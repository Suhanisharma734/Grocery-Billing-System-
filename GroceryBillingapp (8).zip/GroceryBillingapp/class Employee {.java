class Employee {

    int salary = 30000;

    void work() {
        System.out.println("Employee is working");
    }
}

class Manager extends Employee {
                                                                                                                        
    void manage() {
        System.out.println("Manager is managing");
    }
}

class Main {

    public static void main(String[] args) {

        Manager m = new Manager();

        System.out.println("Salary = " + m.salary);

        m.work();
        m.manage();
    }
}