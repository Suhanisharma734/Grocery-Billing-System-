package org.example.ui;

import org.example.dao.ProductDao;
import org.example.model.Product;
import org.example.utils.InputValidator;
import org.example.utils.UiUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.sql.Date;
import java.util.List;

public class ProductManagementFrame extends JFrame {
    private final ProductDao dao = new ProductDao();
    private final DefaultTableModel tableModel = new DefaultTableModel(
            new Object[]{"ID", "Name", "Category", "Price", "Stock", "Expiry"}, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable table = new JTable(tableModel);
    private final JTextField search = new JTextField(18);

    public ProductManagementFrame(Frame owner) {
        setTitle("Product Management"); setSize(760, 460); setLocationRelativeTo(owner);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JButton find = new JButton("Search"), add = new JButton("Add"), edit = new JButton("Edit"), delete = new JButton("Delete"), refresh = new JButton("Refresh");
        for (JButton b : new JButton[]{find, add, edit, delete, refresh}) UiUtils.styleButton(b);
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT)); top.add(new JLabel("Search:")); top.add(search); top.add(find);
        JPanel bottom = new JPanel(); bottom.add(add); bottom.add(edit); bottom.add(delete); bottom.add(refresh);
        add(top, BorderLayout.NORTH); add(new JScrollPane(table), BorderLayout.CENTER); add(bottom, BorderLayout.SOUTH);
        find.addActionListener(e -> loadProducts()); refresh.addActionListener(e -> { search.setText(""); loadProducts(); });
        add.addActionListener(e -> editProduct(null)); edit.addActionListener(e -> editSelected());
        delete.addActionListener(e -> deleteSelected());
        loadProducts();
    }

    private void loadProducts() {
        try {
            tableModel.setRowCount(0);
            List<Product> products = dao.search(search.getText().trim());
            for (Product p : products) tableModel.addRow(new Object[]{p.getProductId(), p.getProductName(), p.getCategory(),
                    String.format("%.2f", p.getPrice()), p.getStock(), p.getExpiryDate()});
        } catch (Exception ex) { UiUtils.showError(this, ex); }
    }
    private Product selectedProduct() {
        int row = table.getSelectedRow();
        if (row < 0) return null;
        return new Product((Integer)tableModel.getValueAt(row, 0), (String)tableModel.getValueAt(row, 1),
                (String)tableModel.getValueAt(row, 2), Double.parseDouble(tableModel.getValueAt(row, 3).toString()),
                (Integer)tableModel.getValueAt(row, 4), tableModel.getValueAt(row, 5) == null ? null :
                Date.valueOf(tableModel.getValueAt(row, 5).toString()));
    }
    private void editSelected() {
        Product p = selectedProduct();
        if (p == null) { JOptionPane.showMessageDialog(this, "Select a product first."); return; }
        editProduct(p);
    }
    private void editProduct(Product product) {
        JTextField name = new JTextField(product == null ? "" : product.getProductName());
        JTextField category = new JTextField(product == null ? "" : product.getCategory());
        JTextField price = new JTextField(product == null ? "" : String.valueOf(product.getPrice()));
        JTextField stock = new JTextField(product == null ? "" : String.valueOf(product.getStock()));
        JTextField expiry = new JTextField(product == null || product.getExpiryDate() == null ? "" : product.getExpiryDate().toString());
        JPanel panel = new JPanel(new GridLayout(0, 2, 5, 5));
        panel.add(new JLabel("Name:")); panel.add(name); panel.add(new JLabel("Category:")); panel.add(category);
        panel.add(new JLabel("Price:")); panel.add(price); panel.add(new JLabel("Stock:")); panel.add(stock);
        panel.add(new JLabel("Expiry (YYYY-MM-DD):")); panel.add(expiry);
        if (JOptionPane.showConfirmDialog(this, panel, product == null ? "Add Product" : "Edit Product",
                JOptionPane.OK_CANCEL_OPTION) != JOptionPane.OK_OPTION) return;
        try {
            Product value = product == null ? new Product() : product;
            value.setProductName(InputValidator.required(name.getText(), "Name"));
            value.setCategory(InputValidator.required(category.getText(), "Category"));
            value.setPrice(InputValidator.positivePrice(price.getText()));
            value.setStock(InputValidator.nonNegativeInt(stock.getText(), "Stock"));
            String date = expiry.getText().trim();
            value.setExpiryDate(date.isEmpty() ? null : Date.valueOf(date));
            dao.save(value); loadProducts();
        } catch (IllegalArgumentException ex) { UiUtils.showError(this, ex); }
        catch (Exception ex) { UiUtils.showError(this, ex); }
    }
    private void deleteSelected() {
        Product p = selectedProduct();
        if (p == null) { JOptionPane.showMessageDialog(this, "Select a product first."); return; }
        if (JOptionPane.showConfirmDialog(this, "Delete " + p.getProductName() + "?",
                "Confirm", JOptionPane.YES_NO_OPTION) == JOptionPane.YES_OPTION) {
            try { dao.delete(p.getProductId()); loadProducts(); } catch (Exception ex) { UiUtils.showError(this, ex); }
        }
    }
}
