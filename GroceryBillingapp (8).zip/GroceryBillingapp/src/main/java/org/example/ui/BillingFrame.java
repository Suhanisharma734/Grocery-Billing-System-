package org.example.ui;

import org.example.dao.BillDao;
import org.example.dao.ProductDao;
import org.example.model.BillItem;
import org.example.model.Product;
import org.example.model.User;
import org.example.utils.InputValidator;
import org.example.utils.UiUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.util.ArrayList;
import java.util.List;

public class BillingFrame extends JFrame {
    private final ProductDao productDao = new ProductDao();
    private final BillDao billDao = new BillDao();
    private final JComboBox<Product> productBox = new JComboBox<>();
    private final JTextField quantity = new JTextField(5);
    private final JTextField discount = new JTextField("0", 5);
    private final DefaultTableModel cartModel = new DefaultTableModel(
            new Object[]{"Product ID", "Product Name", "Price", "Quantity", "Subtotal"}, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };
    private final JTable cartTable = new JTable(cartModel);
    private final List<BillItem> cart = new ArrayList<>();
    private final JLabel subtotalLabel = new JLabel("Subtotal: Rs. 0.00");
    private final JLabel discountLabel = new JLabel("Discount: Rs. 0.00");
    private final JLabel totalLabel = new JLabel("Payable: Rs. 0.00");
    private final User user;

    public BillingFrame(Frame owner, User user) {
        this.user = user;
        setTitle("Create Bill"); setSize(700, 450); setLocationRelativeTo(owner);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JButton addButton = new JButton("Add to Bill"), remove = new JButton("Remove Selected"), generate = new JButton("Generate Bill");
        for (JButton b : new JButton[]{addButton, remove, generate}) UiUtils.styleButton(b);
        JPanel input = new JPanel(new GridLayout(0, 4, 8, 5)); input.add(new JLabel("Product:")); input.add(productBox);
        input.add(new JLabel("Quantity:")); input.add(quantity); input.add(addButton);
        input.add(new JLabel("Discount (%):")); input.add(discount);
        JPanel bottom = new JPanel(new GridLayout(0, 3, 8, 5)); bottom.add(remove); bottom.add(subtotalLabel);
        bottom.add(discountLabel); bottom.add(totalLabel); bottom.add(generate);
        add(input, BorderLayout.NORTH); add(new JScrollPane(cartTable), BorderLayout.CENTER); add(bottom, BorderLayout.SOUTH);
        addButton.addActionListener(e -> addItem()); remove.addActionListener(e -> removeItem()); generate.addActionListener(e -> generateBill());
        loadProducts();
    }
    private void loadProducts() {
        try { productBox.removeAllItems(); for (Product p : productDao.findAll()) if (p.getStock() > 0) productBox.addItem(p); }
        catch (Exception ex) { UiUtils.showError(this, ex); }
    }
    private void addItem() {
        try {
            Product p = (Product) productBox.getSelectedItem();
            if (p == null) throw new IllegalArgumentException("Select a product.");
            int qty = InputValidator.positiveInt(quantity.getText(), "Quantity");
            int existing = 0;
            for (BillItem i : cart) if (i.getProductId() == p.getProductId()) existing += i.getQuantity();
            if (existing + qty > p.getStock()) throw new IllegalArgumentException("Quantity exceeds available stock (" + p.getStock() + ").");
            BillItem item = null;
            for (BillItem i : cart) if (i.getProductId() == p.getProductId()) item = i;
            if (item == null) cart.add(new BillItem(p.getProductId(), p.getProductName(), qty, p.getPrice()));
            else item.setQuantity(existing + qty);
            refreshCart(); quantity.setText("");
        } catch (Exception ex) { UiUtils.showError(this, ex); }
    }
    private void removeItem() {
        int row = cartTable.getSelectedRow();
        if (row >= 0) { cart.remove(row); refreshCart(); }
    }
    private void refreshCart() {
        cartModel.setRowCount(0); double total = 0;
        for (BillItem i : cart) {
            double line = i.getQuantity() * i.getUnitPrice();
            total += line;
            cartModel.addRow(new Object[]{i.getProductId(), i.getProductName(),
                    String.format("%.2f", i.getUnitPrice()), i.getQuantity(), String.format("%.2f", line)});
        }
        double discountPercent = getDiscountPercent();
        double discountAmount = total * discountPercent / 100.0;
        subtotalLabel.setText(String.format("Subtotal: Rs. %.2f", total));
        discountLabel.setText(String.format("Discount: Rs. %.2f", discountAmount));
        totalLabel.setText(String.format("Payable: Rs. %.2f", total - discountAmount));
    }
    private double getDiscountPercent() {
        try {
            double value = Double.parseDouble(discount.getText().trim());
            return value >= 0 && value <= 100 ? value : 0;
        } catch (NumberFormatException ex) {
            return 0;
        }
    }
    private void generateBill() {
        try {
            if (cart.isEmpty()) throw new IllegalArgumentException("Add at least one product.");
            double discountPercent = Double.parseDouble(discount.getText().trim());
            if (discountPercent < 0 || discountPercent > 100)
                throw new IllegalArgumentException("Discount must be between 0 and 100.");
            int id = billDao.createBill(user.getUserId(), cart, discountPercent);
            JOptionPane.showMessageDialog(this, "Bill #" + id + " created successfully.");
            cart.clear(); discount.setText("0"); refreshCart(); loadProducts();
        } catch (Exception ex) { UiUtils.showError(this, ex); loadProducts(); }
    }
}
