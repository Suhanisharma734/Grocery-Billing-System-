/**
 * Java Swing windows, panels, forms, and tables.
 */
package org.example.ui;
