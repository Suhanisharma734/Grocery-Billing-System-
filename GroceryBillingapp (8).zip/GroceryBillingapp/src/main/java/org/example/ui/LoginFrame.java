package org.example.ui;

import org.example.dao.LoginDao;
import org.example.model.User;
import org.example.utils.InputValidator;
import org.example.utils.UiUtils;

import javax.swing.*;
import javax.swing.border.AbstractBorder;
import java.awt.*;
import java.awt.geom.RoundRectangle2D;

public class LoginFrame extends JFrame {
    private final JTextField username = new JTextField(18);
    private final JPasswordField password = new JPasswordField(18);
    private final JComboBox<String> role = new JComboBox<>(new String[]{"Admin", "Cashier"});
    private final LoginDao loginDao = new LoginDao();

    public LoginFrame() {
        setTitle("Grocery Billing System - Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(440, 650);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel root = new JPanel(new GridBagLayout());
        root.setBackground(new Color(247, 250, 248));
        root.setBorder(BorderFactory.createEmptyBorder(24, 24, 24, 24));

        JPanel card = new JPanel();
        card.setBackground(Color.WHITE);
        card.setBorder(new RoundedBorder(22, new Color(229, 231, 235), 1));
        card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
        card.setBorder(BorderFactory.createCompoundBorder(
                new RoundedBorder(22, new Color(229, 231, 235), 1),
                BorderFactory.createEmptyBorder(28, 34, 28, 34)));

        JLabel logo = new JLabel("+", SwingConstants.CENTER);
        logo.setOpaque(true);
        logo.setBackground(new Color(46, 139, 87));
        logo.setForeground(Color.WHITE);
        logo.setFont(new Font("SansSerif", Font.BOLD, 26));
        logo.setAlignmentX(Component.CENTER_ALIGNMENT);
        logo.setPreferredSize(new Dimension(48, 48));
        logo.setMaximumSize(new Dimension(48, 48));
        logo.setBorder(new RoundedBorder(14, new Color(46, 139, 87), 1));

        JLabel title = new JLabel("GROCERY BILLING");
        title.setFont(new Font("SansSerif", Font.BOLD, 22));
        title.setForeground(new Color(35, 122, 75));
        title.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel subtitle = new JLabel("Sign in to your account");
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 13));
        subtitle.setForeground(new Color(107, 114, 128));
        subtitle.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton login = new JButton("Login to System");
        login.setFont(new Font("SansSerif", Font.BOLD, 14));
        login.setBackground(new Color(46, 139, 87));
        login.setForeground(Color.WHITE);
        login.setFocusPainted(false);
        login.setCursor(new Cursor(Cursor.HAND_CURSOR));
        login.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
        login.setBorder(new RoundedBorder(10, new Color(46, 139, 87), 1));

        JButton exit = new JButton("Exit");
        UiUtils.styleButton(exit);
        exit.setCursor(new Cursor(Cursor.HAND_CURSOR));
        exit.addActionListener(e -> System.exit(0));
        login.addActionListener(e -> login());
        password.addActionListener(e -> login());

        card.add(logo);
        card.add(Box.createVerticalStrut(14));
        card.add(title);
        card.add(Box.createVerticalStrut(4));
        card.add(subtitle);
        card.add(Box.createVerticalStrut(26));
        addField(card, "Username", username);
        addField(card, "Password", password);
        addField(card, "Role", role);
        card.add(Box.createVerticalStrut(12));
        card.add(login);
        card.add(Box.createVerticalStrut(8));
        exit.setAlignmentX(Component.CENTER_ALIGNMENT);
        card.add(exit);
        card.add(Box.createVerticalStrut(18));

        JPanel demo = new JPanel(new BorderLayout());
        demo.setBackground(new Color(234, 246, 238));
        demo.setBorder(BorderFactory.createCompoundBorder(
                new RoundedBorder(10, new Color(190, 224, 201), 1),
                BorderFactory.createEmptyBorder(10, 12, 10, 12)));
        JLabel hint = new JLabel("<html><b>Demo credentials</b><br>admin / 1234 (Admin)</html>");
        hint.setFont(new Font("SansSerif", Font.PLAIN, 11));
        hint.setForeground(new Color(35, 122, 75));
        demo.add(hint, BorderLayout.CENTER);
        card.add(demo);

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.weightx = 1;
        constraints.weighty = 1;
        root.add(card, constraints);
        setContentPane(root);
    }

    private void addField(JPanel parent, String labelText, JComponent field) {
        JLabel label = new JLabel(labelText);
        label.setFont(new Font("SansSerif", Font.BOLD, 12));
        label.setForeground(new Color(31, 41, 55));
        label.setAlignmentX(Component.LEFT_ALIGNMENT);
        parent.add(label);
        parent.add(Box.createVerticalStrut(5));
        if (field instanceof JTextField textField) {
            textField.setFont(new Font("SansSerif", Font.PLAIN, 13));
            textField.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
            textField.setBorder(BorderFactory.createCompoundBorder(
                    new RoundedBorder(9, new Color(203, 213, 225), 1),
                    BorderFactory.createEmptyBorder(6, 10, 6, 10)));
        } else if (field instanceof JComboBox<?> comboBox) {
            comboBox.setFont(new Font("SansSerif", Font.PLAIN, 13));
            comboBox.setBackground(Color.WHITE);
            comboBox.setMaximumSize(new Dimension(Integer.MAX_VALUE, 38));
            comboBox.setBorder(new RoundedBorder(9, new Color(203, 213, 225), 1));
        }
        parent.add(field);
        parent.add(Box.createVerticalStrut(14));
    }

    private void login() {
        try {
            String user = InputValidator.required(username.getText(), "Username");
            String pass = InputValidator.required(new String(password.getPassword()), "Password");
            String selectedRole = String.valueOf(role.getSelectedItem()).toUpperCase();
            User loggedIn = loginDao.login(user, pass, selectedRole);
            if (loggedIn == null) {
                JOptionPane.showMessageDialog(this, "Invalid username, password, or role.",
                        "Login Failed", JOptionPane.WARNING_MESSAGE);
                return;
            }
            dispose(); new DashboardFrame(loggedIn).setVisible(true);
        } catch (Exception ex) { UiUtils.showError(this, ex); }
    }

    private static class RoundedBorder extends AbstractBorder {
        private final int radius;
        private final Color color;
        private final int thickness;

        private RoundedBorder(int radius, Color color, int thickness) {
            this.radius = radius;
            this.color = color;
            this.thickness = thickness;
        }

        @Override
        public Insets getBorderInsets(Component component) {
            return new Insets(thickness + 2, thickness + 2, thickness + 2, thickness + 2);
        }

        @Override
        public void paintBorder(Component component, Graphics graphics, int x, int y, int width, int height) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(color);
            g.setStroke(new BasicStroke(thickness));
            g.draw(new RoundRectangle2D.Double(x + thickness / 2.0, y + thickness / 2.0,
                    width - thickness, height - thickness, radius, radius));
            g.dispose();
        }
    }
}
