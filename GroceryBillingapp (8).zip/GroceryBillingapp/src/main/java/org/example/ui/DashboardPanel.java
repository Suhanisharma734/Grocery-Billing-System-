package org.example.ui;

import org.example.dao.ProductDao;
import org.example.dao.SalesDao;
import org.example.model.Product;
import org.example.model.Sale;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import java.awt.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.List;

/** Dashboard overview with responsive metrics, category shortcuts, and live tables. */
public class DashboardPanel extends JPanel {
    private static final Color BACKGROUND = new Color(247, 250, 248);
    private static final Color SURFACE = Color.WHITE;
    private static final Color TEXT = new Color(31, 41, 55);
    private static final Color MUTED = new Color(107, 114, 128);
    private static final Color BORDER = new Color(226, 232, 235);
    private static final Color GREEN = new Color(35, 122, 75);
    private static final Color GREEN_LIGHT = new Color(232, 246, 237);
    private static final DecimalFormat MONEY = new DecimalFormat("₹ #,##0.00");

    public DashboardPanel() {
        setLayout(new BorderLayout());
        setBackground(BACKGROUND);
        setBorder(new EmptyBorder(8, 10, 10, 10));

        DashboardContent content = new DashboardContent();
        content.setBorder(new EmptyBorder(8, 8, 14, 14));

        GridBagConstraints constraints = new GridBagConstraints();
        constraints.gridx = 0;
        constraints.weightx = 1;
        constraints.fill = GridBagConstraints.HORIZONTAL;
        constraints.anchor = GridBagConstraints.NORTH;
        constraints.insets = new Insets(0, 0, 14, 0);

        constraints.gridy = 0;
        content.add(createHeaderPanel(), constraints);
        constraints.gridy = 1;
        content.add(createStatsPanel(), constraints);
        constraints.gridy = 2;
        content.add(createCategoryPanel(), constraints);
        constraints.gridy = 3;
        constraints.weighty = 1;
        constraints.fill = GridBagConstraints.BOTH;
        constraints.insets = new Insets(0, 0, 0, 0);
        content.add(createTablesPanel(), constraints);

        JScrollPane scrollPane = new JScrollPane(content,
                ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
        scrollPane.setBorder(null);
        scrollPane.getVerticalScrollBar().setUnitIncrement(16);
        scrollPane.getViewport().setBackground(BACKGROUND);
        add(scrollPane, BorderLayout.CENTER);
    }

    private JPanel createHeaderPanel() {
        JPanel panel = new JPanel(new BorderLayout(16, 0));
        panel.setOpaque(false);

        JPanel copy = new JPanel();
        copy.setOpaque(false);
        copy.setLayout(new BoxLayout(copy, BoxLayout.Y_AXIS));
        JLabel title = new JLabel("Dashboard Overview");
        title.setForeground(TEXT);
        title.setFont(new Font("SansSerif", Font.BOLD, 26));
        JLabel subtitle = new JLabel("A clear view of today's store performance and activity");
        subtitle.setForeground(MUTED);
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 13));
        copy.add(title);
        copy.add(Box.createVerticalStrut(5));
        copy.add(subtitle);
        panel.add(copy, BorderLayout.WEST);

        JLabel sectionTag = new JLabel("STORE OVERVIEW");
        sectionTag.setOpaque(true);
        sectionTag.setBackground(GREEN_LIGHT);
        sectionTag.setForeground(GREEN);
        sectionTag.setFont(new Font("SansSerif", Font.BOLD, 10));
        sectionTag.setBorder(new EmptyBorder(8, 11, 8, 11));
        panel.add(sectionTag, BorderLayout.EAST);
        return panel;
    }

    private JPanel createStatsPanel() {
        int totalProducts = 0;
        double todaySales = 0;
        int todayBills = 0;
        int lowStock = 0;
        try {
            ProductDao productDao = new ProductDao();
            SalesDao salesDao = new SalesDao();
            totalProducts = productDao.count();
            lowStock = productDao.countLowStock();
            todaySales = salesDao.todayRevenue();
            todayBills = salesDao.todayBills();
        } catch (Exception ignored) {
            // Keep the dashboard available if the database is temporarily unavailable.
        }

        JPanel panel = new JPanel(new GridLayout(1, 4, 12, 0));
        panel.setOpaque(false);
        panel.add(createStatCard("TOTAL PRODUCTS", String.valueOf(totalProducts),
                "Products in your catalog", GREEN, "▣"));
        panel.add(createStatCard("TODAY'S SALES", MONEY.format(todaySales),
                "Sales recorded today", new Color(30, 132, 98), "₹"));
        panel.add(createStatCard("TODAY'S BILLS", String.valueOf(todayBills),
                "Bills created today", new Color(57, 110, 82), "▤"));
        panel.add(createStatCard("LOW STOCK", String.valueOf(lowStock),
                "Items needing attention", new Color(190, 125, 34), "!"));
        return panel;
    }

    private JPanel createCategoryPanel() {
        DashboardCard card = new DashboardCard(new BorderLayout(0, 8));
        card.setBorder(new EmptyBorder(13, 16, 12, 16));

        JPanel heading = new JPanel(new BorderLayout());
        heading.setOpaque(false);
        JLabel title = new JLabel("Quick categories");
        title.setForeground(TEXT);
        title.setFont(new Font("SansSerif", Font.BOLD, 14));
        JLabel hint = new JLabel("Choose a category");
        hint.setForeground(MUTED);
        hint.setFont(new Font("SansSerif", Font.PLAIN, 11));
        heading.add(title, BorderLayout.WEST);
        heading.add(hint, BorderLayout.EAST);
        card.add(heading, BorderLayout.NORTH);

        JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 3));
        buttons.setOpaque(false);
        String[] categories = {"All", "Grocery", "Beverages", "Dairy",
                "Snacks", "Personal Care", "Household", "Bakery"};
        PillButton[] categoryButtons = new PillButton[categories.length];
        for (int i = 0; i < categories.length; i++) {
            PillButton button = new PillButton(categories[i], i == 0);
            categoryButtons[i] = button;
            button.addActionListener(event -> {
                for (PillButton categoryButton : categoryButtons) {
                    categoryButton.setActive(categoryButton == button);
                }
            });
            buttons.add(button);
        }
        card.add(buttons, BorderLayout.CENTER);
        return card;
    }

    private JPanel createTablesPanel() {
        JPanel panel = new JPanel(new GridLayout(1, 2, 14, 0));
        panel.setOpaque(false);
        panel.setMinimumSize(new Dimension(0, 220));
        panel.setPreferredSize(new Dimension(0, 340));
        panel.add(createRecentSalesCard());
        panel.add(createLowStockCard());
        return panel;
    }

    private JPanel createRecentSalesCard() {
        DefaultTableModel model = new DefaultTableModel(
                new Object[]{"Bill No.", "Customer", "Date", "Amount"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        try {
            List<Sale> sales = new SalesDao().findAll();
            SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
            for (int i = 0; i < Math.min(10, sales.size()); i++) {
                Sale sale = sales.get(i);
                model.addRow(new Object[]{
                        sale.getBillNumber(),
                        sale.getCustomerName() == null ? "Walk-in" : sale.getCustomerName(),
                        sale.getSaleDate() == null ? "-" : dateFormat.format(sale.getSaleDate()),
                        MONEY.format(sale.getGrandTotal())
                });
            }
        } catch (Exception ignored) {
            // Keep the dashboard table available if sales cannot be loaded.
        }
        return createTableCard("Recent Sales", model, "No sales recorded yet.");
    }

    private JPanel createLowStockCard() {
        DefaultTableModel model = new DefaultTableModel(
                new Object[]{"Product", "Stock", "Status"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        try {
            List<Product> products = new ProductDao().findLowStockProducts();
            for (int i = 0; i < Math.min(10, products.size()); i++) {
                Product product = products.get(i);
                model.addRow(new Object[]{
                        product.getProductName(),
                        product.getStock(),
                        product.getStock() <= 0 ? "Out of Stock" : "Low Stock"
                });
            }
        } catch (Exception ignored) {
            // Keep the dashboard table available if inventory cannot be loaded.
        }
        return createTableCard("Low Stock Alert", model, "No low-stock products.");
    }

    private JPanel createTableCard(String title, DefaultTableModel model, String emptyText) {
        DashboardCard card = new DashboardCard(new BorderLayout(0, 10));
        card.setBorder(new EmptyBorder(14, 15, 14, 15));

        JPanel heading = new JPanel(new BorderLayout());
        heading.setOpaque(false);
        JLabel titleLabel = new JLabel(title);
        titleLabel.setForeground(TEXT);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 16));
        heading.add(titleLabel, BorderLayout.WEST);
        JLabel count = new JLabel(model.getRowCount() == 0 ? "—" : String.valueOf(model.getRowCount()));
        count.setForeground(GREEN);
        count.setFont(new Font("SansSerif", Font.BOLD, 11));
        count.setBorder(new EmptyBorder(4, 8, 4, 8));
        count.setOpaque(true);
        count.setBackground(GREEN_LIGHT);
        heading.add(count, BorderLayout.EAST);
        card.add(heading, BorderLayout.NORTH);

        if (model.getRowCount() == 0) {
            JLabel empty = new JLabel(emptyText, SwingConstants.CENTER);
            empty.setForeground(MUTED);
            empty.setFont(new Font("SansSerif", Font.PLAIN, 13));
            card.add(empty, BorderLayout.CENTER);
        } else {
            JTable table = new JTable(model);
            styleTable(table);
            JScrollPane scrollPane = new JScrollPane(table,
                    ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                    ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
            scrollPane.setBorder(null);
            scrollPane.getViewport().setBackground(SURFACE);
            scrollPane.getVerticalScrollBar().setUnitIncrement(16);
            card.add(scrollPane, BorderLayout.CENTER);
        }
        return card;
    }

    private void styleTable(JTable table) {
        table.setRowHeight(34);
        table.setFillsViewportHeight(true);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 0));
        table.setBackground(SURFACE);
        table.setForeground(TEXT);
        table.setSelectionBackground(GREEN_LIGHT);
        table.setSelectionForeground(TEXT);
        table.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
        table.setRowMargin(0);

        JTableHeader header = table.getTableHeader();
        header.setPreferredSize(new Dimension(0, 34));
        header.setBackground(new Color(241, 245, 242));
        header.setForeground(MUTED);
        header.setFont(new Font("SansSerif", Font.BOLD, 11));
        header.setReorderingAllowed(false);
        header.setBorder(BorderFactory.createMatteBorder(0, 0, 1, 0, BORDER));
        DefaultTableCellRenderer headerRenderer = new DefaultTableCellRenderer();
        headerRenderer.setBackground(new Color(241, 245, 242));
        headerRenderer.setForeground(MUTED);
        headerRenderer.setFont(new Font("SansSerif", Font.BOLD, 11));
        headerRenderer.setBorder(new EmptyBorder(0, 9, 0, 9));
        header.setDefaultRenderer(headerRenderer);

        table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable source, Object value,
                                                           boolean selected, boolean focused,
                                                           int row, int column) {
                Component cell = super.getTableCellRendererComponent(
                        source, value, selected, focused, row, column);
                cell.setForeground(TEXT);
                cell.setBackground(selected ? GREEN_LIGHT : (row % 2 == 0
                        ? SURFACE : new Color(250, 252, 250)));
                setBorder(new EmptyBorder(0, 9, 0, 9));
                setFont(new Font("SansSerif", Font.PLAIN, 12));
                return cell;
            }
        });
    }

    private JPanel createStatCard(String title, String value, String detail,
                                  Color accent, String iconText) {
        DashboardCard card = new DashboardCard(new BorderLayout(8, 7));
        card.setBorder(new EmptyBorder(13, 14, 12, 14));

        JPanel top = new JPanel(new BorderLayout(8, 0));
        top.setOpaque(false);
        JLabel titleLabel = new JLabel(title);
        titleLabel.setForeground(MUTED);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 10));
        top.add(titleLabel, BorderLayout.CENTER);
        top.add(new IconBadge(iconText, accent), BorderLayout.EAST);
        card.add(top, BorderLayout.NORTH);

        JLabel valueLabel = new JLabel(value);
        valueLabel.setForeground(TEXT);
        valueLabel.setFont(new Font("SansSerif", Font.BOLD, 21));
        valueLabel.setToolTipText(value);
        card.add(valueLabel, BorderLayout.CENTER);

        JLabel detailLabel = new JLabel(detail);
        detailLabel.setForeground(MUTED);
        detailLabel.setFont(new Font("SansSerif", Font.PLAIN, 10));
        card.add(detailLabel, BorderLayout.SOUTH);
        return card;
    }

    private static final class DashboardContent extends JPanel implements Scrollable {
        DashboardContent() {
            super(new GridBagLayout());
            setOpaque(false);
        }

        @Override
        public Dimension getPreferredScrollableViewportSize() {
            return new Dimension(900, 600);
        }

        @Override
        public boolean getScrollableTracksViewportWidth() {
            return true;
        }

        @Override
        public boolean getScrollableTracksViewportHeight() {
            return false;
        }

        @Override
        public int getScrollableUnitIncrement(Rectangle visibleRect, int orientation, int direction) {
            return 16;
        }

        @Override
        public int getScrollableBlockIncrement(Rectangle visibleRect, int orientation, int direction) {
            return Math.max(visibleRect.height - 32, 16);
        }
    }

    private static final class DashboardCard extends JPanel {
        DashboardCard(LayoutManager layout) {
            super(layout);
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(new Color(15, 81, 50, 15));
            g.fillRoundRect(2, 3, getWidth() - 5, getHeight() - 5, 18, 18);
            g.setColor(SURFACE);
            g.fillRoundRect(0, 0, getWidth() - 5, getHeight() - 5, 18, 18);
            g.setColor(BORDER);
            g.drawRoundRect(0, 0, getWidth() - 5, getHeight() - 5, 18, 18);
            g.dispose();
        }
    }

    private static final class IconBadge extends JLabel {
        IconBadge(String text, Color accent) {
            super(text, SwingConstants.CENTER);
            setForeground(accent);
            setFont(new Font("SansSerif", Font.BOLD, 16));
            setPreferredSize(new Dimension(36, 36));
            setMinimumSize(new Dimension(36, 36));
            setOpaque(false);
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(new Color(getForeground().getRed(), getForeground().getGreen(),
                    getForeground().getBlue(), 24));
            g.fillOval(0, 0, getWidth() - 1, getHeight() - 1);
            g.dispose();
            super.paintComponent(graphics);
        }
    }

    private static final class PillButton extends JButton {
        private boolean selected;
        private boolean hovered;

        PillButton(String text, boolean selected) {
            super(text);
            this.selected = selected;
            setFont(new Font("SansSerif", Font.BOLD, 12));
            setBorder(new EmptyBorder(8, 13, 8, 13));
            setFocusPainted(false);
            setContentAreaFilled(false);
            setOpaque(false);
            setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
            updateForeground();
            addMouseListener(new java.awt.event.MouseAdapter() {
                @Override
                public void mouseEntered(java.awt.event.MouseEvent event) {
                    hovered = true;
                    repaint();
                }

                @Override
                public void mouseExited(java.awt.event.MouseEvent event) {
                    hovered = false;
                    repaint();
                }
            });
        }

        void setActive(boolean selected) {
            this.selected = selected;
            updateForeground();
            repaint();
        }

        private void updateForeground() {
            setForeground(selected ? Color.WHITE : GREEN);
        }

        @Override
        protected void paintComponent(Graphics graphics) {
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(selected ? GREEN : (hovered ? GREEN_LIGHT : SURFACE));
            g.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);
            g.setColor(selected ? GREEN : BORDER);
            g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 18, 18);
            g.dispose();
            super.paintComponent(graphics);
        }
    }
}
