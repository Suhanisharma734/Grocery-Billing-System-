package org.example.ui;

import org.example.dao.BillDao;
import org.example.model.Bill;
import org.example.utils.UiUtils;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;

public class BillHistoryFrame extends JFrame {
    private final BillDao dao = new BillDao();
    private final DefaultTableModel model = new DefaultTableModel(new Object[]{"Bill ID", "Date", "User", "Total"}, 0) {
        @Override public boolean isCellEditable(int row, int column) { return false; }
    };
    public BillHistoryFrame(Frame owner) {
        setTitle("Bill History"); setSize(650, 400); setLocationRelativeTo(owner);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        JButton refresh = new JButton("Refresh"); UiUtils.styleButton(refresh);
        add(new JScrollPane(new JTable(model)), BorderLayout.CENTER); add(refresh, BorderLayout.SOUTH);
        refresh.addActionListener(e -> load()); load();
    }
    private void load() {
        try {
            model.setRowCount(0);
            for (Bill b : dao.findAll()) model.addRow(new Object[]{b.getBillId(), b.getBillDate(),
                    b.getUsername() == null ? "Unknown" : b.getUsername(), String.format("%.2f", b.getTotalAmount())});
        } catch (Exception ex) { UiUtils.showError(this, ex); }
    }
}
