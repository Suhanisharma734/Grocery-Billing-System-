package org.example.ui;

import org.example.dao.CustomerDao;
import org.example.dao.ProductDao;
import org.example.dao.SalesDao;
import org.example.model.Product;
import org.example.model.Sale;
import org.example.model.User;
import org.example.utils.UiUtils;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.List;

public class DashboardFrame extends JFrame {
    private static final Color BACKGROUND = new Color(248, 250, 252);
    private static final Color SURFACE = Color.WHITE;
    private static final Color TEXT = new Color(30, 41, 59);
    private static final Color MUTED = new Color(100, 116, 139);
    private static final Color BORDER = new Color(226, 232, 240);
    private static final Color NAVY = new Color(15, 23, 42);
    private static final Color NAVY_MUTED = new Color(148, 163, 184);
    private static final Color GREEN = new Color(16, 185, 129);
    private static final DecimalFormat MONEY = new DecimalFormat("₹ #,##0.00");

    private final User user;

    public DashboardFrame(User user) {
        this.user = user;
        setTitle("Grocery Billing System - Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        int frameWidth = Math.min(1180, screenSize.width - 40);
        int frameHeight = Math.min(740, screenSize.height - 60);
        setSize(frameWidth, frameHeight);
        setMinimumSize(new Dimension(Math.min(980, frameWidth), Math.min(650, frameHeight)));
        setLocationRelativeTo(null);

        JPanel root = new JPanel(new BorderLayout(18, 0));
        root.setBackground(BACKGROUND);
        root.setBorder(new EmptyBorder(16, 16, 16, 16));
        root.add(buildSidebar(), BorderLayout.WEST);
        root.add(buildContent(), BorderLayout.CENTER);
        setContentPane(root);
    }

    private JPanel buildSidebar() {
        JPanel sidebar = new JPanel(new BorderLayout());
        sidebar.setBackground(NAVY);
        sidebar.setBorder(new EmptyBorder(22, 16, 18, 16));
        sidebar.setPreferredSize(new Dimension(220, 0));

        JPanel top = new JPanel();
        top.setOpaque(false);
        top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));

        JLabel brand = new JLabel("GROCERY POS");
        brand.setForeground(Color.WHITE);
        brand.setFont(new Font("SansSerif", Font.BOLD, 19));
        brand.setAlignmentX(Component.LEFT_ALIGNMENT);
        JLabel subtitle = new JLabel("Billing System");
        subtitle.setForeground(NAVY_MUTED);
        subtitle.setFont(new Font("SansSerif", Font.PLAIN, 12));
        subtitle.setAlignmentX(Component.LEFT_ALIGNMENT);
        top.add(brand);
        top.add(Box.createVerticalStrut(3));
        top.add(subtitle);
        top.add(Box.createVerticalStrut(28));

        String[] labels = {"Dashboard", "Billing / POS", "Products", "Customers",
                "Sales History", "Stock", "Reports", "Settings"};
        JButton[] buttons = new JButton[labels.length];
        JPanel navigation = new JPanel();
        navigation.setOpaque(false);
        navigation.setLayout(new BoxLayout(navigation, BoxLayout.Y_AXIS));

        for (int i = 0; i < labels.length; i++) {
            JButton button = new JButton(labels[i]);
            button.setFocusPainted(false);
            button.setBorderPainted(false);
            button.setOpaque(true);
            button.setHorizontalAlignment(SwingConstants.LEFT);
            button.setForeground(i == 0 ? Color.WHITE : NAVY_MUTED);
            button.setBackground(i == 0 ? GREEN : NAVY);
            button.setFont(new Font("SansSerif", Font.BOLD, 13));
            button.setBorder(new EmptyBorder(11, 12, 11, 12));
            button.setMaximumSize(new Dimension(Integer.MAX_VALUE, 42));
            button.setCursor(new Cursor(Cursor.HAND_CURSOR));
            buttons[i] = button;

            final int index = i;
            button.addActionListener(e -> {
                for (int j = 0; j < buttons.length; j++) {
                    buttons[j].setBackground(j == index ? GREEN : NAVY);
                    buttons[j].setForeground(j == index ? Color.WHITE : NAVY_MUTED);
                }
                openSection(labels[index]);
            });
            navigation.add(button);
            navigation.add(Box.createVerticalStrut(5));
        }

        top.add(navigation);
        sidebar.add(top, BorderLayout.NORTH);

        JPanel footer = new JPanel();
        footer.setOpaque(false);
        footer.setLayout(new BoxLayout(footer, BoxLayout.Y_AXIS));
        JLabel userLabel = new JLabel("Signed in as " + user.getUsername());
        userLabel.setForeground(NAVY_MUTED);
        userLabel.setFont(new Font("SansSerif", Font.PLAIN, 11));
        userLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
        JButton logout = new JButton("Logout");
        logout.setAlignmentX(Component.LEFT_ALIGNMENT);
        logout.setFocusPainted(false);
        logout.setForeground(Color.WHITE);
        logout.setBackground(new Color(31, 43, 67));
        logout.setBorder(new EmptyBorder(10, 12, 10, 12));
        logout.setMaximumSize(new Dimension(Integer.MAX_VALUE, 40));
        logout.addActionListener(e -> {
            dispose();
            new LoginFrame().setVisible(true);
        });
        footer.add(userLabel);
        footer.add(Box.createVerticalStrut(10));
        footer.add(logout);
        sidebar.add(footer, BorderLayout.SOUTH);
        return sidebar;
    }

    private JPanel buildContent() {
        JPanel content = new JPanel(new BorderLayout(0, 16));
        content.setOpaque(false);
        content.add(buildHeader(), BorderLayout.NORTH);

        JPanel body = new JPanel(new BorderLayout(0, 16));
        body.setOpaque(false);
        body.add(buildMetricCards(), BorderLayout.NORTH);
        body.add(buildTables(), BorderLayout.CENTER);
        content.add(body, BorderLayout.CENTER);
        return content;
    }

    private JPanel buildHeader() {
        JPanel header = new JPanel(new BorderLayout(14, 0));
        header.setOpaque(false);
        JLabel title = new JLabel("Dashboard Overview");
        title.setForeground(TEXT);
        title.setFont(new Font("SansSerif", Font.BOLD, 26));
        JLabel greeting = new JLabel("Welcome back, " + user.getUsername());
        greeting.setForeground(MUTED);
        greeting.setFont(new Font("SansSerif", Font.PLAIN, 13));

        JPanel copy = new JPanel();
        copy.setOpaque(false);
        copy.setLayout(new BoxLayout(copy, BoxLayout.Y_AXIS));
        copy.add(title);
        copy.add(Box.createVerticalStrut(4));
        copy.add(greeting);

        JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
        actions.setOpaque(false);
        JButton newBill = new JButton("+ New Bill");
        stylePrimaryButton(newBill);
        newBill.addActionListener(e -> new BillingFrame(this, user).setVisible(true));
        JButton refresh = new JButton("Refresh");
        styleSecondaryButton(refresh);
        refresh.addActionListener(e -> refreshDashboard());
        actions.add(refresh);
        actions.add(newBill);

        header.add(copy, BorderLayout.WEST);
        header.add(actions, BorderLayout.EAST);
        return header;
    }

    private JPanel buildMetricCards() {
        double revenue = 0;
        int bills = 0;
        int items = 0;
        int lowStock = 0;
        int products = 0;
        int customers = 0;
        try {
            SalesDao salesDao = new SalesDao();
            ProductDao productDao = new ProductDao();
            revenue = salesDao.todayRevenue();
            bills = salesDao.todayBills();
            items = salesDao.todayItems();
            lowStock = productDao.countLowStock();
            products = productDao.count();
            customers = new CustomerDao().count();
        } catch (Exception ignored) {
            // Individual cards safely retain zero values when the database is unavailable.
        }

        JPanel cards = new JPanel(new GridLayout(1, 4, 12, 0));
        cards.setOpaque(false);
        cards.add(createCard("Today's Revenue", MONEY.format(revenue), "Live sales total", GREEN));
        cards.add(createCard("Bills Today", String.valueOf(bills), "Completed bills", new Color(59, 130, 246)));
        cards.add(createCard("Items Sold", String.valueOf(items), products + " products listed", new Color(99, 102, 241)));
        cards.add(createCard("Low Stock", lowStock + " items", customers + " customers", new Color(245, 158, 11)));
        return cards;
    }

    private JPanel buildTables() {
        JPanel tables = new JPanel(new GridLayout(1, 2, 16, 0));
        tables.setOpaque(false);

        List<Product> lowStock = List.of();
        List<Sale> sales = List.of();
        try {
            lowStock = new ProductDao().findLowStockProducts();
            sales = new SalesDao().findAll();
        } catch (Exception ex) {
            UiUtils.showError(this, ex);
        }

        DefaultTableModel lowModel = new DefaultTableModel(
                new Object[]{"Product", "Stock", "Status"}, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        for (int i = 0; i < Math.min(8, lowStock.size()); i++) {
            Product product = lowStock.get(i);
            String status = product.getStock() <= 0 ? "Out of Stock" : "Low Stock";
            lowModel.addRow(new Object[]{product.getProductName(), product.getStock(), status});
        }

        DefaultTableModel salesModel = new DefaultTableModel(
                new Object[]{"Bill No.", "Customer", "Date", "Amount", "Payment"}, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        SimpleDateFormat dateFormat = new SimpleDateFormat("dd MMM yyyy");
        for (int i = 0; i < Math.min(8, sales.size()); i++) {
            Sale sale = sales.get(i);
            salesModel.addRow(new Object[]{
                    sale.getBillNumber(),
                    sale.getCustomerName() == null ? "Walk-in" : sale.getCustomerName(),
                    sale.getSaleDate() == null ? "-" : dateFormat.format(sale.getSaleDate()),
                    MONEY.format(sale.getGrandTotal()),
                    sale.getPaymentMethod()
            });
        }

        tables.add(createTableCard("Low Stock Alerts", lowModel, "No low-stock products."));
        tables.add(createTableCard("Recent Transactions", salesModel, "No transactions recorded."));
        return tables;
    }

    private JPanel createCard(String title, String value, String detail, Color accent) {
        JPanel card = new JPanel(new BorderLayout(8, 5));
        card.setBackground(SURFACE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createMatteBorder(0, 4, 0, 0, accent),
                BorderFactory.createCompoundBorder(
                        BorderFactory.createLineBorder(BORDER),
                        new EmptyBorder(14, 14, 14, 14))));
        JLabel titleLabel = new JLabel(title.toUpperCase());
        titleLabel.setForeground(MUTED);
        titleLabel.setFont(new Font("SansSerif", Font.BOLD, 10));
        JLabel valueLabel = new JLabel(value);
        valueLabel.setForeground(TEXT);
        valueLabel.setFont(new Font("SansSerif", Font.BOLD, 21));
        JLabel detailLabel = new JLabel(detail);
        detailLabel.setForeground(MUTED);
        detailLabel.setFont(new Font("SansSerif", Font.PLAIN, 11));
        card.add(titleLabel, BorderLayout.NORTH);
        card.add(valueLabel, BorderLayout.CENTER);
        card.add(detailLabel, BorderLayout.SOUTH);
        return card;
    }

    private JPanel createTableCard(String title, DefaultTableModel model, String emptyText) {
        JPanel card = new JPanel(new BorderLayout(8, 10));
        card.setBackground(SURFACE);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER),
                new EmptyBorder(14, 14, 14, 14)));
        JLabel heading = new JLabel(title);
        heading.setForeground(TEXT);
        heading.setFont(new Font("SansSerif", Font.BOLD, 16));
        card.add(heading, BorderLayout.NORTH);

        if (model.getRowCount() == 0) {
            JLabel empty = new JLabel(emptyText, SwingConstants.CENTER);
            empty.setForeground(MUTED);
            card.add(empty, BorderLayout.CENTER);
        } else {
            JTable table = new JTable(model);
            table.setRowHeight(32);
            table.setShowGrid(false);
            table.setFillsViewportHeight(true);
            table.setBackground(SURFACE);
            table.setForeground(TEXT);
            table.setSelectionBackground(new Color(236, 253, 245));
            table.setSelectionForeground(TEXT);
            table.getTableHeader().setBackground(new Color(241, 245, 249));
            table.getTableHeader().setForeground(MUTED);
            table.getTableHeader().setFont(new Font("SansSerif", Font.BOLD, 11));
            JScrollPane scroll = new JScrollPane(table);
            scroll.setBorder(null);
            card.add(scroll, BorderLayout.CENTER);
        }
        return card;
    }

    private void openSection(String section) {
        switch (section) {
            case "Billing / POS" -> new BillingFrame(this, user).setVisible(true);
            case "Products" -> new ProductManagementFrame(this).setVisible(true);
            case "Sales History" -> new BillHistoryFrame(this).setVisible(true);
            case "Customers", "Stock", "Reports", "Settings" ->
                    JOptionPane.showMessageDialog(this, section + " is available from the main application.",
                            section, JOptionPane.INFORMATION_MESSAGE);
            default -> refreshDashboard();
        }
    }

    private void refreshDashboard() {
        getContentPane().removeAll();
        getContentPane().add(buildSidebar(), BorderLayout.WEST);
        getContentPane().add(buildContent(), BorderLayout.CENTER);
        getContentPane().revalidate();
        getContentPane().repaint();
    }

    private void stylePrimaryButton(JButton button) {
        button.setBackground(GREEN);
        button.setForeground(Color.WHITE);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createEmptyBorder(10, 16, 10, 16));
    }

    private void styleSecondaryButton(JButton button) {
        button.setBackground(SURFACE);
        button.setForeground(TEXT);
        button.setFocusPainted(false);
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(BORDER),
                BorderFactory.createEmptyBorder(9, 14, 9, 14)));
    }
}
