/**
 * JDBC connection and database utility classes.
 */
package org.example.database;
