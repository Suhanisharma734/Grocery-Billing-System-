


package org.example.database;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

/** Opens MySQL connections and creates application-owned tables when needed. */
public final class DatabaseConnection {
    private static final String URL = "jdbc:mysql://localhost:3307/grocery_db?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
    private static final String USER = "root";
    private static final String PASSWORD = "a1A@Suhani";

    private DatabaseConnection() { }

    public static Connection getConnection() throws SQLException {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException
                e) {
            throw new SQLException("MySQL JDBC driver not found. Add mysql-connector-j to the project.", e);
        }
        return DriverManager.getConnection(URL, USER, PASSWORD);
    }

    public static void initializeDatabase() throws SQLException {
        try (Connection connection = getConnection(); Statement statement = connection.createStatement()) {
            statement.executeUpdate("CREATE TABLE IF NOT EXISTS users (" +
                    "user_id INT NOT NULL AUTO_INCREMENT, " +
                    "username VARCHAR(50) NOT NULL UNIQUE, " +
                    "password VARCHAR(255) NOT NULL, " +
                    "role VARCHAR(20) NOT NULL DEFAULT 'CASHIER', " +
                    "full_name VARCHAR(100), " +
                    "created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, " +
                    "PRIMARY KEY (user_id)) ENGINE=InnoDB");

            statement.executeUpdate("CREATE TABLE IF NOT EXISTS categories (" +
                    "category_id INT NOT NULL AUTO_INCREMENT, " +
                    "category_name VARCHAR(80) NOT NULL UNIQUE, " +
                    "PRIMARY KEY (category_id)) ENGINE=InnoDB");

            statement.executeUpdate("CREATE TABLE IF NOT EXISTS products (" +
                    "product_id INT NOT NULL AUTO_INCREMENT, " +
                    "product_name VARCHAR(100) NOT NULL, " +
                    "category VARCHAR(80) NOT NULL, " +
                    "unit VARCHAR(30) NOT NULL DEFAULT 'pcs', " +
                    "price DECIMAL(10,2) NOT NULL, " +
                    "stock INT NOT NULL DEFAULT 0, " +
                    "minimum_stock_level INT NOT NULL DEFAULT 0, " +
                    "product_photo_path VARCHAR(255) NULL, " +
                    "barcode VARCHAR(80) NULL UNIQUE, " +
                    "expiry_date DATE NULL, " +
                    "created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, " +
                    "updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, " +
                    "PRIMARY KEY (product_id)) ENGINE=InnoDB");

            statement.executeUpdate("CREATE TABLE IF NOT EXISTS customers (" +
                    "customer_id INT NOT NULL AUTO_INCREMENT, " +
                    "customer_name VARCHAR(100) NOT NULL, " +
                    "mobile_number VARCHAR(30), " +
                    "email VARCHAR(100), " +
                    "address VARCHAR(255), " +
                    "created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, " +
                    "PRIMARY KEY (customer_id)) ENGINE=InnoDB");

            statement.executeUpdate("CREATE TABLE IF NOT EXISTS sales (" +
                    "sale_id INT NOT NULL AUTO_INCREMENT, " +
                    "user_id INT NULL, " +
                    "customer_id INT NULL, " +
                    "bill_number VARCHAR(50) NOT NULL UNIQUE, " +
                    "sale_date TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP, " +
                    "subtotal DECIMAL(12,2) NOT NULL DEFAULT 0, " +
                    "discount DECIMAL(12,2) NOT NULL DEFAULT 0, " +
                    "tax DECIMAL(12,2) NOT NULL DEFAULT 0, " +
                    "grand_total DECIMAL(12,2) NOT NULL DEFAULT 0, " +
                    "payment_method VARCHAR(20) NOT NULL DEFAULT 'Cash', " +
                    "PRIMARY KEY (sale_id), " +
                    "CONSTRAINT fk_sales_user FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE SET NULL, " +
                    "CONSTRAINT fk_sales_customer FOREIGN KEY (customer_id) REFERENCES customers(customer_id) ON DELETE SET NULL" +
                    ") ENGINE=InnoDB");

            statement.executeUpdate("CREATE TABLE IF NOT EXISTS sale_items (" +
                    "sale_item_id INT NOT NULL AUTO_INCREMENT, " +
                    "sale_id INT NOT NULL, " +
                    "product_id INT NOT NULL, " +
                    "quantity INT NOT NULL, " +
                    "unit_price DECIMAL(10,2) NOT NULL, " +
                    "line_total DECIMAL(12,2) NOT NULL, " +
                    "PRIMARY KEY (sale_item_id), " +
                    "CONSTRAINT fk_sale_items_sale FOREIGN KEY (sale_id) REFERENCES sales(sale_id) ON DELETE CASCADE, " +
                    "CONSTRAINT fk_sale_items_product FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE RESTRICT" +
                    ") ENGINE=InnoDB");

            statement.executeUpdate("CREATE TABLE IF NOT EXISTS stock (" +
                    "stock_id INT NOT NULL AUTO_INCREMENT, " +
                    "product_id INT NOT NULL UNIQUE, " +
                    "available_quantity INT NOT NULL DEFAULT 0, " +
                    "minimum_stock_level INT NOT NULL DEFAULT 0, " +
                    "last_updated TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP, " +
                    "updated_by_user_id INT NULL, " +
                    "PRIMARY KEY (stock_id), " +
                    "CONSTRAINT fk_stock_product FOREIGN KEY (product_id) REFERENCES products(product_id) ON DELETE CASCADE, " +
                    "CONSTRAINT fk_stock_user FOREIGN KEY (updated_by_user_id) REFERENCES users(user_id) ON DELETE SET NULL" +
                    ") ENGINE=InnoDB");

            migrateExistingSchema(connection);

            try (PreparedStatement categoryInsert = connection.prepareStatement(
                    "INSERT IGNORE INTO categories(category_name) VALUES (?)")) {
                String[] defaults = {"Grocery", "Beverages", "Dairy", "Snacks", "Personal Care", "Household", "Bakery"};
                for (String category : defaults) {
                    categoryInsert.setString(1, category);
                    categoryInsert.executeUpdate();
                }
            }

            try (PreparedStatement userInsert = connection.prepareStatement(
                    "INSERT IGNORE INTO users(username, password, role, full_name) VALUES (?, ?, ?, ?)")) {
                userInsert.setString(1, "admin");
                userInsert.setString(2, "1234");
                userInsert.setString(3, "ADMIN");
                userInsert.setString(4, "System Administrator");
                userInsert.executeUpdate();
            }

            try (PreparedStatement adminUpdate = connection.prepareStatement(
                    "UPDATE users SET password=?, role=?, full_name=? WHERE username=?")) {
                adminUpdate.setString(1, "1234");
                adminUpdate.setString(2, "ADMIN");
                adminUpdate.setString(3, "System Administrator");
                adminUpdate.setString(4, "admin");
                adminUpdate.executeUpdate();
            }

            try (PreparedStatement cashierInsert = connection.prepareStatement(
                    "INSERT IGNORE INTO users(username, password, role, full_name) VALUES (?, ?, ?, ?)")) {
                cashierInsert.setString(1, "cashier");
                cashierInsert.setString(2, "cashier");
                cashierInsert.setString(3, "CASHIER");
                cashierInsert.setString(4, "Default Cashier");
                cashierInsert.executeUpdate();
            }
        }
    }

    private static void migrateExistingSchema(Connection connection) throws SQLException {
        addColumnIfMissing(connection, "users", "full_name", "VARCHAR(100) NULL AFTER username");
        addColumnIfMissing(connection, "users", "created_at",
                "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP");
        addColumnIfMissing(connection, "customers", "mobile_number",
                "VARCHAR(30) NULL AFTER customer_name");
        addColumnIfMissing(connection, "customers", "email", "VARCHAR(100) NULL");
        addColumnIfMissing(connection, "customers", "created_at",
                "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP");
        if (columnExists(connection, "customers", "phone")) {
            try (PreparedStatement ps = connection.prepareStatement(
                    "UPDATE customers SET mobile_number=phone WHERE mobile_number IS NULL")) {
                ps.executeUpdate();
            }
        }
        addColumnIfMissing(connection, "products", "unit",
                "VARCHAR(30) NOT NULL DEFAULT 'pcs' AFTER category");
        addColumnIfMissing(connection, "products", "minimum_stock_level",
                "INT NOT NULL DEFAULT 0 AFTER stock");
        addColumnIfMissing(connection, "products", "product_photo_path",
                "VARCHAR(255) NULL AFTER minimum_stock_level");
        addColumnIfMissing(connection, "products", "barcode", "VARCHAR(80) NULL");
        addColumnIfMissing(connection, "products", "created_at",
                "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP");
        addColumnIfMissing(connection, "products", "updated_at",
                "TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP");
    }

    private static void addColumnIfMissing(Connection connection, String table,
                                           String column, String definition) throws SQLException {
        if (!columnExists(connection, table, column)) {
            try (Statement statement = connection.createStatement()) {
                statement.executeUpdate("ALTER TABLE `" + table + "` ADD COLUMN `" +
                        column + "` " + definition);
            }
        }
    }

    private static boolean columnExists(Connection connection, String table,
                                        String column) throws SQLException {
        String sql = "SELECT COUNT(*) FROM INFORMATION_SCHEMA.COLUMNS " +
                "WHERE TABLE_SCHEMA=DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=?";
        try (PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, table);
            ps.setString(2, column);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() && rs.getInt(1) > 0;
            }
        }
    }
}


