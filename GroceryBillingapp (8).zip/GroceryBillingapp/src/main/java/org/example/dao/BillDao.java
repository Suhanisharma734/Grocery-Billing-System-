package org.example.dao;

import org.example.database.DatabaseConnection;
import org.example.model.Bill;
import org.example.model.BillItem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BillDao {
    public int createBill(int userId, List<BillItem> items) throws SQLException {
        return createBill(userId, items, 0);
    }

    public int createBill(int userId, List<BillItem> items, double discountPercent) throws SQLException {
        if (items == null || items.isEmpty()) {
            throw new SQLException("A bill must contain at least one item.");
        }
        if (discountPercent < 0 || discountPercent > 100) {
            throw new SQLException("Discount must be between 0 and 100.");
        }

        try (Connection connection = DatabaseConnection.getConnection()) {
            connection.setAutoCommit(false);
            try {
                double subtotal = 0.0;
                Map<Integer, Integer> requestedQuantities = new HashMap<>();
                for (BillItem item : items) {
                    if (item.getQuantity() <= 0) {
                        throw new SQLException("Quantity must be greater than zero.");
                    }
                    requestedQuantities.put(item.getProductId(), requestedQuantities.getOrDefault(item.getProductId(), 0) + item.getQuantity());
                }

                String stockSql = "SELECT stock, product_name, price FROM products WHERE product_id=? FOR UPDATE";
                for (BillItem item : items) {
                    try (PreparedStatement ps = connection.prepareStatement(stockSql)) {
                        ps.setInt(1, item.getProductId());
                        try (ResultSet rs = ps.executeQuery()) {
                            if (!rs.next()) {
                                throw new SQLException("Product no longer exists: " + item.getProductName());
                            }
                            int stock = rs.getInt("stock");
                            if (requestedQuantities.get(item.getProductId()) > stock) {
                                throw new SQLException("Insufficient stock for " + rs.getString("product_name") + ". Available: " + stock);
                            }
                            item.setUnitPrice(rs.getDouble("price"));
                            subtotal += item.getQuantity() * item.getUnitPrice();
                        }
                    }
                }

                double discountAmount = subtotal * discountPercent / 100.0;
                double grandTotal = subtotal - discountAmount;
                int saleId;
                try (PreparedStatement ps = connection.prepareStatement(
                        "INSERT INTO sales(user_id, bill_number, subtotal, discount, tax, grand_total, payment_method) VALUES (?, ?, ?, ?, ?, ?, ?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    ps.setInt(1, userId);
                    ps.setString(2, "INV-" + System.currentTimeMillis());
                    ps.setDouble(3, subtotal);
                    ps.setDouble(4, discountAmount);
                    ps.setDouble(5, 0.0);
                    ps.setDouble(6, grandTotal);
                    ps.setString(7, "Cash");
                    ps.executeUpdate();
                    try (ResultSet keys = ps.getGeneratedKeys()) {
                        if (!keys.next()) {
                            throw new SQLException("Could not create bill.");
                        }
                        saleId = keys.getInt(1);
                    }
                }

                for (BillItem item : items) {
                    try (PreparedStatement ps = connection.prepareStatement(
                            "INSERT INTO sale_items(sale_id, product_id, quantity, unit_price, line_total) VALUES(?,?,?,?,?)")) {
                        ps.setInt(1, saleId);
                        ps.setInt(2, item.getProductId());
                        ps.setInt(3, item.getQuantity());
                        ps.setDouble(4, item.getUnitPrice());
                        ps.setDouble(5, item.getQuantity() * item.getUnitPrice());
                        ps.executeUpdate();
                    }
                    try (PreparedStatement ps = connection.prepareStatement(
                            "UPDATE products SET stock=stock-? WHERE product_id=?")) {
                        ps.setInt(1, item.getQuantity());
                        ps.setInt(2, item.getProductId());
                        ps.executeUpdate();
                    }
                }

                connection.commit();
                return saleId;
            } catch (SQLException ex) {
                connection.rollback();
                throw ex;
            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    public List<Bill> findAll() throws SQLException {
        List<Bill> bills = new ArrayList<>();
        String sql = "SELECT s.sale_id, s.user_id, u.username, s.sale_date, s.grand_total FROM sales s LEFT JOIN users u ON s.user_id=u.user_id ORDER BY s.sale_date DESC";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                bills.add(new Bill(
                        rs.getInt("sale_id"),
                        rs.getInt("user_id"),
                        rs.getString("username"),
                        rs.getTimestamp("sale_date"),
                        rs.getDouble("grand_total")
                ));
            }
        }
        return bills;
    }
}
