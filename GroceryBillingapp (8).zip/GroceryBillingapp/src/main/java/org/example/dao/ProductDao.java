package org.example.dao;

import org.example.database.DatabaseConnection;
import org.example.model.Product;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductDao {
    private Product map(ResultSet rs) throws SQLException {
        Product product = new Product(rs.getInt("product_id"), rs.getString("product_name"),
                rs.getString("category"), rs.getString("unit"), rs.getDouble("price"),
                rs.getInt("stock"), rs.getDate("expiry_date"), rs.getString("product_photo_path"));
        product.setMinimumStockLevel(rs.getInt("minimum_stock_level"));
        product.setBarcode(rs.getString("barcode"));
        return product;
    }

    private String selectSql() {
        return "SELECT product_id, product_name, category, unit, price, stock, minimum_stock_level, expiry_date, product_photo_path, barcode FROM products ";
    }

    public List<Product> findAll() throws SQLException { return search(""); }

    public List<Product> search(String text) throws SQLException {
        List<Product> products = new ArrayList<>();
        String sql = selectSql() + "WHERE product_name LIKE ? OR category LIKE ? OR CAST(product_id AS CHAR) LIKE ? OR COALESCE(barcode,'') LIKE ? ORDER BY product_name";
        try (Connection c = DatabaseConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            String value = text == null ? "" : text.trim();
            for (int i = 1; i <= 4; i++) ps.setString(i, "%" + value + "%");
            try (ResultSet rs = ps.executeQuery()) { while (rs.next()) products.add(map(rs)); }
        }
        return products;
    }

    public Product findByBarcode(String barcode) throws SQLException {
        if (barcode == null || barcode.isBlank()) return null;
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(selectSql() + "WHERE barcode=?")) {
            ps.setString(1, barcode.trim());
            try (ResultSet rs = ps.executeQuery()) { return rs.next() ? map(rs) : null; }
        }
    }

    public void save(Product p) throws SQLException {
        boolean insert = p.getProductId() == 0;
        String sql = insert
                ? "INSERT INTO products(product_name,category,unit,price,stock,expiry_date,minimum_stock_level,product_photo_path,barcode) VALUES(?,?,?,?,?,?,?,?,?)"
                : "UPDATE products SET product_name=?,category=?,unit=?,price=?,stock=?,expiry_date=?,minimum_stock_level=?,product_photo_path=?,barcode=? WHERE product_id=?";
        try (Connection c = DatabaseConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setString(1, p.getProductName()); ps.setString(2, p.getCategory()); ps.setString(3, p.getUnit());
            ps.setDouble(4, p.getPrice()); ps.setInt(5, p.getStock());
            if (p.getExpiryDate() == null) ps.setNull(6, Types.DATE); else ps.setDate(6, p.getExpiryDate());
            ps.setInt(7, p.getMinimumStockLevel()); ps.setString(8, p.getProductPhotoPath());
            ps.setString(9, p.getBarcode()); if (!insert) ps.setInt(10, p.getProductId());
            ps.executeUpdate();
        }
    }

    public void updateStock(int productId, int stock) throws SQLException {
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("UPDATE products SET stock=? WHERE product_id=?")) {
            ps.setInt(1, stock); ps.setInt(2, productId); ps.executeUpdate();
        }
    }

    public void delete(int productId) throws SQLException {
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("DELETE FROM products WHERE product_id=?")) {
            ps.setInt(1, productId); ps.executeUpdate();
        }
    }

    public int count() throws SQLException { return scalar("SELECT COUNT(*) FROM products"); }
    public int countInStock() throws SQLException { return scalar("SELECT COUNT(*) FROM products WHERE stock > 0"); }
    public int countCategories() throws SQLException {
        return scalar("SELECT COUNT(DISTINCT TRIM(category)) FROM products " +
                "WHERE category IS NOT NULL AND TRIM(category) <> ''");
    }
    public int countLowStock() throws SQLException {
        return scalar("SELECT COUNT(*) FROM products WHERE stock <= minimum_stock_level OR stock <= 0");
    }

    private int scalar(String sql) throws SQLException {
        try (Connection c = DatabaseConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getInt(1) : 0; }
    }

    public List<Product> findLowStockProducts() throws SQLException {
        List<Product> products = new ArrayList<>();
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(selectSql() + "WHERE stock <= minimum_stock_level OR stock <= 0 ORDER BY stock ASC");
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) products.add(map(rs));
        }
        return products;
    }
}
