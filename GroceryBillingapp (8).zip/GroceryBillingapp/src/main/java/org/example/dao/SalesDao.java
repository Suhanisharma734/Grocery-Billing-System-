package org.example.dao;

import org.example.database.DatabaseConnection;
import org.example.model.Sale;
import org.example.model.SaleItem;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class SalesDao {
    public double todayRevenue() throws SQLException { return scalar("SELECT COALESCE(SUM(grand_total),0) FROM sales WHERE DATE(sale_date)=CURRENT_DATE"); }
    public int todayBills() throws SQLException { return (int) scalar("SELECT COUNT(*) FROM sales WHERE DATE(sale_date)=CURRENT_DATE"); }
    public int todayItems() throws SQLException { return (int) scalar("SELECT COALESCE(SUM(si.quantity),0) FROM sale_items si JOIN sales s ON s.sale_id=si.sale_id WHERE DATE(s.sale_date)=CURRENT_DATE"); }
    public List<Object[]> topSellingProducts(int limit) throws SQLException {
        List<Object[]> rows = new ArrayList<>();
        String sql = "SELECT p.product_name, p.product_photo_path, SUM(si.quantity) units_sold, " +
                "SUM(si.line_total) revenue FROM sale_items si JOIN products p ON p.product_id=si.product_id " +
                "JOIN sales s ON s.sale_id=si.sale_id WHERE DATE(s.sale_date)=CURRENT_DATE " +
                "GROUP BY p.product_id, p.product_name, p.product_photo_path ORDER BY units_sold DESC LIMIT ?";
        try (Connection c = DatabaseConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql)) {
            ps.setInt(1, Math.max(1, limit));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) rows.add(new Object[]{rs.getString("product_name"),
                        rs.getString("product_photo_path"), rs.getInt("units_sold"), rs.getDouble("revenue")});
            }
        }
        return rows;
    }

    public List<Object[]> todayPaymentSplit() throws SQLException {
        List<Object[]> rows = new ArrayList<>();
        String sql = "SELECT payment_method, COALESCE(SUM(grand_total),0) total FROM sales " +
                "WHERE DATE(sale_date)=CURRENT_DATE GROUP BY payment_method ORDER BY total DESC";
        try (Connection c = DatabaseConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) rows.add(new Object[]{rs.getString("payment_method"), rs.getDouble("total")});
        }
        return rows;
    }
    private double scalar(String sql) throws SQLException {
        try (Connection c = DatabaseConnection.getConnection(); PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getDouble(1) : 0; }
    }
    public int saveSale(String billNumber, String customerName, String customerMobile,
                        String paymentMethod, double subtotal, double discount,
                        double tax, double grandTotal, List<SaleItem> items) throws SQLException {
        if (items == null || items.isEmpty()) {
            throw new SQLException("Sale cannot be empty.");
        }

        try (Connection connection = DatabaseConnection.getConnection()) {
            connection.setAutoCommit(false);
            try {
                int customerId = 0;
                if (customerName != null && !customerName.trim().isEmpty()) {
                    try (PreparedStatement customerPs = connection.prepareStatement(
                            "INSERT INTO customers(customer_name, mobile_number) VALUES(?, ?) ON DUPLICATE KEY UPDATE customer_name=VALUES(customer_name), mobile_number=VALUES(mobile_number)",
                            Statement.RETURN_GENERATED_KEYS)) {
                        customerPs.setString(1, customerName.trim());
                        customerPs.setString(2, customerMobile == null ? "" : customerMobile.trim());
                        customerPs.executeUpdate();
                        try (ResultSet resultSet = customerPs.getGeneratedKeys()) {
                            if (resultSet.next()) {
                                customerId = resultSet.getInt(1);
                            }
                        }
                        if (customerId == 0) {
                            try (PreparedStatement selectPs = connection.prepareStatement(
                                    "SELECT customer_id FROM customers WHERE customer_name=? ORDER BY customer_id DESC LIMIT 1")) {
                                selectPs.setString(1, customerName.trim());
                                try (ResultSet selectRs = selectPs.executeQuery()) {
                                    if (selectRs.next()) {
                                        customerId = selectRs.getInt("customer_id");
                                    }
                                }
                            }
                        }
                    }
                }

                int userId = 1;
                try (PreparedStatement userPs = connection.prepareStatement("SELECT user_id FROM users WHERE username='admin' LIMIT 1")) {
                    try (ResultSet rs = userPs.executeQuery()) {
                        if (rs.next()) userId = rs.getInt("user_id");
                    }
                }

                int saleId;
                try (PreparedStatement salePs = connection.prepareStatement(
                        "INSERT INTO sales(user_id, customer_id, bill_number, subtotal, discount, tax, grand_total, payment_method) VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                        Statement.RETURN_GENERATED_KEYS)) {
                    salePs.setInt(1, userId);
                    if (customerId == 0) salePs.setNull(2, java.sql.Types.INTEGER); else salePs.setInt(2, customerId);
                    salePs.setString(3, billNumber);
                    salePs.setDouble(4, subtotal);
                    salePs.setDouble(5, discount);
                    salePs.setDouble(6, tax);
                    salePs.setDouble(7, grandTotal);
                    salePs.setString(8, paymentMethod);
                    salePs.executeUpdate();
                    try (ResultSet keys = salePs.getGeneratedKeys()) {
                        if (!keys.next()) {
                            throw new SQLException("Could not create sale record.");
                        }
                        saleId = keys.getInt(1);
                    }
                }

                for (SaleItem item : items) {
                    try (PreparedStatement itemPs = connection.prepareStatement(
                            "INSERT INTO sale_items(sale_id, product_id, quantity, unit_price, line_total) VALUES (?, ?, ?, ?, ?)")) {
                        itemPs.setInt(1, saleId);
                        itemPs.setInt(2, item.getProductId());
                        itemPs.setInt(3, item.getQuantity());
                        itemPs.setDouble(4, item.getUnitPrice());
                        itemPs.setDouble(5, item.getLineTotal());
                        itemPs.executeUpdate();
                    }

                    try (PreparedStatement stockPs = connection.prepareStatement(
                            "UPDATE products SET stock = stock - ? WHERE product_id = ? AND stock >= ?")) {
                        stockPs.setInt(1, item.getQuantity());
                        stockPs.setInt(2, item.getProductId());
                        stockPs.setInt(3, item.getQuantity());
                        if (stockPs.executeUpdate() == 0) {
                            throw new SQLException("Stock changed while completing the sale. Please retry.");
                        }
                    }
                }
                connection.commit();
                return saleId;
            } catch (SQLException ex) {
                connection.rollback();
                throw ex;
            } finally {
                connection.setAutoCommit(true);
            }
        }
    }

    public List<Sale> findAll() throws SQLException {
        List<Sale> sales = new ArrayList<>();
        String sql = "SELECT s.sale_id, s.bill_number, s.sale_date, s.subtotal, s.discount, s.tax, s.grand_total, s.payment_method, " +
                "u.username, c.customer_name FROM sales s LEFT JOIN users u ON s.user_id = u.user_id " +
                "LEFT JOIN customers c ON s.customer_id = c.customer_id ORDER BY s.sale_date DESC";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Sale sale = new Sale();
                sale.setSaleId(rs.getInt("sale_id"));
                sale.setBillNumber(rs.getString("bill_number"));
                sale.setSaleDate(rs.getTimestamp("sale_date"));
                sale.setSubtotal(rs.getDouble("subtotal"));
                sale.setDiscount(rs.getDouble("discount"));
                sale.setTax(rs.getDouble("tax"));
                sale.setGrandTotal(rs.getDouble("grand_total"));
                sale.setPaymentMethod(rs.getString("payment_method"));
                sale.setCustomerName(rs.getString("customer_name"));
                sales.add(sale);
            }
        }
        return sales;
    }
}
