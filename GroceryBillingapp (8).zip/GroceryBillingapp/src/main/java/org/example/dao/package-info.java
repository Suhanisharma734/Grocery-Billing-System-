/**
 * Data Access Object classes for CRUD operations with MySQL.
 */
package org.example.dao;
