package org.example.dao;

import org.example.database.DatabaseConnection;
import org.example.model.Customer;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CustomerDao {
    public int count() throws SQLException {
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement("SELECT COUNT(*) FROM customers");
             ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getInt(1) : 0; }
    }
    public int countActive() throws SQLException {
        String sql = "SELECT COUNT(DISTINCT customer_id) FROM sales WHERE customer_id IS NOT NULL";
        try (Connection c = DatabaseConnection.getConnection();
             PreparedStatement ps = c.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) { return rs.next() ? rs.getInt(1) : 0; }
    }

    public List<Customer> findAll() throws SQLException {
        List<Customer> customers = new ArrayList<>();
        String sql = "SELECT customer_id, customer_name, mobile_number, email, address FROM customers ORDER BY customer_name";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Customer customer = new Customer();
                customer.setCustomerId(rs.getInt("customer_id"));
                customer.setCustomerName(rs.getString("customer_name"));
                customer.setMobileNumber(rs.getString("mobile_number"));
                customer.setEmail(rs.getString("email"));
                customer.setAddress(rs.getString("address"));
                customers.add(customer);
            }
        }
        return customers;
    }

    public List<Customer> findByName(String name) throws SQLException {
        List<Customer> customers = new ArrayList<>();
        String sql = "SELECT customer_id, customer_name, mobile_number, email, address " +
                "FROM customers WHERE LOWER(TRIM(customer_name))=LOWER(TRIM(?)) ORDER BY customer_id";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, name == null ? "" : name.trim());
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Customer customer = new Customer();
                    customer.setCustomerId(rs.getInt("customer_id"));
                    customer.setCustomerName(rs.getString("customer_name"));
                    customer.setMobileNumber(rs.getString("mobile_number"));
                    customer.setEmail(rs.getString("email"));
                    customer.setAddress(rs.getString("address"));
                    customers.add(customer);
                }
            }
        }
        return customers;
    }

    public void save(Customer customer) throws SQLException {
        String sql = customer.getCustomerId() == 0
                ? "INSERT INTO customers(customer_name, mobile_number, email, address) VALUES(?,?,?,?)"
                : "UPDATE customers SET customer_name=?, mobile_number=?, email=?, address=? WHERE customer_id=?";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, customer.getCustomerName());
            ps.setString(2, customer.getMobileNumber());
            ps.setString(3, customer.getEmail());
            ps.setString(4, customer.getAddress());
            if (customer.getCustomerId() != 0) {
                ps.setInt(5, customer.getCustomerId());
            }
            ps.executeUpdate();
        }
    }

    public void delete(int customerId) throws SQLException {
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement("DELETE FROM customers WHERE customer_id=?")) {
            ps.setInt(1, customerId);
            ps.executeUpdate();
        }
    }
}
