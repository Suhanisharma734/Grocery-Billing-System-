package org.example.dao;

import org.example.database.DatabaseConnection;
import org.example.model.User;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class UserDao {
    public User authenticate(String username, String password) throws SQLException {
        return authenticate(username, password, null);
    }

    public User authenticate(String username, String password, String role) throws SQLException {
        String sql = "SELECT user_id, username, password, role FROM users " +
                "WHERE LOWER(TRIM(username))=LOWER(?) LIMIT 1";
        try (Connection connection = DatabaseConnection.getConnection();
             PreparedStatement ps = connection.prepareStatement(sql)) {
            ps.setString(1, username == null ? "" : username.trim());
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()
                        && rs.getString("password") != null
                        && rs.getString("password").trim().equals(password == null ? "" : password.trim())
                        && (role == null || rs.getString("role") != null
                        && rs.getString("role").trim().equalsIgnoreCase(role.trim()))) {
                    return new User(rs.getInt("user_id"), rs.getString("username"),
                            rs.getString("password"), rs.getString("role"));
                }
            }
        }
        return null;
    }
}
