package org.example.dao;

import org.example.model.User;
import java.sql.SQLException;

/** Login-specific DAO kept separate from the rest of user operations. */
public class LoginDao {
    private final UserDao userDao = new UserDao();

    public User login(String username, String password) throws SQLException {
        return userDao.authenticate(username, password);
    }

    public User login(String username, String password, String role) throws SQLException {
        return userDao.authenticate(username, password, role);
    }
}
