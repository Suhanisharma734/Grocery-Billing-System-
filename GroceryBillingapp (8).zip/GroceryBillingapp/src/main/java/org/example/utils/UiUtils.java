package org.example.utils;

import javax.swing.*;
import java.awt.*;

public final class UiUtils {
    private UiUtils() { }
    public static void showError(Component parent, Exception ex) {
        JOptionPane.showMessageDialog(parent, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
    }
    public static void styleButton(AbstractButton button) {
        button.setFocusPainted(false);
        button.setFont(new Font("SansSerif", Font.BOLD, 13));
    }
}
