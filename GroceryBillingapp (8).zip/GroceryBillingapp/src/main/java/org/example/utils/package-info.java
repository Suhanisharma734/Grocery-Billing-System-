/**
 * Shared validation, formatting, and application helper classes.
 */
package org.example.utils;
