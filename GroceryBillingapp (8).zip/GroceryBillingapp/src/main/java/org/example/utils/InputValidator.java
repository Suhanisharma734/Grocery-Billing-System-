package org.example.utils;

public final class InputValidator {
    private InputValidator() { }
    public static String required(String value, String label) {
        if (value == null || value.trim().isEmpty()) throw new IllegalArgumentException(label + " is required.");
        return value.trim();
    }
    public static double positivePrice(String value) {
        try { double n = Double.parseDouble(value); if (n > 0) return n; }
        catch (NumberFormatException ignored) { }
        throw new IllegalArgumentException("Price must be a positive number.");
    }
    public static int nonNegativeInt(String value, String label) {
        try { int n = Integer.parseInt(value); if (n >= 0) return n; }
        catch (NumberFormatException ignored) { }
        throw new IllegalArgumentException(label + " must be a non-negative whole number.");
    }
    public static int positiveInt(String value, String label) {
        int n = nonNegativeInt(value, label);
        if (n > 0) return n;
        throw new IllegalArgumentException(label + " must be greater than zero.");
    }
}
