package org.example.utils;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.RenderingHints;
import java.awt.Font;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;

/** Small, reusable image loader for Swing thumbnails and previews. */
public final class ImageUtils {
    private static final int MAX_CACHE_ENTRIES = 128;
    private static final Map<String, ImageIcon> THUMBNAIL_CACHE =
            Collections.synchronizedMap(new LinkedHashMap<String, ImageIcon>(MAX_CACHE_ENTRIES, 0.75f, true) {
                @Override
                protected boolean removeEldestEntry(Map.Entry<String, ImageIcon> eldest) {
                    return size() > MAX_CACHE_ENTRIES;
                }
            });

    private ImageUtils() { }

    public static ImageIcon loadCover(String path, int width, int height) {
        if (width <= 0 || height <= 0) {
            throw new IllegalArgumentException("Image dimensions must be positive.");
        }
        String cacheKey = cacheKey(path, width, height);
        ImageIcon cached = THUMBNAIL_CACHE.get(cacheKey);
        if (cached != null) {
            return cached;
        }

        BufferedImage canvas = new BufferedImage(width, height, BufferedImage.TYPE_INT_ARGB);
        Graphics2D graphics = canvas.createGraphics();
        graphics.setColor(Color.WHITE);
        graphics.fillRect(0, 0, width, height);
        graphics.setRenderingHint(RenderingHints.KEY_INTERPOLATION,
                RenderingHints.VALUE_INTERPOLATION_BICUBIC);
        graphics.setRenderingHint(RenderingHints.KEY_RENDERING,
                RenderingHints.VALUE_RENDER_QUALITY);
        graphics.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);

        BufferedImage source = read(path);
        if (source == null) {
            graphics.setColor(new Color(236, 253, 245));
            graphics.fillRoundRect(1, 1, width - 2, height - 2, 14, 14);
            graphics.setColor(new Color(22, 101, 52));
            graphics.drawRoundRect(1, 1, width - 3, height - 3, 14, 14);
            graphics.setFont(new Font("SansSerif", Font.BOLD, Math.max(18, Math.min(30, width / 4))));
            String cart = "🛒";
            int cartWidth = graphics.getFontMetrics().stringWidth(cart);
            graphics.drawString(cart, Math.max(6, (width - cartWidth) / 2), height / 2 + 10);
            graphics.dispose();
            ImageIcon icon = new ImageIcon(canvas);
            THUMBNAIL_CACHE.put(cacheKey, icon);
            return icon;
        }

        double scale = Math.min((double) (width - 10) / source.getWidth(),
                (double) (height - 10) / source.getHeight());
        int scaledWidth = Math.max(1, (int) Math.round(source.getWidth() * scale));
        int scaledHeight = Math.max(1, (int) Math.round(source.getHeight() * scale));
        int x = (width - scaledWidth) / 2;
        int y = (height - scaledHeight) / 2;
        graphics.drawImage(source, x, y, scaledWidth, scaledHeight, null);
        graphics.dispose();
        ImageIcon icon = new ImageIcon(canvas);
        THUMBNAIL_CACHE.put(cacheKey, icon);
        return icon;
    }

    private static String cacheKey(String path, int width, int height) {
        if (path == null || path.isBlank()) {
            return "placeholder|" + width + "x" + height;
        }
        File file = new File(path);
        return path + "|" + file.lastModified() + "|" + width + "x" + height;
    }

    public static BufferedImage read(String path) {
        if (path == null || path.isBlank()) return null;
        try {
            File file = new File(path);
            return file.isFile() ? ImageIO.read(file) : null;
        } catch (IOException | SecurityException ex) {
            return null;
        }
    }
}
