/**
 * Plain Java model classes that represent application data.
 */
package org.example.model;
