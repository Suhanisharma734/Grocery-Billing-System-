package org.example.model;

public class BillItem {
    private int billItemId;
    private int billId;
    private int productId;
    private String productName;
    private int quantity;
    private double unitPrice;
    private double lineTotal;

    public BillItem() { }
    public BillItem(int productId, String productName, int quantity, double unitPrice) {
        this.productId = productId; this.productName = productName; this.quantity = quantity;
        this.unitPrice = unitPrice; this.lineTotal = quantity * unitPrice;
    }
    public int getBillItemId() { return billItemId; }
    public void setBillItemId(int value) { billItemId = value; }
    public int getBillId() { return billId; }
    public void setBillId(int value) { billId = value; }
    public int getProductId() { return productId; }
    public void setProductId(int value) { productId = value; }
    public String getProductName() { return productName; }
    public void setProductName(String value) { productName = value; }
    public int getQuantity() { return quantity; }
    public void setQuantity(int value) { quantity = value; lineTotal = value * unitPrice; }
    public double getUnitPrice() { return unitPrice; }
    public void setUnitPrice(double value) { unitPrice = value; lineTotal = quantity * value; }
    public double getLineTotal() { return lineTotal; }
    public void setLineTotal(double value) { lineTotal = value; }
}
