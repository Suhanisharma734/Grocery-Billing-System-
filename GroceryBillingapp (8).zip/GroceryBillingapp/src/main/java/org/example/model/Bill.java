package org.example.model;

import java.sql.Timestamp;

public class Bill {
    private int billId;
    private int userId;
    private String username;
    private Timestamp billDate;
    private double totalAmount;

    public Bill() { }
    public Bill(int billId, int userId, String username, Timestamp billDate, double totalAmount) {
        this.billId = billId; this.userId = userId; this.username = username;
        this.billDate = billDate; this.totalAmount = totalAmount;
    }
    public int getBillId() { return billId; }
    public void setBillId(int value) { billId = value; }
    public int getUserId() { return userId; }
    public void setUserId(int value) { userId = value; }
    public String getUsername() { return username; }
    public void setUsername(String value) { username = value; }
    public Timestamp getBillDate() { return billDate; }
    public void setBillDate(Timestamp value) { billDate = value; }
    public double getTotalAmount() { return totalAmount; }
    public void setTotalAmount(double value) { totalAmount = value; }
}
