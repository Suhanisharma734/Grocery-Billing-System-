package org.example.model;

import java.sql.Date;

public class Product {
    private int productId;
    private String productName;
    private String category;
    private String unit;
    private double price;
    private int stock;
    private int minimumStockLevel;
    private Date expiryDate;
    private String productPhotoPath;
    private String barcode;

    public Product() { }

    public Product(int productId, String productName, String category, double price, int stock, Date expiryDate) {
        this(productId, productName, category, "pcs", price, stock, expiryDate, null);
    }

    public Product(int productId, String productName, String category, String unit, double price, int stock, Date expiryDate) {
        this(productId, productName, category, unit, price, stock, expiryDate, null);
    }

    public Product(int productId, String productName, String category, double price, int stock, Date expiryDate, String productPhotoPath) {
        this(productId, productName, category, "pcs", price, stock, expiryDate, productPhotoPath);
    }

    public Product(int productId, String productName, String category, String unit, double price, int stock, Date expiryDate, String productPhotoPath) {
        this.productId = productId; this.productName = productName; this.category = category;
        this.unit = unit == null ? "pcs" : unit; this.price = price; this.stock = stock;
        this.expiryDate = expiryDate; this.productPhotoPath = productPhotoPath;
    }

    public int getProductId() { return productId; }
    public void setProductId(int value) { productId = value; }
    public String getProductName() { return productName; }
    public void setProductName(String value) { productName = value; }
    public String getCategory() { return category; }
    public void setCategory(String value) { category = value; }
    public String getUnit() { return unit == null ? "pcs" : unit; }
    public void setUnit(String value) { unit = value; }
    public double getPrice() { return price; }
    public void setPrice(double value) { price = value; }
    public int getStock() { return stock; }
    public void setStock(int value) { stock = value; }
    public int getMinimumStockLevel() { return minimumStockLevel; }
    public void setMinimumStockLevel(int value) { minimumStockLevel = Math.max(0, value); }
    public Date getExpiryDate() { return expiryDate; }
    public void setExpiryDate(Date value) { expiryDate = value; }
    public String getProductPhotoPath() { return productPhotoPath; }
    public void setProductPhotoPath(String value) { productPhotoPath = value; }
    public String getBarcode() { return barcode; }
    public void setBarcode(String value) { barcode = value; }
    @Override public String toString() { return productName + " (stock: " + stock + ", Rs. " + price + ")"; }
}
