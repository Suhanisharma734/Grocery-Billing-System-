package org.example;

import org.example.dao.ProductDao;
import org.example.dao.UserDao;
import org.example.database.DatabaseConnection;

import javax.imageio.ImageIO;
import javax.swing.*;
import javax.swing.border.AbstractBorder;
import javax.swing.border.EmptyBorder;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;
import javax.swing.filechooser.FileNameExtensionFilter;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.JTableHeader;
import javax.swing.table.TableCellEditor;
import javax.swing.table.TableCellRenderer;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.geom.RoundRectangle2D;
import java.awt.image.BufferedImage;
import java.awt.print.PrinterException;
import java.awt.print.PrinterJob;
import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.SQLException;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import org.example.utils.ImageUtils;
import com.formdev.flatlaf.FlatLightLaf;

public class Main {
    private static final Color BG = new Color(247, 250, 248);
    private static final Color SURFACE = new Color(255, 255, 255);
    private static final Color SOFT = new Color(234, 246, 238);
    private static final Color BORDER = new Color(229, 231, 235);
    private static final Color MUTED = new Color(107, 114, 128);
    private static final Color TEXT = new Color(31, 41, 55);
    private static final Color GREEN = new Color(46, 139, 87);
    private static final Color GREEN_DARK = new Color(35, 122, 75);
    private static final Color SIDEBAR_GREEN = new Color(15, 81, 50);
    private static final Color SIDEBAR_MUTED = new Color(190, 226, 205);
    private static final Color WHITE = Color.WHITE;
    private static final DecimalFormat MONEY = new DecimalFormat("₹ #,##0.00");
    private static final String PRODUCT_PHOTO_STORAGE_FOLDER = "product_photos";
    private static final long MAX_PRODUCT_PHOTO_SIZE_BYTES = 5L * 1024 * 1024;

    public static void main(String[] args) {
        try {
            FlatLightLaf.setup();
        } catch (Exception ignored) {
            try {
                UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
            } catch (Exception ignoredSystemLookAndFeel) {
                // Swing's default look and feel remains a safe fallback.
            }

        }
        SwingUtilities.invokeLater(() -> new GroceryBillingApp().setVisible(true));
    }

    static class GroceryBillingApp extends JFrame {
        private final CardLayout mainLayout = new CardLayout();
        private final JPanel mainCards = new JPanel(mainLayout);

        private final CardLayout sectionLayout = new CardLayout();
        private final JPanel sectionCards = new JPanel(sectionLayout);

        private final List<Product> productCatalog = new ArrayList<>();
        private final List<CartItem> cartItems = new ArrayList<>();
        private final List<CartItem> heldBill = new ArrayList<>();
        private final List<SaleRecord> salesHistory = new ArrayList<>();

        private final JTextField usernameField = new JTextField("admin");
        private final JPasswordField passwordField = new JPasswordField("1234");
        private JComboBox<String> roleCombo;
        private final JTextField customerNameField = new JTextField();
        private final JTextField customerMobileField = new JTextField();
        private JComboBox<String> customerSelector;
        private JTextField billingSearchField;
        private JTextField globalSearchField;
        private JLabel lblTotalProducts;
        private final JRadioButton cashPayment = new JRadioButton("Cash", true);
        private final JRadioButton cardPayment = new JRadioButton("Card");
        private final JRadioButton upiPayment = new JRadioButton("UPI");

        private final DefaultTableModel productModel = new DefaultTableModel(
                new Object[]{"#", "PRODUCT NAME", "CATEGORY", "UNIT", "PRICE", "ACTION"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 5;
            }
        };
        private final JTable productTable = new JTable(productModel);

        private final DefaultTableModel cartModel = new DefaultTableModel(
                new Object[]{"IMAGE", "ITEM NAME", "QTY", "PRICE", "TOTAL", "ACTION"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 2 || column == 5;
            }
        };
        private final JTable cartTable = new JTable(cartModel);

        private final DefaultTableModel productsPanelModel = new DefaultTableModel(
                new Object[]{"S.No.", "Product ID", "IMAGE", "PRODUCT NAME", "CATEGORY",
                        "PRICE", "UNIT", "STOCK QUANTITY", "ACTIONS"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 8;
            }
        };
        private final JTable productsPanelTable = new JTable(productsPanelModel);
        private JTextField productsPanelSearchField;
        private JComboBox<String> productsPanelCategoryFilter;
        private JPanel productsPanelState;
        private JLabel productsPanelCountLabel;
        private JLabel productsPanelTotalLabel;
        private JLabel productsPanelStockLabel;
        private JLabel productsPanelLowStockLabel;
        private JLabel productsPanelCategoriesLabel;
        private int productsPanelPage = 1;
        private static final int PRODUCTS_PAGE_SIZE = 8;
        private final List<Product> productsPanelFiltered = new ArrayList<>();
        private boolean updatingProductCategories;

        private final List<org.example.model.Customer> customerList = new ArrayList<>();
        private final List<org.example.model.Customer> filteredCustomers = new ArrayList<>();
        private static final int CUSTOMERS_PAGE_SIZE = 10;
        private int customersPage = 1;
        private JTextField customerSearchField;
        private JLabel customersCountLabel;
        private JLabel customersActiveLabel;
        private JLabel customersLoyaltyLabel;
        private JLabel customersTiersLabel;
        private JLabel customersRangeLabel;
        private JPanel customersTableState;
        private final DefaultTableModel customerModel = new DefaultTableModel(
                new Object[]{"S.No.", "Customer ID", "Customer Name", "Phone Number",
                        "Email", "Address", "ACTIONS"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 6;
            }
        };
        private final JTable customerTable = new JTable(customerModel);

        private final DefaultTableModel salesHistoryModel = new DefaultTableModel(
                new Object[]{"Invoice ID", "Date/Time", "Customer", "Total Amount", "Payment Method", "Receipt"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 5;
            }
        };
        private final JTable salesHistoryTable = new JTable(salesHistoryModel);

        private final DefaultTableModel stockModel = new DefaultTableModel(
                new Object[]{"IMAGE", "ITEM NAME", "CURRENT STOCK", "MINIMUM THRESHOLD", "STATUS", "UPDATE STOCK"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return column == 5;
            }
        };
        private final JTable stockTable = new JTable(stockModel);

        private final DefaultTableModel topProductsModel = new DefaultTableModel(
                new Object[]{"IMAGE", "PRODUCT", "UNITS SOLD", "REVENUE"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        private final JTable topProductsTable = new JTable(topProductsModel);

        private final DefaultTableModel paymentSplitModel = new DefaultTableModel(
                new Object[]{"Payment Method", "Total"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        private final JTable paymentSplitTable = new JTable(paymentSplitModel);

        private final JLabel subtotalLabel = new JLabel("₹ 0.00");
        private final JLabel discountLabel = new JLabel("₹ 0.00");
        private final JLabel taxLabel = new JLabel("₹ 0.00");
        private final JLabel grandTotalLabel = new JLabel("₹ 0.00");
        private final JTextField discountField = new JTextField("0.00");
        private final JTextField taxField = new JTextField("0.00");
        private final JLabel productsNoDataLabel = createEmptyStateLabel(
                "<html><div style='text-align:center'><font size='6'>▣</font><br><b>No products found</b><br><font color='#64748B'>Try changing your search or category filter.</font></div></html>");
        private final JPanel billingNoResultsPanel = createBillingEmptyState();
        private final JLabel cartEmptyLabel = createEmptyStateLabel("<html><div style='text-align:center'>No items in the bill yet.<br>Add products to start checkout.</div></html>");
        private JScrollPane productScrollPane;
        private JScrollPane cartScrollPane;
        private JLabel billingCountLabel;
        private JPanel billingProductGrid;
        private JPanel billingProductState;
        private JScrollPane billingProductScrollPane;
        private JPanel cartState;

        private String currentCategory = "All";
        private String currentSearchText = "";
        private final List<Product> filteredProducts = new ArrayList<>();

        GroceryBillingApp() {
            setTitle("GROCERY BILLING SYSTEM");
            setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            int frameWidth = Math.min(1450, screenSize.width - 40);
            int frameHeight = Math.min(900, screenSize.height - 60);
            setSize(frameWidth, frameHeight);
            setMinimumSize(new Dimension(Math.min(1050, frameWidth), Math.min(680, frameHeight)));
            setLocationRelativeTo(null);
            setContentPane(mainCards);
            getRootPane().setBorder(new EmptyBorder(12, 12, 12, 12));

            try {
                DatabaseConnection.initializeDatabase                                                                                       ();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Database connection failed: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            }

            seedProducts();
            seedDemoSales();
            buildScreens();
            installShortcuts();
            mainLayout.show(mainCards, "LOGIN");
        }

        private void buildScreens() {
            mainCards.add(buildLoginPanel(), "LOGIN");
            mainCards.add(buildDashboardPanel(), "DASHBOARD");
        }

        private JPanel buildLoginPanel() {
            JPanel root = new JPanel(new GridBagLayout());
            root.setBackground(BG);

            JPanel card = new JPanel();
            card.setBackground(SURFACE);
            card.setBorder(new RoundedBorder(26, new Color(255, 255, 255, 220), 1, true));
            card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
            card.setPreferredSize(new Dimension(500, 560));
            card.setMinimumSize(new Dimension(500, 560));
            card.setAlignmentX(Component.CENTER_ALIGNMENT);

            JPanel header = new JPanel(new BorderLayout(16, 0));
            header.setOpaque(false);
            header.setBorder(new EmptyBorder(0, 10, 0, 10));
            header.setAlignmentX(Component.CENTER_ALIGNMENT);
            header.setMaximumSize(new Dimension(440, 64));

            JLabel logo = new JLabel("🛒", SwingConstants.CENTER);
            logo.setOpaque(true);
            logo.setBackground(new Color(217, 249, 234));
            logo.setForeground(GREEN_DARK);
            logo.setFont(new Font("SansSerif", Font.BOLD, 30));
            logo.setPreferredSize(new Dimension(56, 56));
            logo.setMinimumSize(new Dimension(56, 56));
            logo.setBorder(new RoundedBorder(18, new Color(0, 168, 89, 35), 1, true));
            header.add(logo, BorderLayout.WEST);

            JLabel title = new JLabel("GROCERY BILLING SYSTEM");
            title.setForeground(TEXT);
            title.setFont(new Font("SansSerif", Font.BOLD, 24));
            title.setHorizontalAlignment(SwingConstants.LEFT);
            title.setHorizontalTextPosition(SwingConstants.LEFT);
            title.setBorder(new EmptyBorder(0, 0, 0, 0));
            header.add(title, BorderLayout.CENTER);

            card.add(Box.createVerticalStrut(28));
            card.add(header);
            card.add(Box.createVerticalStrut(32));

            JPanel form = new JPanel();
            form.setOpaque(false);
            form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
            form.setAlignmentX(Component.CENTER_ALIGNMENT);

            addLoginField(form, "Username", usernameField);
            addLoginField(form, "Password", passwordField);

            JLabel roleLabel = new JLabel("Role");
            roleLabel.setForeground(TEXT);
            roleLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            roleLabel.setAlignmentX(Component.LEFT_ALIGNMENT);
            roleLabel.setBorder(new EmptyBorder(10, 0, 6, 0));
            form.add(roleLabel);

            roleCombo = new JComboBox<>(new String[]{"Cashier", "Admin"});
            roleCombo.setBackground(WHITE);
            roleCombo.setForeground(TEXT);
            roleCombo.setFont(new Font("SansSerif", Font.PLAIN, 15));
            roleCombo.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDER, 1),
                    new EmptyBorder(10, 12, 10, 12)));
            roleCombo.setMaximumSize(new Dimension(340, 44));
            form.add(roleCombo);

            JButton loginButton = createPrimaryButton("LOGIN TO BILLING SYSTEM");
            loginButton.setAlignmentX(Component.CENTER_ALIGNMENT);
            loginButton.setPreferredSize(new Dimension(380, 52));
            loginButton.setMinimumSize(new Dimension(380, 52));
            loginButton.setMaximumSize(new Dimension(380, 52));
            loginButton.setMargin(new Insets(10, 18, 10, 18));
            loginButton.addActionListener(e -> handleLogin());
            form.add(Box.createVerticalStrut(20));
            form.add(loginButton);

            card.add(form);
            card.add(Box.createVerticalStrut(24));

            JPanel footer = new JPanel(new BorderLayout());
            footer.setOpaque(true);
            footer.setBackground(new Color(232, 252, 239));
            footer.setBorder(new EmptyBorder(14, 16, 14, 16));
            footer.setMaximumSize(new Dimension(340, 72));
            footer.setAlignmentX(Component.CENTER_ALIGNMENT);

            JLabel credentials = new JLabel("Demo credentials: admin / 1234 (Admin)");
            credentials.setForeground(new Color(0, 107, 63));
            credentials.setFont(new Font("SansSerif", Font.BOLD, 12));
            footer.add(credentials, BorderLayout.CENTER);

            card.add(footer);
            root.add(card);
            return root;
        }

        private void addLoginField(JPanel parent, String labelText, JComponent field) {
            JLabel label = new JLabel(labelText);
            label.setForeground(TEXT);
            label.setFont(new Font("SansSerif", Font.BOLD, 12));
            label.setAlignmentX(Component.LEFT_ALIGNMENT);
            label.setBorder(new EmptyBorder(10, 0, 6, 0));
            parent.add(label);

            field.setBackground(WHITE);
            field.setForeground(TEXT);
            field.setFont(new Font("SansSerif", Font.PLAIN, 15));
            field.setBorder(BorderFactory.createCompoundBorder(
                    BorderFactory.createLineBorder(BORDER, 1),
                    new EmptyBorder(12, 12, 12, 12)));
            field.setMaximumSize(new Dimension(340, 44));
            if (field instanceof JTextField tf) {
                tf.setCaretColor(TEXT);
            }
            if (field instanceof JPasswordField pf) {
                pf.setCaretColor(TEXT);
            }
            parent.add(field);
            parent.add(Box.createVerticalStrut(8));
        }

        private JPanel buildDashboardPanel() {
            JPanel root = new JPanel(new BorderLayout(18, 18));
            root.setBackground(BG);
            root.setBorder(new EmptyBorder(18, 18, 18, 18));

            JPanel sidebar = buildSidebar();
            JPanel dashboardContent = new org.example.ui.DashboardPanel();
            JPanel billingContent = buildBillingContent();
            JPanel productsContent = buildProductsPanel();
            JPanel customersContent = buildCustomersPanel();
            JPanel salesContent = buildSalesHistoryPanel();
            JPanel stockContent = buildStockPanel();
            JPanel reportsContent = buildReportsPanel();
            JPanel settingsContent = buildSettingsPanel();

            sectionCards.setBackground(BG);
            sectionCards.add(dashboardContent, "DASHBOARD");
            sectionCards.add(billingContent, "BILLING");
            sectionCards.add(productsContent, "PRODUCTS");
            sectionCards.add(customersContent, "CUSTOMERS");
            sectionCards.add(salesContent, "SALES");
            sectionCards.add(stockContent, "STOCK");
            sectionCards.add(reportsContent, "REPORTS");
            sectionCards.add(settingsContent, "SETTINGS");

            JPanel workspace = new JPanel(new BorderLayout(0, 12));
            workspace.setOpaque(false);
            workspace.add(buildGlobalHeader(), BorderLayout.NORTH);
            workspace.add(sectionCards, BorderLayout.CENTER);
            root.add(sidebar, BorderLayout.WEST);
            root.add(workspace, BorderLayout.CENTER);
            root.add(buildFooterBar(), BorderLayout.SOUTH);
            sectionLayout.show(sectionCards, "DASHBOARD");
            return root;
        }

        private JPanel buildGlobalHeader() {
            JPanel header = new JPanel();
            header.setOpaque(false);
            header.setLayout(new BoxLayout(header, BoxLayout.Y_AXIS));

            JPanel topPanel = new JPanel(new BorderLayout(12, 0));
            topPanel.setOpaque(false);
            topPanel.setBorder(new EmptyBorder(0, 4, 8, 4));
            JPanel brand = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
            brand.setOpaque(false);
            JLabel logo = new JLabel("+", SwingConstants.CENTER);
            logo.setOpaque(true);
            logo.setBackground(GREEN);
            logo.setForeground(WHITE);
            logo.setFont(new Font("SansSerif", Font.BOLD, 20));
            logo.setPreferredSize(new Dimension(34, 34));
            logo.setBorder(new RoundedBorder(10, GREEN, 1, true));
            JLabel title = new JLabel("GROCERY BILLING SYSTEM");
            title.setForeground(TEXT);
            title.setFont(new Font("SansSerif", Font.BOLD, 17));
            brand.add(logo);
            brand.add(title);
            topPanel.add(brand, BorderLayout.WEST);

            JPanel accountActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
            accountActions.setOpaque(false);
            JButton notifications = createSecondaryButton("Notifications");
            notifications.setForeground(TEXT);
            notifications.addActionListener(e -> showNotifications());
            JPanel notificationWrap = new JPanel(new BorderLayout());
            notificationWrap.setOpaque(false);
            notificationWrap.add(notifications, BorderLayout.CENTER);
            JLabel notificationBadge = new JLabel("3", SwingConstants.CENTER);
            notificationBadge.setOpaque(true);
            notificationBadge.setBackground(new Color(220, 38, 38));
            notificationBadge.setForeground(WHITE);
            notificationBadge.setFont(new Font("SansSerif", Font.BOLD, 10));
            notificationBadge.setBorder(new RoundedBorder(9, new Color(220, 38, 38), 1, true));
            notificationBadge.setPreferredSize(new Dimension(18, 18));
            notificationWrap.add(notificationBadge, BorderLayout.EAST);
            JButton profile = createSecondaryButton("Admin  ▾");
            profile.addActionListener(e -> JOptionPane.showMessageDialog(this,
                    "Signed in as Administrator\nRole: ADMIN", "Profile", JOptionPane.INFORMATION_MESSAGE));
            accountActions.add(notificationWrap);
            accountActions.add(profile);
            topPanel.add(accountActions, BorderLayout.EAST);
            header.add(topPanel);

            JPanel actionRow = new JPanel(new BorderLayout(12, 0));
            actionRow.setOpaque(false);
            globalSearchField = new JTextField();
            globalSearchField.setToolTipText("Search products by name, category or barcode");
            globalSearchField.setFont(new Font("SansSerif", Font.PLAIN, 14));
            globalSearchField.setBorder(BorderFactory.createCompoundBorder(
                    new RoundedBorder(14, BORDER, 1, true), new EmptyBorder(0, 14, 0, 14)));
            globalSearchField.setPreferredSize(new Dimension(0, 40));
            globalSearchField.addActionListener(e -> performGlobalSearch());
            actionRow.add(globalSearchField, BorderLayout.CENTER);

            JPanel quickActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
            quickActions.setOpaque(false);
            JButton newBill = createPrimaryButton("+  Add Product");
            newBill.addActionListener(e -> {
                sectionLayout.show(sectionCards, "BILLING");
                if (billingSearchField != null) billingSearchField.requestFocusInWindow();
            });
            JButton scan = createSecondaryButton("Scan Barcode");
            scan.addActionListener(e -> simulateScanAndAdd());
            JButton clear = createSecondaryButton("Clear");
            clear.addActionListener(e -> {
                if (billingSearchField != null) {
                    billingSearchField.setText("");
                    billingSearchField.requestFocusInWindow();
                }
            });
            quickActions.add(newBill);
            quickActions.add(scan);
            quickActions.add(clear);
            actionRow.add(quickActions, BorderLayout.EAST);
            header.add(actionRow);
            return header;
        }

        private JPanel buildDashboardOverview() {
            JPanel panel = new JPanel(new BorderLayout(16, 16));
            panel.setBackground(BG);
            panel.setBorder(new EmptyBorder(18, 18, 18, 18));
            JPanel heading = new JPanel(new BorderLayout());
            heading.setOpaque(false);
            JLabel title = new JLabel("Dashboard");
            title.setForeground(TEXT);
            title.setFont(new Font("SansSerif", Font.BOLD, 30));
            JLabel subtitle = new JLabel("A live view of today's register performance");
            subtitle.setForeground(MUTED);
            subtitle.setFont(new Font("SansSerif", Font.PLAIN, 14));
            JPanel copy = new JPanel();
            copy.setOpaque(false);
            copy.setLayout(new BoxLayout(copy, BoxLayout.Y_AXIS));
            copy.add(title);
            copy.add(Box.createVerticalStrut(4));
            copy.add(subtitle);
            heading.add(copy, BorderLayout.WEST);
            JButton start = createPrimaryButton("Open Billing  →");
            start.addActionListener(e -> sectionLayout.show(sectionCards, "BILLING"));
            heading.add(start, BorderLayout.EAST);
            double revenue = 0;
            int bills = 0;
            int lowStock = 0;
            try {
                org.example.dao.SalesDao salesDao = new org.example.dao.SalesDao();
                revenue = salesDao.todayRevenue();
                bills = salesDao.todayBills();
                ProductDao productDao = new ProductDao();
                lowStock = productDao.countLowStock();
            } catch (SQLException ignored) { }
            JPanel cards = new JPanel(new GridLayout(1, 4, 10, 10));
            cards.setOpaque(false);
            JPanel totalProductsCard = createStatCard("Total Products", "0", new Color(124, 58, 237));
            lblTotalProducts = (JLabel) totalProductsCard.getClientProperty("valueLabel");
            cards.add(totalProductsCard);
            cards.add(createStatCard("Today's Sales", MONEY.format(revenue), GREEN));
            cards.add(createStatCard("Low Stock Alert", String.valueOf(lowStock), new Color(217, 119, 6)));
            cards.add(createStatCard("Bills Today", String.valueOf(bills), new Color(37, 99, 235)));
            updateDashboardStats();
            JPanel top = new JPanel(new BorderLayout(0, 16));
            top.setOpaque(false);
            top.add(heading, BorderLayout.NORTH);
            top.add(cards, BorderLayout.SOUTH);
            panel.add(top, BorderLayout.NORTH);

            JPanel insight = new JPanel(new GridLayout(2, 2, 14, 14));
            insight.setOpaque(false);
            insight.add(createDashboardInsight("Quick actions",
                    "Create a bill, restock inventory, or review yesterday's performance.",
                    new String[]{"New Bill", "Products", "Reports"},
                    new String[]{"BILLING", "PRODUCTS", "REPORTS"}));
            insight.add(createDashboardInsight("Register status",
                    "Database-backed metrics refresh whenever you return to this dashboard.",
                    new String[]{"Refresh Data", "Low Stock", "Sales History"},
                    new String[]{"REFRESH", "STOCK", "SALES"}));
            insight.add(createDashboardTableCard("Low stock alert", new String[]{"Product", "Stock", "Status"},
                    loadLowStockRows(), "No low-stock products right now."));
            insight.add(createDashboardTableCard("Recent transactions", new String[]{"Bill", "Customer", "Amount"},
                    loadRecentSaleRows(), "No sales recorded yet."));
            panel.add(insight, BorderLayout.CENTER);
            return panel;
        }

        private void updateDashboardStats() {
            if (lblTotalProducts == null) {
                return;
            }
            try {
                int count = new ProductDao().count();
                lblTotalProducts.setText(String.valueOf(count));
            } catch (SQLException ex) {
                lblTotalProducts.setText("—");
                showToast("Unable to refresh dashboard product count");
            }
        }

        private List<Object[]> loadLowStockRows() {
            List<Object[]> rows = new ArrayList<>();
            try {
                for (org.example.model.Product product : new ProductDao().findLowStockProducts()) {
                    if (rows.size() == 6) break;
                    String status = product.getStock() <= 0 ? "Out of stock" : "Low stock";
                    rows.add(new Object[]{product.getProductName(), product.getStock(), status});
                }
            } catch (SQLException ignored) { }
            return rows;
        }

        private List<Object[]> loadRecentSaleRows() {
            List<Object[]> rows = new ArrayList<>();
            try {
                List<org.example.model.Sale> sales = new org.example.dao.SalesDao().findAll();
                for (int i = 0; i < Math.min(5, sales.size()); i++) {
                    org.example.model.Sale sale = sales.get(i);
                    rows.add(new Object[]{sale.getBillNumber(),
                            sale.getCustomerName() == null ? "Walk-in" : sale.getCustomerName(),
                            MONEY.format(sale.getGrandTotal())});
                }
            } catch (SQLException ignored) { }
            return rows;
        }

        private JPanel createDashboardTableCard(String title, String[] columns, List<Object[]> rows, String emptyText) {
            JPanel card = new JPanel(new BorderLayout(8, 8));
            card.setBackground(SURFACE);
            card.setBorder(BorderFactory.createCompoundBorder(new RoundedBorder(16, BORDER, 1, true),
                    new EmptyBorder(14, 14, 14, 14)));
            JLabel heading = new JLabel(title);
            heading.setForeground(TEXT);
            heading.setFont(new Font("SansSerif", Font.BOLD, 16));
            card.add(heading, BorderLayout.NORTH);
            if (rows.isEmpty()) {
                JLabel empty = new JLabel(emptyText, SwingConstants.CENTER);
                empty.setForeground(MUTED);
                empty.setFont(new Font("SansSerif", Font.PLAIN, 12));
                card.add(empty, BorderLayout.CENTER);
            } else {
                DefaultTableModel model = new DefaultTableModel(columns, 0) {
                    @Override public boolean isCellEditable(int row, int column) { return false; }
                };
                for (Object[] row : rows) model.addRow(row);
                JTable table = new JTable(model);
                styleTableWithHeader(table);
                table.setRowHeight(32);
                JScrollPane scroll = new JScrollPane(table);
                scroll.setBorder(null);
                card.add(scroll, BorderLayout.CENTER);
            }
            return card;
        }

        private JPanel createDashboardInsight(String title, String subtitle, String[] labels, String[] keys) {
            JPanel card = new JPanel(new BorderLayout(8, 12));
            card.setBackground(SURFACE);
            card.setBorder(BorderFactory.createCompoundBorder(new RoundedBorder(16, BORDER, 1, true),
                    new EmptyBorder(18, 18, 18, 18)));
            JLabel heading = new JLabel(title);
            heading.setForeground(TEXT);
            heading.setFont(new Font("SansSerif", Font.BOLD, 18));
            JLabel copy = new JLabel("<html><font color='#64748B'>" + subtitle + "</font></html>");
            JPanel buttons = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
            buttons.setOpaque(false);
            for (int i = 0; i < labels.length; i++) {
                JButton button = createSecondaryButton(labels[i]);
                String key = keys[i];
                button.addActionListener(e -> {
                    if ("REFRESH".equals(key)) {
                        seedProducts();
                        refreshStockTable();
                        refreshSalesHistoryTable();
                        showToast("Live data refreshed");
                    } else {
                        sectionLayout.show(sectionCards, key);
                    }
                });
                buttons.add(button);
            }
            JPanel body = new JPanel();
            body.setOpaque(false);
            body.setLayout(new BoxLayout(body, BoxLayout.Y_AXIS));
            body.add(heading);
            body.add(Box.createVerticalStrut(8));
            body.add(copy);
            card.add(body, BorderLayout.NORTH);
            card.add(buttons, BorderLayout.SOUTH);
            return card;
        }

        private JPanel buildFooterBar() {
            JPanel footer = new JPanel(new BorderLayout());
            footer.setBackground(BG);
            footer.setBorder(new EmptyBorder(8, 8, 0, 8));
            footer.setPreferredSize(new Dimension(0, 34));

            JLabel dateLabel = new JLabel(new java.text.SimpleDateFormat("dd MMM yyyy").format(new java.util.Date()));
            dateLabel.setForeground(MUTED);
            dateLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            footer.add(dateLabel, BorderLayout.WEST);

            JLabel invoiceLabel = new JLabel("Invoice No: —");
            invoiceLabel.setForeground(MUTED);
            invoiceLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            footer.add(invoiceLabel, BorderLayout.CENTER);

            JPanel status = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
            status.setOpaque(false);
            JLabel dot = new JLabel("●");
            dot.setForeground(GREEN);
            dot.setFont(new Font("SansSerif", Font.BOLD, 12));
            JLabel connected = new JLabel("Connected");
            connected.setForeground(GREEN_DARK);
            connected.setFont(new Font("SansSerif", Font.BOLD, 12));
            status.add(dot);
            status.add(connected);
            footer.add(status, BorderLayout.EAST);
            return footer;
        }

        private JPanel buildSidebar() {
            JPanel sidebar = new JPanel(new BorderLayout(0, 0));
            sidebar.setBackground(SIDEBAR_GREEN);
            sidebar.setBorder(new RoundedBorder(18, SIDEBAR_GREEN, 1, true));
            sidebar.setPreferredSize(new Dimension(238, 0));

            JPanel top = new JPanel();
            top.setOpaque(false);
            top.setLayout(new BoxLayout(top, BoxLayout.Y_AXIS));
            top.setBorder(new EmptyBorder(18, 18, 12, 18));

            JPanel brandRow = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
            brandRow.setOpaque(false);

            JLabel logoBox = new JLabel("🛒");
            logoBox.setOpaque(true);
            logoBox.setBackground(GREEN);
            logoBox.setForeground(WHITE);
            logoBox.setHorizontalAlignment(SwingConstants.CENTER);
            logoBox.setFont(new Font("SansSerif", Font.BOLD, 26));
            logoBox.setPreferredSize(new Dimension(42, 42));
            logoBox.setMinimumSize(new Dimension(42, 42));
            logoBox.setBorder(new RoundedBorder(12, GREEN, 1, true));

            JLabel brandName = new JLabel("GROCERY");
            brandName.setForeground(WHITE);
            brandName.setFont(new Font("SansSerif", Font.BOLD, 18));
            brandRow.add(logoBox);
            brandRow.add(brandName);

            JLabel brandSub = new JLabel("Billing System");
            brandSub.setForeground(SIDEBAR_MUTED);
            brandSub.setFont(new Font("SansSerif", Font.PLAIN, 12));
            brandSub.setBorder(new EmptyBorder(0, 8, 0, 0));

            top.add(Box.createVerticalStrut(8));
            top.add(brandRow);
            top.add(Box.createVerticalStrut(8));
            top.add(brandSub);

            JPanel navWrapper = new JPanel();
            navWrapper.setOpaque(false);
            navWrapper.setLayout(new BoxLayout(navWrapper, BoxLayout.Y_AXIS));
            navWrapper.setBorder(new EmptyBorder(18, 10, 8, 10));

            String[] labels = {"Dashboard", "Billing / POS", "Products", "Customers", "Sales History", "Stock", "Reports", "Settings"};
            String[] icons = {"⌂", "◉", "▣", "◌", "▤", "◫", "▥", "⚙"};
            JButton[] navButtons = new JButton[labels.length];
            for (int i = 0; i < labels.length; i++) {
                String sectionKey = switch (labels[i]) {
                    case "Dashboard" -> "DASHBOARD";
                    case "Billing / POS" -> "BILLING";
                    case "Products" -> "PRODUCTS";
                    case "Customers" -> "CUSTOMERS";
                    case "Sales History" -> "SALES";
                    case "Stock" -> "STOCK";
                    case "Reports" -> "REPORTS";
                    default -> "SETTINGS";
                };

                JButton btn = new JButton();
                btn.setText("");
                btn.setFocusPainted(false);
                btn.setOpaque(true);
                btn.setContentAreaFilled(true);
                btn.setBorderPainted(true);
                btn.setMargin(new Insets(0, 0, 0, 0));
                btn.setBackground(i == 0 ? GREEN : SIDEBAR_GREEN);
                btn.setForeground(WHITE);
                btn.setBorder(new RoundedBorder(12, i == 0 ? GREEN : SIDEBAR_GREEN, 1, true));
                btn.setFont(new Font("SansSerif", Font.BOLD, 14));
                btn.setPreferredSize(new Dimension(180, 46));
                btn.setMinimumSize(new Dimension(180, 46));
                btn.setMaximumSize(new Dimension(180, 46));
                btn.setHorizontalAlignment(SwingConstants.LEFT);
                btn.setLayout(new BorderLayout(8, 0));

                JPanel rowContent = new JPanel(new BorderLayout(8, 0));
                rowContent.setOpaque(false);
                rowContent.setBorder(new EmptyBorder(0, 12, 0, 12));

                JLabel iconLabel = new JLabel(icons[i]);
                iconLabel.setHorizontalAlignment(SwingConstants.CENTER);
                iconLabel.setForeground(i == 0 ? WHITE : SIDEBAR_MUTED);
                iconLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
                iconLabel.setPreferredSize(new Dimension(18, 18));
                rowContent.add(iconLabel, BorderLayout.WEST);

                JLabel textLabel = new JLabel(labels[i]);
                textLabel.setForeground(WHITE);
                textLabel.setFont(new Font("SansSerif", Font.BOLD, 14));
                textLabel.setHorizontalAlignment(SwingConstants.LEFT);
                rowContent.add(textLabel, BorderLayout.CENTER);

                btn.add(rowContent, BorderLayout.CENTER);

                btn.addActionListener(e -> {
                    sectionLayout.show(sectionCards, sectionKey);
                    if ("DASHBOARD".equals(sectionKey)) {
                        updateDashboardStats();
                    }
                    for (JButton navBtn : navButtons) {
                        if (navBtn != null) {
                            navBtn.setBackground(SIDEBAR_GREEN);
                            navBtn.setForeground(TEXT);
                            navBtn.setBorder(new RoundedBorder(12, SIDEBAR_GREEN, 1, true));
                            for (Component child : ((JPanel) navBtn.getComponent(0)).getComponents()) {
                                if (child instanceof JLabel label) {
                                    label.setForeground(label == ((JPanel) navBtn.getComponent(0)).getComponent(0)
                                            ? SIDEBAR_MUTED : WHITE);
                                }
                            }
                        }
                    }
                    btn.setBackground(GREEN);
                    btn.setForeground(WHITE);
                    btn.setBorder(new RoundedBorder(12, GREEN, 1, true));
                    JPanel selectedContent = (JPanel) btn.getComponent(0);
                    for (Component child : selectedContent.getComponents()) {
                        if (child instanceof JLabel label) label.setForeground(WHITE);
                    }
                });
                navButtons[i] = btn;
                navWrapper.add(btn);
                navWrapper.add(Box.createVerticalStrut(8));
            }
            navWrapper.add(Box.createVerticalGlue());

            JPanel footer = new JPanel(new BorderLayout());
            footer.setOpaque(false);
            footer.setBorder(new EmptyBorder(10, 0, 0, 0));
            footer.setPreferredSize(new Dimension(0, 72));
            footer.setMinimumSize(new Dimension(0, 72));
            JButton switchUser = createSecondaryButton("← Logout");
            switchUser.setPreferredSize(new Dimension(180, 42));
            switchUser.setMinimumSize(new Dimension(180, 42));
            switchUser.setMaximumSize(new Dimension(180, 42));
            switchUser.setHorizontalAlignment(SwingConstants.CENTER);
            switchUser.addActionListener(e -> handleLogout());
            footer.add(switchUser, BorderLayout.CENTER);

            JPanel summaryCard = new JPanel();
            summaryCard.setBackground(new Color(236, 253, 245));
            summaryCard.setLayout(new BoxLayout(summaryCard, BoxLayout.Y_AXIS));
            summaryCard.setBorder(BorderFactory.createCompoundBorder(
                    new RoundedBorder(16, new Color(167, 243, 208), 1, true),
                    new EmptyBorder(16, 16, 16, 16)));
            JLabel summaryTitle = new JLabel("TODAY'S SUMMARY");
            summaryTitle.setForeground(GREEN_DARK);
            summaryTitle.setFont(new Font("SansSerif", Font.BOLD, 11));
            summaryTitle.setAlignmentX(Component.LEFT_ALIGNMENT);
            double summaryRevenue = 0;
            int summaryBills = 0;
            int summaryItems = 0;
            int summaryCustomers = 0;
            try {
                org.example.dao.SalesDao salesDao = new org.example.dao.SalesDao();
                summaryRevenue = salesDao.todayRevenue();
                summaryBills = salesDao.todayBills();
                summaryItems = salesDao.todayItems();
                summaryCustomers = new org.example.dao.CustomerDao().count();
            } catch (SQLException ignored) { }
            JLabel amount = new JLabel(MONEY.format(summaryRevenue));
            amount.setForeground(TEXT);
            amount.setFont(new Font("SansSerif", Font.BOLD, 24));
            amount.setAlignmentX(Component.LEFT_ALIGNMENT);
            JLabel totalSales = new JLabel("Total sales");
            totalSales.setForeground(MUTED);
            totalSales.setFont(new Font("SansSerif", Font.PLAIN, 11));
            totalSales.setAlignmentX(Component.LEFT_ALIGNMENT);
            JPanel stats = new JPanel(new GridLayout(1, 3, 8, 0));
            stats.setOpaque(false);
            stats.add(makeMiniStat(String.valueOf(summaryBills), "Bills"));
            stats.add(makeMiniStat(String.valueOf(summaryItems), "Items"));
            stats.add(makeMiniStat(String.valueOf(summaryCustomers), "Customers"));
            summaryCard.add(summaryTitle);
            summaryCard.add(Box.createVerticalStrut(8));
            summaryCard.add(amount);
            summaryCard.add(Box.createVerticalStrut(3));
            summaryCard.add(totalSales);
            summaryCard.add(Box.createVerticalStrut(12));
            summaryCard.add(stats);

            JPanel bottomPanel = new JPanel();
            bottomPanel.setOpaque(false);
            bottomPanel.setLayout(new BoxLayout(bottomPanel, BoxLayout.Y_AXIS));
            bottomPanel.setBorder(new EmptyBorder(8, 12, 18, 12));
            bottomPanel.add(Box.createVerticalStrut(4));
            bottomPanel.add(summaryCard);

            sidebar.add(top, BorderLayout.NORTH);
            JScrollPane navScroll = new JScrollPane(navWrapper);
            navScroll.setBorder(null);
            navScroll.setViewportBorder(null);
            navScroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
            navScroll.setVerticalScrollBarPolicy(ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED);
            navScroll.getVerticalScrollBar().setUnitIncrement(12);
            navScroll.getViewport().setOpaque(false);
            navScroll.setOpaque(false);
            sidebar.add(navScroll, BorderLayout.CENTER);
            sidebar.add(bottomPanel, BorderLayout.SOUTH);
            return sidebar;
        }

        private JPanel makeMiniStat(String value, String label) {
            JPanel panel = new JPanel();
            panel.setOpaque(false);
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            JLabel valueLbl = new JLabel(value);
            valueLbl.setForeground(TEXT);
            valueLbl.setFont(new Font("SansSerif", Font.BOLD, 14));
            valueLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
            JLabel labelLbl = new JLabel(label);
            labelLbl.setForeground(MUTED);
            labelLbl.setFont(new Font("SansSerif", Font.PLAIN, 10));
            labelLbl.setAlignmentX(Component.CENTER_ALIGNMENT);
            panel.add(valueLbl);
            panel.add(labelLbl);
            return panel;
        }

        private JPanel buildProductsPanel() {
            JPanel panel = new JPanel(new BorderLayout(18, 18));
            panel.setBackground(BG);
            panel.setBorder(new EmptyBorder(22, 24, 22, 24));

            JPanel toolbar = new JPanel(new BorderLayout(12, 0));
            toolbar.setOpaque(false);

            productsPanelSearchField = new PlaceholderTextField(
                    "Search by product name, category, barcode or ID");
            productsPanelSearchField.setToolTipText("Search by product name, category, barcode or ID");
            productsPanelSearchField.setBorder(BorderFactory.createCompoundBorder(
                    new RoundedBorder(12, BORDER, 1, true), new EmptyBorder(0, 12, 0, 12)));
            productsPanelSearchField.setPreferredSize(new Dimension(0, 44));
            productsPanelSearchField.setFont(new Font("SansSerif", Font.PLAIN, 14));
            productsPanelSearchField.getDocument().addDocumentListener(new SimpleDocumentListener(() -> {
                productsPanelPage = 1;
                refreshProductPanelTable(productsPanelSearchField.getText(),
                        String.valueOf(productsPanelCategoryFilter.getSelectedItem()));
            }));
            toolbar.add(productsPanelSearchField, BorderLayout.CENTER);

            JPanel filterActions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
            filterActions.setOpaque(false);
            productsPanelCategoryFilter = new JComboBox<>();
            productsPanelCategoryFilter.setBackground(WHITE);
            productsPanelCategoryFilter.setForeground(TEXT);
            productsPanelCategoryFilter.setBorder(new RoundedBorder(10, BORDER, 1, true));
            productsPanelCategoryFilter.setPreferredSize(new Dimension(160, 42));
            productsPanelCategoryFilter.addActionListener(e -> {
                if (updatingProductCategories) {
                    return;
                }
                productsPanelPage = 1;
                refreshProductPanelTable(productsPanelSearchField.getText(),
                        String.valueOf(productsPanelCategoryFilter.getSelectedItem()));
            });

            JButton addButton = createPrimaryButton("+  Add New Product");
            addButton.addActionListener(e -> openAddProductDialog());
            JButton exportButton = createSecondaryButton("Export CSV");
            exportButton.addActionListener(e -> exportProductsCsv());
            JButton importButton = createSecondaryButton("Import CSV");
            importButton.addActionListener(e -> importProductsCsv());
            JButton clearSearchButton = createSecondaryButton("Clear");
            clearSearchButton.addActionListener(e -> productsPanelSearchField.setText(""));

            filterActions.add(productsPanelCategoryFilter);
            filterActions.add(clearSearchButton);
            filterActions.add(importButton);
            filterActions.add(exportButton);
            filterActions.add(addButton);
            toolbar.add(filterActions, BorderLayout.EAST);

            JPanel heading = new JPanel();
            heading.setOpaque(false);
            heading.setLayout(new BoxLayout(heading, BoxLayout.Y_AXIS));
            JLabel title = new JLabel("Products");
            title.setForeground(TEXT);
            title.setFont(new Font("SansSerif", Font.BOLD, 30));
            JLabel subtitle = new JLabel("Manage your grocery products and inventory");
            subtitle.setForeground(MUTED);
            subtitle.setFont(new Font("SansSerif", Font.PLAIN, 14));
            heading.add(title);
            heading.add(Box.createVerticalStrut(4));
            heading.add(subtitle);

            JPanel top = new JPanel(new BorderLayout(0, 18));
            top.setOpaque(false);
            top.add(toolbar, BorderLayout.NORTH);
            top.add(heading, BorderLayout.SOUTH);
            panel.add(top, BorderLayout.NORTH);

            JPanel summary = new JPanel(new GridLayout(1, 4, 12, 0));
            summary.setOpaque(false);
            productsPanelCountLabel = createSummaryValueLabel();
            productsPanelStockLabel = createSummaryValueLabel();
            productsPanelLowStockLabel = createSummaryValueLabel();
            productsPanelCategoriesLabel = createSummaryValueLabel();
            summary.add(createProductSummaryCard("▣", "Total Products", productsPanelCountLabel, new Color(220, 252, 231)));
            summary.add(createProductSummaryCard("▱", "In Stock", productsPanelStockLabel, new Color(219, 234, 254)));
            summary.add(createProductSummaryCard("⚠", "Low Stock", productsPanelLowStockLabel, new Color(254, 243, 199)));
            summary.add(createProductSummaryCard("▤", "Categories", productsPanelCategoriesLabel, new Color(243, 232, 255)));
            styleProductsPanelTable(productsPanelTable);
            JScrollPane scroll = new JScrollPane(productsPanelTable);
            scroll.setBorder(BorderFactory.createEmptyBorder());
            scroll.setViewportBorder(null);
            scroll.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            scroll.getVerticalScrollBar().setUnitIncrement(12);
            JPanel tableContent = new JPanel(new CardLayout());
            tableContent.setBackground(SURFACE);
            tableContent.setBorder(new EmptyBorder(8, 0, 0, 0));
            tableContent.add(scroll, "TABLE");
            tableContent.add(productsNoDataLabel, "EMPTY");
            productsNoDataLabel.setHorizontalAlignment(SwingConstants.CENTER);
            productsNoDataLabel.setForeground(MUTED);

            JPanel pagination = new JPanel(new BorderLayout());
            pagination.setOpaque(false);
            productsPanelTotalLabel = new JLabel();
            productsPanelTotalLabel.setForeground(MUTED);
            productsPanelTotalLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
            pagination.add(productsPanelTotalLabel, BorderLayout.WEST);
            JPanel pageButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 5, 0));
            pageButtons.setOpaque(false);
            JButton previous = createPageButton("<");
            JButton next = createPageButton(">");
            JLabel pageNumber = new JLabel();
            pageNumber.setForeground(TEXT);
            pageNumber.setFont(new Font("SansSerif", Font.BOLD, 12));
            previous.addActionListener(e -> {
                if (productsPanelPage > 1) {
                    productsPanelPage--;
                    refreshProductPanelTable(productsPanelSearchField.getText(), String.valueOf(productsPanelCategoryFilter.getSelectedItem()));
                }
            });
            next.addActionListener(e -> {
                int pages = Math.max(1, (int) Math.ceil(productsPanelFiltered.size() / (double) PRODUCTS_PAGE_SIZE));
                if (productsPanelPage < pages) {
                    productsPanelPage++;
                    refreshProductPanelTable(productsPanelSearchField.getText(), String.valueOf(productsPanelCategoryFilter.getSelectedItem()));
                }
            });
            pageButtons.add(previous);
            pageButtons.add(pageNumber);
            pageButtons.add(next);
            pagination.add(pageButtons, BorderLayout.EAST);

            JPanel tableWrap = new JPanel(new BorderLayout(0, 12));
            tableWrap.setBackground(SURFACE);
            tableWrap.setBorder(BorderFactory.createCompoundBorder(
                    new RoundedBorder(16, BORDER, 1, true), new EmptyBorder(10, 14, 12, 14)));
            tableWrap.add(tableContent, BorderLayout.CENTER);
            tableWrap.add(pagination, BorderLayout.SOUTH);

            JPanel body = new JPanel(new BorderLayout(0, 14));
            body.setOpaque(false);
            body.add(summary, BorderLayout.NORTH);
            body.add(tableWrap, BorderLayout.CENTER);
            panel.add(body, BorderLayout.CENTER);
            productsPanelState = tableContent;
            tableContent.putClientProperty("paginationLabel", pageNumber);
            tableContent.putClientProperty("previousButton", previous);
            tableContent.putClientProperty("nextButton", next);
            refreshProductPanelTable("", "All");
            updateProductSummary();
            return panel;
        }

        private void exportProductsCsv() {
            JFileChooser chooser = new JFileChooser();
            chooser.setSelectedFile(new File("products-export.csv"));
            if (chooser.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) return;
            try {
                StringBuilder csv = new StringBuilder("id,name,category,unit,price,stock,barcode\n");
                for (Product p : productCatalog) {
                    csv.append(p.getId()).append(",\"").append(p.getName().replace("\"", "\"\"")).append("\",\"")
                            .append(p.getCategory()).append("\",").append(p.getUnit()).append(",")
                            .append(p.getPrice()).append(",").append(p.getStock()).append(",")
                            .append(p.getBarcode() == null ? "" : p.getBarcode()).append("\n");
                }
                Files.writeString(chooser.getSelectedFile().toPath(), csv.toString());
                showToast("Products exported successfully");
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Unable to export products: " + ex.getMessage(),
                        "Export", JOptionPane.ERROR_MESSAGE);
            }
        }

        private void importProductsCsv() {
            JFileChooser chooser = new JFileChooser();
            if (chooser.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) return;
            try {
                List<String> lines = Files.readAllLines(chooser.getSelectedFile().toPath());
                int imported = 0;
                for (int i = 1; i < lines.size(); i++) {
                    String[] values = lines.get(i).split(",", -1);
                    if (values.length < 6) continue;
                    org.example.model.Product p = new org.example.model.Product();
                    p.setProductName(values[1].replace("\"", "").trim());
                    p.setCategory(values[2].replace("\"", "").trim());
                    p.setUnit(values[3].trim());
                    p.setPrice(Double.parseDouble(values[4].trim()));
                    p.setStock(Integer.parseInt(values[5].trim()));
                    if (values.length > 6 && !values[6].trim().isEmpty()) p.setBarcode(values[6].trim());
                    new ProductDao().save(p);
                    imported++;
                }
                seedProducts();
                showToast(imported + " products imported");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Import failed. Use the exported CSV format.",
                        "Import", JOptionPane.ERROR_MESSAGE);
            }
        }

        private JLabel createSummaryValueLabel() {
            JLabel label = new JLabel("0");
            label.setForeground(TEXT);
            label.setFont(new Font("SansSerif", Font.BOLD, 24));
            return label;
        }

        private JPanel createProductSummaryCard(String icon, String title, JLabel value, Color iconBackground) {
            JPanel card = new JPanel(new BorderLayout(12, 0));
            card.setBackground(SURFACE);
            card.setBorder(BorderFactory.createCompoundBorder(new RoundedBorder(14, BORDER, 1, true),
                    new EmptyBorder(14, 16, 14, 16)));
            JLabel iconLabel = new JLabel(icon, SwingConstants.CENTER);
            iconLabel.setOpaque(true);
            iconLabel.setBackground(iconBackground);
            iconLabel.setForeground(GREEN_DARK);
            iconLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
            iconLabel.setPreferredSize(new Dimension(42, 42));
            iconLabel.setBorder(new RoundedBorder(21, iconBackground, 1, true));
            JPanel text = new JPanel();
            text.setOpaque(false);
            text.setLayout(new BoxLayout(text, BoxLayout.Y_AXIS));
            JLabel titleLabel = new JLabel(title);
            titleLabel.setForeground(MUTED);
            titleLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
            text.add(value);
            text.add(Box.createVerticalStrut(2));
            text.add(titleLabel);
            card.add(iconLabel, BorderLayout.WEST);
            card.add(text, BorderLayout.CENTER);
            return card;
        }

        private JButton createPageButton(String text) {
            JButton button = new JButton(text);
            button.setFocusPainted(false);
            button.setForeground(TEXT);
            button.setBackground(WHITE);
            button.setFont(new Font("SansSerif", Font.BOLD, 12));
            button.setBorder(new RoundedBorder(8, BORDER, 1, true));
            button.setPreferredSize(new Dimension(32, 30));
            return button;
        }

        private static final class PlaceholderTextField extends JTextField {
            private final String placeholder;

            private PlaceholderTextField(String placeholder) {
                this.placeholder = placeholder;
            }

            @Override
            protected void paintComponent(Graphics graphics) {
                super.paintComponent(graphics);
                if (!getText().isEmpty()) {
                    return;
                }
                Graphics2D g = (Graphics2D) graphics.create();
                g.setColor(MUTED);
                g.setFont(getFont());
                FontMetrics metrics = g.getFontMetrics();
                Insets insets = getInsets();
                int baseline = (getHeight() - metrics.getHeight()) / 2 + metrics.getAscent();
                g.drawString(placeholder, insets.left + 2, baseline);
                g.dispose();
            }
        }

        private void updateProductSummary() {
            if (productsPanelCountLabel == null) {
                return;
            }
            try {
                ProductDao productDao = new ProductDao();
                productsPanelCountLabel.setText(String.valueOf(productDao.count()));
                productsPanelStockLabel.setText(String.valueOf(productDao.countInStock()));
                productsPanelLowStockLabel.setText(String.valueOf(productDao.countLowStock()));
                productsPanelCategoriesLabel.setText(String.valueOf(productDao.countCategories()));
            } catch (SQLException ex) {
                productsPanelCountLabel.setText("—");
                productsPanelStockLabel.setText("—");
                productsPanelLowStockLabel.setText("—");
                productsPanelCategoriesLabel.setText("—");
            }
        }

        private void updateProductCategories() {
            if (productsPanelCategoryFilter == null) {
                return;
            }
            updatingProductCategories = true;
            String selected = String.valueOf(productsPanelCategoryFilter.getSelectedItem());
            java.util.Set<String> categories = new java.util.TreeSet<>(String.CASE_INSENSITIVE_ORDER);
            for (Product product : productCatalog) {
                if (product.getCategory() != null && !product.getCategory().isBlank()) {
                    categories.add(product.getCategory());
                }
            }
            productsPanelCategoryFilter.removeAllItems();
            productsPanelCategoryFilter.addItem("All");
            for (String category : categories) {
                productsPanelCategoryFilter.addItem(category);
            }
            productsPanelCategoryFilter.setSelectedItem(categories.contains(selected) ? selected : "All");
            updatingProductCategories = false;
        }

        private void refreshProductPanelTable(String searchText, String category) {
            String query = searchText == null ? "" : searchText.trim().toLowerCase();
            updateProductCategories();
            Object selected = productsPanelCategoryFilter == null
                    ? category : productsPanelCategoryFilter.getSelectedItem();
            String selectedCategory = selected == null ? "All" : String.valueOf(selected);
            productsPanelFiltered.clear();
            for (Product product : productCatalog) {
                String productCategory = product.getCategory() == null ? "" : product.getCategory();
                String productName = product.getName() == null ? "" : product.getName();
                boolean matchesCategory = "All".equals(selectedCategory) || productCategory.equalsIgnoreCase(selectedCategory);
                boolean matchesSearch = query.isEmpty() || productName.toLowerCase().contains(query)
                        || productCategory.toLowerCase().contains(query)
                        || String.valueOf(product.getId()).contains(query)
                                || (product.getBarcode() != null && product.getBarcode().toLowerCase().contains(query));
                if (matchesCategory && matchesSearch) {
                    productsPanelFiltered.add(product);
                }
            }
            int pages = Math.max(1, (int) Math.ceil(productsPanelFiltered.size() / (double) PRODUCTS_PAGE_SIZE));
            productsPanelPage = Math.min(productsPanelPage, pages);
            int from = Math.min((productsPanelPage - 1) * PRODUCTS_PAGE_SIZE, productsPanelFiltered.size());
            int to = Math.min(from + PRODUCTS_PAGE_SIZE, productsPanelFiltered.size());
            productsPanelModel.setRowCount(0);
            for (int i = from; i < to; i++) {
                Product product = productsPanelFiltered.get(i);
                productsPanelModel.addRow(new Object[]{i + 1, product.getId(), "", product.getName(),
                        product.getCategory(), MONEY.format(product.getPrice()), product.getUnit(),
                        product.getStock(), ""});
            }
            productsNoDataLabel.setVisible(productsPanelModel.getRowCount() == 0);
            productsPanelTable.setVisible(productsPanelModel.getRowCount() > 0);
            CardLayout stateLayout = (CardLayout) productsPanelState.getLayout();
            stateLayout.show(productsPanelState, productsPanelModel.getRowCount() == 0 ? "EMPTY" : "TABLE");
            if (productsPanelTable.getColumnModel().getColumnCount() > 8) {
                productsPanelTable.getColumnModel().getColumn(2).setCellRenderer(new ProductsImageCellRenderer());
                productsPanelTable.getColumnModel().getColumn(4).setCellRenderer(new ProductsCategoryBadgeRenderer());
                productsPanelTable.getColumnModel().getColumn(7).setCellRenderer(new ProductsStockQuantityRenderer());
                productsPanelTable.getColumnModel().getColumn(8).setCellRenderer(new ProductActionRenderer());
                productsPanelTable.getColumnModel().getColumn(8).setCellEditor(new ProductActionEditor());
            }
            productsPanelTotalLabel.setText(productsPanelFiltered.isEmpty() ? "No products to display"
                    : "Showing " + (from + 1) + " to " + to + " of " + productsPanelFiltered.size() + " products");
            JLabel pageNumber = (JLabel) productsPanelState.getClientProperty("paginationLabel");
            JButton previous = (JButton) productsPanelState.getClientProperty("previousButton");
            JButton next = (JButton) productsPanelState.getClientProperty("nextButton");
            pageNumber.setText(productsPanelFiltered.isEmpty() ? "0 / 0"
                    : productsPanelPage + " / " + pages);
            previous.setVisible(productsPanelFiltered.size() > PRODUCTS_PAGE_SIZE);
            next.setVisible(productsPanelFiltered.size() > PRODUCTS_PAGE_SIZE);
            pageNumber.setVisible(productsPanelFiltered.size() > PRODUCTS_PAGE_SIZE);
            previous.setEnabled(productsPanelPage > 1);
            next.setEnabled(productsPanelPage < pages);
        }

        private JPanel buildCustomersPanel() {
            JPanel panel = new JPanel(new BorderLayout(16, 14));
            panel.setBackground(BG);
            panel.setBorder(new EmptyBorder(20, 22, 20, 22));

            JPanel heading = new JPanel();
            heading.setOpaque(false);
            heading.setLayout(new BoxLayout(heading, BoxLayout.Y_AXIS));
            JLabel title = new JLabel("Customers");
            title.setForeground(TEXT);
            title.setFont(new Font("SansSerif", Font.BOLD, 30));
            JLabel subtitle = new JLabel("Manage customer records and keep contact details up to date");
            subtitle.setForeground(MUTED);
            subtitle.setFont(new Font("SansSerif", Font.PLAIN, 14));
            heading.add(title);
            heading.add(Box.createVerticalStrut(4));
            heading.add(subtitle);

            JPanel toolbar = new JPanel(new BorderLayout(12, 0));
            toolbar.setOpaque(false);
            customerSearchField = new PlaceholderTextField(
                    "Search by Customer Name, Phone Number or Customer ID");
            customerSearchField.setToolTipText("Search by Customer Name, Phone Number or Customer ID");
            customerSearchField.setBorder(BorderFactory.createCompoundBorder(
                    new RoundedBorder(12, BORDER, 1, true), new EmptyBorder(0, 12, 0, 12)));
            customerSearchField.setPreferredSize(new Dimension(0, 44));
            customerSearchField.setFont(new Font("SansSerif", Font.PLAIN, 14));
            customerSearchField.getDocument().addDocumentListener(new SimpleDocumentListener(() -> {
                customersPage = 1;
                refreshCustomerTable();
            }));
            toolbar.add(customerSearchField, BorderLayout.CENTER);

            JButton clearButton = createSecondaryButton("Clear Search");
            clearButton.addActionListener(e -> customerSearchField.setText(""));
            JButton addButton = createPrimaryButton("Add Customer");
            addButton.addActionListener(e -> openCustomerDialog(null));
            JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
            actions.setOpaque(false);
            actions.add(clearButton);
            actions.add(addButton);
            toolbar.add(actions, BorderLayout.EAST);

            customersCountLabel = createSummaryValueLabel();
            customersActiveLabel = createSummaryValueLabel();
            customersLoyaltyLabel = new JLabel("Not tracked");
            customersTiersLabel = new JLabel("Not configured");
            for (JLabel label : new JLabel[]{customersLoyaltyLabel, customersTiersLabel}) {
                label.setForeground(TEXT);
                label.setFont(new Font("SansSerif", Font.BOLD, 14));
            }
            customersLoyaltyLabel.setToolTipText("Loyalty points are not stored in the existing customer database.");
            customersTiersLabel.setToolTipText("Customer tiers are not stored in the existing customer database.");

            JPanel summary = new JPanel(new GridLayout(1, 4, 12, 0));
            summary.setOpaque(false);
            summary.add(createProductSummaryCard("◉", "Total Customers",
                    customersCountLabel, new Color(220, 252, 231)));
            summary.add(createProductSummaryCard("✓", "Active Customers",
                    customersActiveLabel, new Color(219, 234, 254)));
            summary.add(createProductSummaryCard("★", "Total Loyalty Points",
                    customersLoyaltyLabel, new Color(254, 243, 199)));
            summary.add(createProductSummaryCard("◆", "Customer Tiers",
                    customersTiersLabel, new Color(243, 232, 255)));

            JPanel top = new JPanel(new BorderLayout(0, 14));
            top.setOpaque(false);
            top.add(heading, BorderLayout.NORTH);
            top.add(toolbar, BorderLayout.CENTER);
            top.add(summary, BorderLayout.SOUTH);
            panel.add(top, BorderLayout.NORTH);

            styleCustomerTable(customerTable);
            JScrollPane scroll = new JScrollPane(customerTable,
                    ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                    ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);
            scroll.setBorder(null);
            scroll.setViewportBorder(null);
            scroll.getViewport().setBackground(SURFACE);
            scroll.getVerticalScrollBar().setUnitIncrement(14);

            JPanel pagination = new JPanel(new BorderLayout());
            pagination.setOpaque(false);
            customersRangeLabel = new JLabel("Loading customers...");
            customersRangeLabel.setForeground(MUTED);
            customersRangeLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
            pagination.add(customersRangeLabel, BorderLayout.WEST);
            JPanel pageButtons = new JPanel(new FlowLayout(FlowLayout.RIGHT, 6, 0));
            pageButtons.setOpaque(false);
            JButton previous = createPageButton("<");
            JButton next = createPageButton(">");
            JLabel pageNumber = new JLabel();
            pageNumber.setForeground(TEXT);
            pageNumber.setFont(new Font("SansSerif", Font.BOLD, 12));
            previous.addActionListener(e -> {
                if (customersPage > 1) {
                    customersPage--;
                    refreshCustomerTable();
                }
            });
            next.addActionListener(e -> {
                int pages = Math.max(1,
                        (int) Math.ceil(filteredCustomers.size() / (double) CUSTOMERS_PAGE_SIZE));
                if (customersPage < pages) {
                    customersPage++;
                    refreshCustomerTable();
                }
            });
            pageButtons.add(previous);
            pageButtons.add(pageNumber);
            pageButtons.add(next);
            pagination.add(pageButtons, BorderLayout.EAST);

            JPanel tableWrap = new JPanel(new BorderLayout(0, 10));
            tableWrap.setBackground(SURFACE);
            tableWrap.setBorder(BorderFactory.createCompoundBorder(
                    new RoundedBorder(16, BORDER, 1, true), new EmptyBorder(10, 14, 12, 14)));
            tableWrap.add(scroll, BorderLayout.CENTER);
            tableWrap.add(pagination, BorderLayout.SOUTH);
            panel.add(tableWrap, BorderLayout.CENTER);

            customersTableState = tableWrap;
            tableWrap.putClientProperty("paginationLabel", pageNumber);
            tableWrap.putClientProperty("previousButton", previous);
            tableWrap.putClientProperty("nextButton", next);
            loadCustomerData();
            return panel;
        }

        private void styleCustomerTable(JTable table) {
            styleTableWithHeader(table);
            table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
            table.setRowHeight(52);
            int[] widths = {58, 82, 190, 145, 210, 240, 160};
            for (int i = 0; i < widths.length; i++) {
                table.getColumnModel().getColumn(i).setPreferredWidth(widths[i]);
            }
            table.getColumnModel().getColumn(0).setMaxWidth(62);
            table.getColumnModel().getColumn(1).setMaxWidth(90);
            table.getColumnModel().getColumn(0).setCellRenderer(createTableCellRenderer(SwingConstants.CENTER));
            table.getColumnModel().getColumn(1).setCellRenderer(createTableCellRenderer(SwingConstants.CENTER));
            table.getColumnModel().getColumn(6).setCellRenderer(new CustomerActionRenderer());
            table.getColumnModel().getColumn(6).setCellEditor(new CustomerActionEditor());
            table.setDefaultRenderer(Object.class, new DefaultTableCellRenderer() {
                @Override
                public Component getTableCellRendererComponent(JTable source, Object value,
                                                               boolean selected, boolean focused,
                                                               int row, int column) {
                    Component cell = super.getTableCellRendererComponent(
                            source, value, selected, focused, row, column);
                    cell.setForeground(TEXT);
                    cell.setBackground(selected ? new Color(236, 253, 245)
                            : (row % 2 == 0 ? SURFACE : new Color(248, 251, 249)));
                    setBorder(new EmptyBorder(0, 10, 0, 10));
                    setFont(new Font("SansSerif", Font.PLAIN, 12));
                    return cell;
                }
            });
        }

        private void loadCustomerData() {
            customerList.clear();
            try {
                customerList.addAll(new org.example.dao.CustomerDao().findAll());
                updateCustomerSummary();
                refreshCustomerTable();
            } catch (SQLException ex) {
                customerModel.setRowCount(0);
                filteredCustomers.clear();
                customersRangeLabel.setText("Unable to load customers");
                updateCustomerSummary();
                JOptionPane.showMessageDialog(this, "Unable to load customers: " + ex.getMessage(),
                        "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        private void updateCustomerSummary() {
            try {
                org.example.dao.CustomerDao dao = new org.example.dao.CustomerDao();
                customersCountLabel.setText(String.valueOf(dao.count()));
                customersActiveLabel.setText(String.valueOf(dao.countActive()));
            } catch (SQLException ex) {
                customersCountLabel.setText("—");
                customersActiveLabel.setText("—");
            }
        }

        private void refreshCustomerTable() {
            String query = customerSearchField.getText().trim().toLowerCase();
            filteredCustomers.clear();
            for (org.example.model.Customer customer : customerList) {
                String name = customer.getCustomerName() == null ? "" : customer.getCustomerName();
                String phone = customer.getMobileNumber() == null ? "" : customer.getMobileNumber();
                if (query.isEmpty() || name.toLowerCase().contains(query)
                        || phone.toLowerCase().contains(query)
                        || String.valueOf(customer.getCustomerId()).contains(query)) {
                    filteredCustomers.add(customer);
                }
            }

            int pages = Math.max(1,
                    (int) Math.ceil(filteredCustomers.size() / (double) CUSTOMERS_PAGE_SIZE));
            customersPage = Math.min(customersPage, pages);
            int from = Math.min((customersPage - 1) * CUSTOMERS_PAGE_SIZE, filteredCustomers.size());
            int to = Math.min(from + CUSTOMERS_PAGE_SIZE, filteredCustomers.size());
            customerModel.setRowCount(0);
            for (int i = from; i < to; i++) {
                org.example.model.Customer customer = filteredCustomers.get(i);
                customerModel.addRow(new Object[]{
                        i + 1,
                        customer.getCustomerId(),
                        customer.getCustomerName(),
                        displayCustomerValue(customer.getMobileNumber()),
                        displayCustomerValue(customer.getEmail()),
                        displayCustomerValue(customer.getAddress()),
                        ""
                });
            }

            customersRangeLabel.setText(filteredCustomers.isEmpty() ? "No customers found"
                    : "Showing " + (from + 1) + "–" + to + " of " + filteredCustomers.size() + " customers");
            JLabel pageNumber = (JLabel) customersTableState.getClientProperty("paginationLabel");
            JButton previous = (JButton) customersTableState.getClientProperty("previousButton");
            JButton next = (JButton) customersTableState.getClientProperty("nextButton");
            pageNumber.setText(filteredCustomers.isEmpty() ? "0 / 0" : customersPage + " / " + pages);
            boolean multiplePages = filteredCustomers.size() > CUSTOMERS_PAGE_SIZE;
            pageNumber.setVisible(multiplePages);
            previous.setVisible(multiplePages);
            next.setVisible(multiplePages);
            previous.setEnabled(customersPage > 1);
            next.setEnabled(customersPage < pages);
        }

        private String displayCustomerValue(String value) {
            return value == null || value.isBlank() ? "—" : value;
        }

        private JPanel createCustomerField(String labelText, JComponent field) {
            JPanel wrapper = new JPanel(new BorderLayout(0, 5));
            wrapper.setOpaque(false);
            JLabel label = new JLabel(labelText);
            label.setForeground(TEXT);
            label.setFont(new Font("SansSerif", Font.BOLD, 12));
            wrapper.add(label, BorderLayout.NORTH);
            wrapper.add(field, BorderLayout.CENTER);
            return wrapper;
        }

        private void styleCustomerInput(JTextField field) {
            field.setFont(new Font("SansSerif", Font.PLAIN, 14));
            field.setBorder(BorderFactory.createCompoundBorder(
                    new RoundedBorder(9, BORDER, 1, true), new EmptyBorder(7, 10, 7, 10)));
            field.setPreferredSize(new Dimension(0, 38));
        }

        private String validateCustomerPhone(String input) {
            String phone = input == null ? "" : input.trim();
            if (phone.isEmpty()) {
                return null;
            }
            if (!phone.matches("\\+?[0-9][0-9 ()\\-.]*")) {
                throw new IllegalArgumentException(
                        "Enter a valid phone number using digits and an optional leading +, spaces, parentheses, hyphens, or periods.");
            }
            int digits = phone.replaceAll("\\D", "").length();
            if (digits < 7 || digits > 15) {
                throw new IllegalArgumentException("Phone numbers must contain 7 to 15 digits.");
            }
            return phone;
        }

        private boolean confirmDuplicateCustomerName(String name, int currentId,
                                                     org.example.dao.CustomerDao dao,
                                                     Component parent) throws SQLException {
            List<org.example.model.Customer> matches = dao.findByName(name);
            StringBuilder ids = new StringBuilder();
            for (org.example.model.Customer match : matches) {
                if (match.getCustomerId() == currentId) {
                    continue;
                }
                if (ids.length() > 0) {
                    ids.append(", ");
                }
                ids.append(match.getCustomerId());
            }
            if (ids.length() == 0) {
                return true;
            }
            int choice = JOptionPane.showConfirmDialog(parent,
                    "A customer with this name already exists (Customer ID: " + ids + ").\n" +
                            "Keep the records separate and continue?",
                    "Possible Duplicate Customer",
                    JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            return choice == JOptionPane.YES_OPTION;
        }

        private void seedDemoSales() {
            try {
                org.example.dao.SalesDao salesDao = new org.example.dao.SalesDao();
                if (!salesDao.findAll().isEmpty() || productCatalog.size() < 3) return;
                String[] customers = {"Rahul Sharma", "Priya Verma", "Amit Kumar", "Neha Singh", "Walk-in Customer"};
                String[] payments = {"Cash", "UPI", "Card"};
                for (int i = 0; i < 15; i++) {
                    Product product = productCatalog.get(i % Math.min(productCatalog.size(), 10));
                    if (product.getStock() <= 0) continue;
                    int quantity = 1 + (i % 2);
                    org.example.model.SaleItem item = new org.example.model.SaleItem();
                    item.setProductId(product.getId());
                    item.setQuantity(quantity);
                    item.setUnitPrice(product.getPrice());
                    item.setLineTotal(product.getPrice() * quantity);
                    List<org.example.model.SaleItem> items = new ArrayList<>();
                    items.add(item);
                    double subtotal = item.getLineTotal();
                    salesDao.saveSale("DEMO-" + (System.currentTimeMillis() + i), customers[i % customers.length],
                            "", payments[i % payments.length], subtotal, 0, 0, subtotal, items);
                }
                seedProducts();
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Unable to prepare demo sales data: " + ex.getMessage(),
                        "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        private void loadCustomerSelector() {
            if (customerSelector == null) return;
            customerSelector.removeAllItems();
            customerSelector.addItem("Walk-in Customer");
            try {
                for (org.example.model.Customer customer : new org.example.dao.CustomerDao().findAll()) {
                    String phone = customer.getMobileNumber() == null ? "" : " · " + customer.getMobileNumber();
                    customerSelector.addItem(customer.getCustomerName() + phone);
                }
            } catch (SQLException ignored) { }
            customerSelector.setSelectedIndex(0);
        }

        private void selectCustomerFromCombo() {
            if (customerSelector == null || customerSelector.getSelectedIndex() <= 0) {
                customerNameField.setText("");
                customerMobileField.setText("");
                return;
            }
            try {
                List<org.example.model.Customer> customers = new org.example.dao.CustomerDao().findAll();
                int index = customerSelector.getSelectedIndex() - 1;
                if (index >= 0 && index < customers.size()) {
                    org.example.model.Customer customer = customers.get(index);
                    customerNameField.setText(customer.getCustomerName());
                    customerMobileField.setText(customer.getMobileNumber() == null ? "" : customer.getMobileNumber());
                }
            } catch (SQLException ignored) { }
        }

        private void openCustomerDialog(org.example.model.Customer existing) {
            boolean editing = existing != null;
            JDialog dialog = new JDialog(this, editing ? "Edit Customer" : "Add Customer", true);
            dialog.setDefaultCloseOperation(JDialog.DISPOSE_ON_CLOSE);

            JPanel root = new JPanel(new BorderLayout(0, 14));
            root.setBackground(BG);
            root.setBorder(new EmptyBorder(20, 22, 18, 22));

            JPanel heading = new JPanel();
            heading.setOpaque(false);
            heading.setLayout(new BoxLayout(heading, BoxLayout.Y_AXIS));
            JLabel title = new JLabel(editing ? "Edit customer details" : "Add a customer");
            title.setForeground(TEXT);
            title.setFont(new Font("SansSerif", Font.BOLD, 21));
            JLabel subtitle = new JLabel("Customer ID is retained when an existing record is edited.");
            subtitle.setForeground(MUTED);
            subtitle.setFont(new Font("SansSerif", Font.PLAIN, 12));
            heading.add(title);
            heading.add(Box.createVerticalStrut(4));
            heading.add(subtitle);
            root.add(heading, BorderLayout.NORTH);

            JTextField nameField = new JTextField(editing ? nullToEmpty(existing.getCustomerName()) : "");
            JTextField phoneField = new JTextField(editing ? nullToEmpty(existing.getMobileNumber()) : "");
            JTextField emailField = new JTextField(editing ? nullToEmpty(existing.getEmail()) : "");
            styleCustomerInput(nameField);
            styleCustomerInput(phoneField);
            styleCustomerInput(emailField);

            JTextArea addressField = new JTextArea(editing ? nullToEmpty(existing.getAddress()) : "", 4, 24);
            addressField.setFont(new Font("SansSerif", Font.PLAIN, 14));
            addressField.setLineWrap(true);
            addressField.setWrapStyleWord(true);
            addressField.setBorder(new EmptyBorder(8, 10, 8, 10));
            JScrollPane addressScroll = new JScrollPane(addressField);
            addressScroll.setBorder(new RoundedBorder(9, BORDER, 1, true));

            JPanel form = new JPanel();
            form.setOpaque(false);
            form.setLayout(new BoxLayout(form, BoxLayout.Y_AXIS));
            form.add(createCustomerField("Customer Name", nameField));
            form.add(Box.createVerticalStrut(10));
            form.add(createCustomerField("Phone Number (optional)", phoneField));
            form.add(Box.createVerticalStrut(10));
            form.add(createCustomerField("Email (optional)", emailField));
            form.add(Box.createVerticalStrut(10));
            form.add(createCustomerField("Address (optional)", addressScroll));
            root.add(form, BorderLayout.CENTER);

            JButton cancel = createSecondaryButton("Cancel");
            cancel.addActionListener(e -> dialog.dispose());
            JButton save = createPrimaryButton(editing ? "Save Changes" : "Save Customer");
            save.addActionListener(e -> {
                try {
                    String name = nameField.getText().trim();
                    if (name.isEmpty()) {
                        throw new IllegalArgumentException("Customer name is required.");
                    }
                    if (name.length() > 100) {
                        throw new IllegalArgumentException("Customer name must be 100 characters or fewer.");
                    }
                    String phone = validateCustomerPhone(phoneField.getText());
                    String email = emailField.getText().trim();
                    String address = addressField.getText().trim();
                    if (email.length() > 100) {
                        throw new IllegalArgumentException("Email must be 100 characters or fewer.");
                    }
                    if (address.length() > 255) {
                        throw new IllegalArgumentException("Address must be 255 characters or fewer.");
                    }

                    org.example.dao.CustomerDao dao = new org.example.dao.CustomerDao();
                    int customerId = editing ? existing.getCustomerId() : 0;
                    if (!confirmDuplicateCustomerName(name, customerId, dao, dialog)) {
                        return;
                    }

                    org.example.model.Customer customer = new org.example.model.Customer();
                    customer.setCustomerId(customerId);
                    customer.setCustomerName(name);
                    customer.setMobileNumber(phone);
                    customer.setEmail(email.isEmpty() ? null : email);
                    customer.setAddress(address.isEmpty() ? null : address);
                    dao.save(customer);

                    dialog.dispose();
                    loadCustomerData();
                    loadCustomerSelector();
                    showToast(editing ? "Customer updated successfully" : "Customer added successfully");
                } catch (IllegalArgumentException ex) {
                    JOptionPane.showMessageDialog(dialog, ex.getMessage(),
                            "Invalid Customer Details", JOptionPane.WARNING_MESSAGE);
                } catch (SQLException ex) {
                    JOptionPane.showMessageDialog(dialog, "Unable to save customer: " + ex.getMessage(),
                            "Database Error", JOptionPane.ERROR_MESSAGE);
                }
            });

            JPanel actions = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
            actions.setOpaque(false);
            actions.add(cancel);
            actions.add(save);
            root.add(actions, BorderLayout.SOUTH);

            dialog.setContentPane(root);
            dialog.setSize(520, 540);
            dialog.setMinimumSize(new Dimension(480, 500));
            dialog.setLocationRelativeTo(this);
            dialog.setVisible(true);
        }

        private String nullToEmpty(String value) {
            return value == null ? "" : value;
        }

        private void deleteCustomer(org.example.model.Customer customer) {
            int choice = JOptionPane.showConfirmDialog(this,
                    "Delete " + customer.getCustomerName() + " (Customer ID " +
                            customer.getCustomerId() + ")?",
                    "Confirm Customer Deletion",
                    JOptionPane.YES_NO_OPTION, JOptionPane.WARNING_MESSAGE);
            if (choice != JOptionPane.YES_OPTION) {
                return;
            }
            try {
                new org.example.dao.CustomerDao().delete(customer.getCustomerId());
                loadCustomerData();
                loadCustomerSelector();
                showToast("Customer deleted successfully");
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Unable to delete customer: " + ex.getMessage(),
                        "Database Error", JOptionPane.ERROR_MESSAGE);
            }
        }

        private class CustomerActionRenderer implements TableCellRenderer {
            private final JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0));
            private final JButton edit = new JButton("Edit");
            private final JButton delete = new JButton("Delete");

            CustomerActionRenderer() {
                panel.setOpaque(false);
                edit.setBackground(SOFT);
                edit.setForeground(TEXT);
                edit.setFocusPainted(false);
                edit.setFont(new Font("SansSerif", Font.BOLD, 11));
                edit.setBorder(new RoundedBorder(8, BORDER, 1, true));
                delete.setBackground(new Color(254, 242, 242));
                delete.setForeground(new Color(153, 27, 27));
                delete.setFocusPainted(false);
                delete.setFont(new Font("SansSerif", Font.BOLD, 11));
                delete.setBorder(new RoundedBorder(8, new Color(248, 113, 113), 1, true));
                edit.setPreferredSize(new Dimension(58, 30));
                delete.setPreferredSize(new Dimension(68, 30));
                panel.add(edit);
                panel.add(delete);
            }

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean selected, boolean focused,
                                                           int row, int column) {
                return panel;
            }
        }

        private class CustomerActionEditor extends AbstractCellEditor
                implements TableCellEditor, ActionListener {
            private final JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0));
            private final JButton edit = new JButton("Edit");
            private final JButton delete = new JButton("Delete");
            private int rowIndex = -1;

            CustomerActionEditor() {
                panel.setOpaque(false);
                edit.setBackground(SOFT);
                edit.setForeground(TEXT);
                edit.setFocusPainted(false);
                edit.setFont(new Font("SansSerif", Font.BOLD, 11));
                edit.setBorder(new RoundedBorder(8, BORDER, 1, true));
                delete.setBackground(new Color(254, 242, 242));
                delete.setForeground(new Color(153, 27, 27));
                delete.setFocusPainted(false);
                delete.setFont(new Font("SansSerif", Font.BOLD, 11));
                delete.setBorder(new RoundedBorder(8, new Color(248, 113, 113), 1, true));
                edit.setPreferredSize(new Dimension(58, 30));
                delete.setPreferredSize(new Dimension(68, 30));
                edit.addActionListener(this);
                delete.addActionListener(this);
                panel.add(edit);
                panel.add(delete);
            }

            @Override
            public Object getCellEditorValue() {
                return "Actions";
            }

            @Override
            public Component getTableCellEditorComponent(JTable table, Object value,
                                                         boolean selected, int row, int column) {
                rowIndex = row;
                return panel;
            }

            @Override
            public void actionPerformed(ActionEvent event) {
                int sourceIndex = (customersPage - 1) * CUSTOMERS_PAGE_SIZE + rowIndex;
                if (rowIndex >= 0 && sourceIndex < filteredCustomers.size()) {
                    org.example.model.Customer customer = filteredCustomers.get(sourceIndex);
                    if (event.getSource() == edit) {
                        openCustomerDialog(customer);
                    } else if (event.getSource() == delete) {
                        deleteCustomer(customer);
                    }
                }
                fireEditingStopped();
            }
        }

        private JPanel buildSalesHistoryPanel() {
            JPanel panel = new JPanel(new BorderLayout(16, 16));
            panel.setBackground(BG);
            panel.setBorder(new EmptyBorder(18, 18, 18, 18));

            JPanel toolbar = new JPanel(new BorderLayout(12, 0));
            toolbar.setOpaque(false);
            JPanel filters = new JPanel(new FlowLayout(FlowLayout.LEFT, 10, 0));
            filters.setOpaque(false);
            JComboBox<String> dateFilter = new JComboBox<>(new String[]{"Last 7 Days", "Last 30 Days", "This Month"});
            dateFilter.setBackground(WHITE);
            dateFilter.setBorder(new RoundedBorder(10, BORDER, 1, true));
            dateFilter.setPreferredSize(new Dimension(160, 36));
            JTextField invoiceSearch = new JTextField();
            invoiceSearch.setBorder(new RoundedBorder(10, BORDER, 1, true));
            invoiceSearch.setPreferredSize(new Dimension(180, 36));
            invoiceSearch.setToolTipText("Search by Invoice ID");
            dateFilter.addActionListener(e -> refreshSalesHistoryTable(String.valueOf(dateFilter.getSelectedItem()), invoiceSearch.getText()));
            invoiceSearch.getDocument().addDocumentListener(new SimpleDocumentListener(
                    () -> refreshSalesHistoryTable(String.valueOf(dateFilter.getSelectedItem()), invoiceSearch.getText())));
            filters.add(dateFilter);
            filters.add(invoiceSearch);
            toolbar.add(filters, BorderLayout.CENTER);

            panel.add(toolbar, BorderLayout.NORTH);
            refreshSalesHistoryTable();
            styleTableWithHeader(salesHistoryTable);
            JScrollPane scroll = new JScrollPane(salesHistoryTable);
            scroll.setBorder(null);
            scroll.setViewportBorder(null);
            scroll.getVerticalScrollBar().setUnitIncrement(12);
            panel.add(scroll, BorderLayout.CENTER);
            return panel;
        }

        private void refreshSalesHistoryTable() {
            refreshSalesHistoryTable("All", "");
        }

        private void refreshSalesHistoryTable(String dateFilter, String invoiceSearch) {
            salesHistoryModel.setRowCount(0);
            salesHistory.clear();
            try {
                org.example.dao.SalesDao salesDao = new org.example.dao.SalesDao();
                for (org.example.model.Sale sale : salesDao.findAll()) {
                    salesHistory.add(new SaleRecord(
                            sale.getBillNumber(),
                            sale.getCustomerName() == null ? "Walk-in Customer" : sale.getCustomerName(),
                            sale.getPaymentMethod(),
                            sale.getSubtotal(),
                            sale.getDiscount(),
                            sale.getTax(),
                            sale.getGrandTotal(),
                            sale.getSaleDate().getTime()
                    ));
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Unable to load sales history: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            }
            long cutoff = 0;
            if ("Last 7 Days".equals(dateFilter)) cutoff = System.currentTimeMillis() - 7L * 24 * 60 * 60 * 1000;
            if ("Last 30 Days".equals(dateFilter)) cutoff = System.currentTimeMillis() - 30L * 24 * 60 * 60 * 1000;
            if ("This Month".equals(dateFilter)) {
                java.util.Calendar calendar = java.util.Calendar.getInstance();
                calendar.set(java.util.Calendar.DAY_OF_MONTH, 1);
                calendar.set(java.util.Calendar.HOUR_OF_DAY, 0);
                calendar.set(java.util.Calendar.MINUTE, 0);
                calendar.set(java.util.Calendar.SECOND, 0);
                cutoff = calendar.getTimeInMillis();
            }
            String query = invoiceSearch == null ? "" : invoiceSearch.trim().toLowerCase();
            for (SaleRecord sale : new ArrayList<>(salesHistory)) {
                if (cutoff > 0 && sale.getTimestamp() < cutoff) continue;
                if (!query.isEmpty() && !sale.getInvoiceId().toLowerCase().contains(query)) continue;
                salesHistoryModel.addRow(new Object[]{sale.getInvoiceId(), new java.text.SimpleDateFormat("dd MMM yyyy, HH:mm").format(new java.util.Date(sale.getTimestamp())), sale.getCustomerName(), MONEY.format(sale.getGrandTotal()), sale.getPaymentMethod(), "View Receipt"});
            }
            if (salesHistoryTable.getColumnModel().getColumnCount() > 5) {
                salesHistoryTable.getColumnModel().getColumn(5).setCellRenderer(new ReceiptButtonRenderer());
                salesHistoryTable.getColumnModel().getColumn(5).setCellEditor(new ReceiptButtonEditor());
            }
        }

        private JPanel buildStockPanel() {
            JPanel panel = new JPanel(new BorderLayout(16, 16));
            panel.setBackground(BG);
            panel.setBorder(new EmptyBorder(18, 18, 18, 18));

            JLabel banner = new JLabel("Low stock items are highlighted below.");
            banner.setOpaque(true);
            banner.setBackground(new Color(254, 243, 199));
            banner.setForeground(new Color(146, 64, 14));
            banner.setBorder(new EmptyBorder(12, 16, 12, 16));
            banner.setFont(new Font("SansSerif", Font.BOLD, 12));
            panel.add(banner, BorderLayout.NORTH);

            refreshStockTable();
            styleTableWithHeader(stockTable);
            JScrollPane scroll = new JScrollPane(stockTable);
            scroll.setBorder(null);
            scroll.setViewportBorder(null);
            scroll.getVerticalScrollBar().setUnitIncrement(12);
            panel.add(scroll, BorderLayout.CENTER);
            return panel;
        }

        private void refreshStockTable() {
            stockModel.setRowCount(0);
            try {
                ProductDao productDao = new ProductDao();
                for (org.example.model.Product product : productDao.findAll()) {
                    int stock = product.getStock();
                    int threshold = Math.max(4, stock / 2);
                    String status = stock <= 0 ? "Out of Stock" : stock <= threshold ? "Low Stock" : "In Stock";
                    stockModel.addRow(new Object[]{product.getProductPhotoPath(), product.getProductName(),
                            stock, threshold, status, "Update Stock"});
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Unable to load stock: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            }
            if (stockTable.getColumnModel().getColumnCount() > 5) {
                stockTable.getColumnModel().getColumn(0).setCellRenderer(new ReportProductImageRenderer());
                stockTable.getColumnModel().getColumn(5).setCellRenderer(new StockActionRenderer());
                stockTable.getColumnModel().getColumn(5).setCellEditor(new StockActionEditor());
            }
        }

        private JPanel buildReportsPanel() {
            JPanel panel = new JPanel(new BorderLayout(16, 16));
            panel.setBackground(BG);
            panel.setBorder(new EmptyBorder(18, 18, 18, 18));

            JPanel stats = new JPanel(new GridLayout(1, 4, 12, 0));
            stats.setOpaque(false);
            int lowStock = 0;
            try { lowStock = new ProductDao().countLowStock(); } catch (SQLException ignored) { }
            double todayRevenue = 0;
            int todayBills = 0;
            try {
                org.example.dao.SalesDao salesDao = new org.example.dao.SalesDao();
                todayRevenue = salesDao.todayRevenue();
                todayBills = salesDao.todayBills();
            } catch (SQLException ignored) { }
            stats.add(createStatCard("Today's Revenue", MONEY.format(todayRevenue), GREEN));
            stats.add(createStatCard("Total Orders", String.valueOf(todayBills), new Color(11, 138, 131)));
            stats.add(createStatCard("Average Order Value", todayBills == 0 ? MONEY.format(0) : MONEY.format(todayRevenue / todayBills), new Color(37, 99, 235)));
            stats.add(createStatCard("Low Stock Items", String.valueOf(lowStock), new Color(245, 158, 11)));
            panel.add(stats, BorderLayout.NORTH);

            JPanel content = new JPanel(new BorderLayout(16, 16));
            content.setOpaque(false);
            List<org.example.model.Sale> reportSales = new ArrayList<>();
            try { reportSales = new org.example.dao.SalesDao().findAll(); } catch (SQLException ignored) { }

            JPanel overview = new JPanel(new BorderLayout(8, 8));
            overview.setBackground(SURFACE);
            overview.setBorder(BorderFactory.createCompoundBorder(new RoundedBorder(16, BORDER, 1, true),
                    new EmptyBorder(14, 16, 14, 16)));
            JLabel overviewTitle = new JLabel("Sales Overview");
            overviewTitle.setForeground(TEXT);
            overviewTitle.setFont(new Font("SansSerif", Font.BOLD, 16));
            overview.add(overviewTitle, BorderLayout.NORTH);
            overview.add(new SalesChartPanel(reportSales), BorderLayout.CENTER);

            JPanel topProductsCard = new JPanel(new BorderLayout(8, 8));
            topProductsCard.setBackground(SURFACE);
            topProductsCard.setBorder(new RoundedBorder(16, BORDER, 1, true));
            JLabel topTitle = new JLabel("Top Selling Products");
            topTitle.setFont(new Font("SansSerif", Font.BOLD, 16));
            topTitle.setBorder(new EmptyBorder(16, 16, 8, 16));
            topProductsCard.add(topTitle, BorderLayout.NORTH);
            topProductsModel.setRowCount(0);
            try {
                for (Object[] row : new org.example.dao.SalesDao().topSellingProducts(8)) {
                    topProductsModel.addRow(new Object[]{row[1], row[0], row[2], MONEY.format(((Number) row[3]).doubleValue())});
                }
            } catch (SQLException ignored) { }
            JTable topProductsTable = new JTable(topProductsModel);
            styleTableWithHeader(topProductsTable);
            topProductsTable.setRowHeight(54);
            topProductsTable.getColumnModel().getColumn(0).setPreferredWidth(62);
            topProductsTable.getColumnModel().getColumn(0).setMaxWidth(72);
            topProductsTable.getColumnModel().getColumn(0).setCellRenderer(new ReportProductImageRenderer());
            JScrollPane topProductsScroll = new JScrollPane(topProductsTable);
            topProductsScroll.setBorder(null);
            topProductsCard.add(topProductsScroll, BorderLayout.CENTER);

            JPanel paymentCard = new JPanel(new BorderLayout(8, 8));
            paymentCard.setBackground(SURFACE);
            paymentCard.setBorder(new RoundedBorder(16, BORDER, 1, true));
            JLabel paymentTitle = new JLabel("Payment Split");
            paymentTitle.setFont(new Font("SansSerif", Font.BOLD, 16));
            paymentTitle.setBorder(new EmptyBorder(16, 16, 8, 16));
            paymentCard.add(paymentTitle, BorderLayout.NORTH);
            paymentSplitModel.setRowCount(0);
            try {
                for (Object[] row : new org.example.dao.SalesDao().todayPaymentSplit()) {
                    paymentSplitModel.addRow(new Object[]{row[0], MONEY.format(((Number) row[1]).doubleValue())});
                }
            } catch (SQLException ignored) { }
            JTable paymentTable = new JTable(paymentSplitModel);
            styleTableWithHeader(paymentTable);
            JScrollPane paymentScroll = new JScrollPane(paymentTable);
            paymentScroll.setBorder(null);
            paymentCard.add(paymentScroll, BorderLayout.CENTER);

            JPanel upper = new JPanel(new GridLayout(1, 2, 16, 0));
            upper.setOpaque(false);
            upper.add(overview);
            upper.add(paymentCard);
            JPanel lower = new JPanel(new GridLayout(1, 2, 16, 0));
            lower.setOpaque(false);
            lower.add(topProductsCard);
            lower.add(createRecentSalesReportCard(reportSales));
            content.add(upper, BorderLayout.NORTH);
            content.add(lower, BorderLayout.CENTER);

            panel.add(content, BorderLayout.CENTER);
            return panel;
        }

        private JPanel createRecentSalesReportCard(List<org.example.model.Sale> sales) {
            JPanel card = new JPanel(new BorderLayout(8, 8));
            card.setBackground(SURFACE);
            card.setBorder(new RoundedBorder(16, BORDER, 1, true));
            JLabel title = new JLabel("Recent Sales");
            title.setFont(new Font("SansSerif", Font.BOLD, 16));
            title.setBorder(new EmptyBorder(16, 16, 8, 16));
            card.add(title, BorderLayout.NORTH);
            if (sales.isEmpty()) {
                JLabel empty = new JLabel("<html><center>No sales data available yet.<br>Create your first bill to see analytics here.</center></html>", SwingConstants.CENTER);
                empty.setForeground(MUTED);
                card.add(empty, BorderLayout.CENTER);
                return card;
            }
            DefaultTableModel model = new DefaultTableModel(new Object[]{"Bill", "Customer", "Amount", "Payment"}, 0) {
                @Override public boolean isCellEditable(int row, int column) { return false; }
            };
            for (int i = 0; i < Math.min(7, sales.size()); i++) {
                org.example.model.Sale sale = sales.get(i);
                model.addRow(new Object[]{sale.getBillNumber(),
                        sale.getCustomerName() == null ? "Walk-in" : sale.getCustomerName(),
                        MONEY.format(sale.getGrandTotal()), sale.getPaymentMethod()});
            }
            JTable table = new JTable(model);
            styleTableWithHeader(table);
            JScrollPane scroll = new JScrollPane(table);
            scroll.setBorder(null);
            card.add(scroll, BorderLayout.CENTER);
            return card;
        }

        private void addTopProductReportRow(String productName, int unitsSold, String revenue) {
            Product product = findProductByName(productName);
            topProductsModel.addRow(new Object[]{
                    product == null ? null : product.getImagePath(), productName, unitsSold, revenue
            });
        }

        private Product findProductByName(String productName) {
            for (Product product : productCatalog) {
                if (product.getName().equalsIgnoreCase(productName)) {
                    return product;
                }
            }
            return null;
        }

        private JPanel createStatCard(String title, String value, Color accentColor) {
            JPanel card = new JPanel();
            card.setBackground(SURFACE);
            card.setBorder(new RoundedBorder(16, BORDER, 1, true));
            card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
            card.setBorder(new EmptyBorder(18, 18, 18, 18));
            JLabel titleLabel = new JLabel(title);
            titleLabel.setForeground(MUTED);
            titleLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            JLabel valueLabel = new JLabel(value);
            valueLabel.setForeground(accentColor);
            valueLabel.setFont(new Font("SansSerif", Font.BOLD, 22));
            card.add(titleLabel);
            card.add(Box.createVerticalStrut(10));
            card.add(valueLabel);
            card.putClientProperty("valueLabel", valueLabel);
            return card;
        }

        private JPanel buildSettingsPanel() {
            JPanel panel = new JPanel(new BorderLayout(16, 16));
            panel.setBackground(BG);
            panel.setBorder(new EmptyBorder(18, 18, 18, 18));

            JPanel form = new JPanel(new GridBagLayout());
            form.setBackground(SURFACE);
            form.setBorder(new RoundedBorder(18, BORDER, 1, true));
            form.setBorder(new EmptyBorder(18, 18, 18, 18));

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(10, 10, 10, 10);
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.gridx = 0;
            gbc.weightx = 0.2;
            JLabel storeNameLabel = new JLabel("Store Name");
            storeNameLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            form.add(storeNameLabel, gbc);
            gbc.gridx = 1;
            gbc.weightx = 1.0;
            JTextField storeNameField = new JTextField("Green Basket Grocery");
            storeNameField.setBorder(new RoundedBorder(10, BORDER, 1, true));
            form.add(storeNameField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 1;
            gbc.weightx = 0.2;
            JLabel addressLabel = new JLabel("Address");
            addressLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            form.add(addressLabel, gbc);
            gbc.gridx = 1;
            gbc.weightx = 1.0;
            JTextArea addressArea = new JTextArea("24 Market Road, Green Park");
            addressArea.setRows(3);
            addressArea.setLineWrap(true);
            addressArea.setWrapStyleWord(true);
            addressArea.setBorder(new RoundedBorder(10, BORDER, 1, true));
            form.add(new JScrollPane(addressArea), gbc);

            gbc.gridx = 0;
            gbc.gridy = 2;
            gbc.weightx = 0.2;
            JLabel taxLabel = new JLabel("Tax/GST Rate (%)");
            taxLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            form.add(taxLabel, gbc);
            gbc.gridx = 1;
            gbc.weightx = 1.0;
            JTextField taxRateField = new JTextField("5.0");
            taxRateField.setBorder(new RoundedBorder(10, BORDER, 1, true));
            form.add(taxRateField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 3;
            gbc.weightx = 0.2;
            JLabel currencyLabel = new JLabel("Currency Symbol");
            currencyLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            form.add(currencyLabel, gbc);
            gbc.gridx = 1;
            gbc.weightx = 1.0;
            JTextField currencyField = new JTextField("₹");
            currencyField.setBorder(new RoundedBorder(10, BORDER, 1, true));
            form.add(currencyField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 4;
            gbc.weightx = 0.2;
            JLabel themeLabel = new JLabel("Theme");
            themeLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            form.add(themeLabel, gbc);
            gbc.gridx = 1;
            gbc.weightx = 1.0;
            JComboBox<String> themeCombo = new JComboBox<>(new String[]{"Light", "Dark"});
            themeCombo.setBackground(WHITE);
            themeCombo.setBorder(new RoundedBorder(10, BORDER, 1, true));
            form.add(themeCombo, gbc);

            gbc.gridx = 1;
            gbc.gridy = 5;
            gbc.weightx = 1.0;
            JButton saveButton = createPrimaryButton("Save Settings");
            saveButton.addActionListener(e -> JOptionPane.showMessageDialog(this, "Settings saved successfully.", "Settings", JOptionPane.INFORMATION_MESSAGE));
            form.add(saveButton, gbc);

            panel.add(form, BorderLayout.CENTER);
            return panel;
        }

        private void styleProductsPanelTable(JTable table) {
            styleTableWithHeader(table);
            table.setAutoResizeMode(JTable.AUTO_RESIZE_OFF);
            int[] columnWidths = {58, 72, 78, 195, 120, 100, 72, 132, 165};
            for (int i = 0; i < columnWidths.length; i++) {
                table.getColumnModel().getColumn(i).setPreferredWidth(columnWidths[i]);
            }
            table.getColumnModel().getColumn(0).setMaxWidth(64);
            table.getColumnModel().getColumn(1).setMaxWidth(82);
            table.getColumnModel().getColumn(2).setMaxWidth(84);
            table.getColumnModel().getColumn(8).setMinWidth(160);
            table.setRowHeight(54);

            table.getColumnModel().getColumn(0).setCellRenderer(createTableCellRenderer(SwingConstants.CENTER));
            table.getColumnModel().getColumn(1).setCellRenderer(createTableCellRenderer(SwingConstants.CENTER));
            table.getColumnModel().getColumn(3).setCellRenderer(createTableCellRenderer(SwingConstants.LEFT));
            table.getColumnModel().getColumn(5).setCellRenderer(createTableCellRenderer(SwingConstants.RIGHT));
            table.getColumnModel().getColumn(6).setCellRenderer(createTableCellRenderer(SwingConstants.CENTER));
        }

        private DefaultTableCellRenderer createTableCellRenderer(int alignment) {
            DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
            renderer.setHorizontalAlignment(alignment);
            renderer.setBackground(SURFACE);
            renderer.setForeground(TEXT);
            renderer.setBorder(new EmptyBorder(8, 12, 8, 12));
            return renderer;
        }

        private void styleTableWithHeader(JTable table) {
            table.setBackground(SURFACE);
            table.setForeground(TEXT);
            table.setShowGrid(false);
            table.setRowHeight(42);
            table.setIntercellSpacing(new Dimension(0, 0));
            table.setSelectionBackground(new Color(236, 253, 245));
            table.setSelectionForeground(TEXT);
            table.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);
            JTableHeader header = table.getTableHeader();
            header.setBackground(new Color(241, 245, 249));
            header.setForeground(MUTED);
            header.setFont(new Font("SansSerif", Font.BOLD, 12));
            header.setBorder(new EmptyBorder(10, 10, 10, 10));
            header.setReorderingAllowed(false);
            DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
            renderer.setBackground(SURFACE);
            renderer.setForeground(TEXT);
            renderer.setBorder(new EmptyBorder(8, 10, 8, 10));
            table.setDefaultRenderer(Object.class, renderer);
        }

        private JPanel buildPlaceholderPanel(String title, String subtitle) {
            JPanel panel = new JPanel(new GridBagLayout());
            panel.setBackground(BG);

            JPanel card = new JPanel();
            card.setLayout(new BoxLayout(card, BoxLayout.Y_AXIS));
            card.setBackground(SURFACE);
            card.setBorder(new RoundedBorder(22, BORDER, 1, true));
            card.setPreferredSize(new Dimension(700, 500));
            card.setAlignmentX(Component.CENTER_ALIGNMENT);
            card.setAlignmentY(Component.CENTER_ALIGNMENT);

            JLabel titleLabel = new JLabel(title);
            titleLabel.setFont(new Font("SansSerif", Font.BOLD, 28));
            titleLabel.setForeground(TEXT);
            titleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

            JLabel subtitleLabel = new JLabel(subtitle);
            subtitleLabel.setFont(new Font("SansSerif", Font.PLAIN, 16));
            subtitleLabel.setForeground(MUTED);
            subtitleLabel.setAlignmentX(Component.CENTER_ALIGNMENT);

            card.add(Box.createVerticalStrut(60));
            card.add(titleLabel);
            card.add(Box.createVerticalStrut(18));
            card.add(subtitleLabel);
            panel.add(card);
            return panel;
        }

        private JPanel buildBillingContent() {
            JPanel main = new JPanel(new BorderLayout(20, 18));
            main.setBackground(BG);
            main.setBorder(new EmptyBorder(4, 6, 4, 6));

            JPanel topControls = new JPanel(new BorderLayout(12, 0));
            topControls.setOpaque(false);
            topControls.setBorder(new EmptyBorder(0, 0, 8, 0));

            billingSearchField = new JTextField();
            billingSearchField.setToolTipText("Search product by name, category or barcode...");
            billingSearchField.setFont(new Font("SansSerif", Font.PLAIN, 15));
            billingSearchField.setBackground(SURFACE);
            billingSearchField.setForeground(TEXT);
            billingSearchField.setBorder(new RoundedBorder(18, BORDER, 1, true));
            billingSearchField.setPreferredSize(new Dimension(0, 46));
            billingSearchField.getDocument().addDocumentListener(new DocumentListener() {
                @Override public void insertUpdate(DocumentEvent e) { currentSearchText = billingSearchField.getText(); applyProductFilter(); }
                @Override public void removeUpdate(DocumentEvent e) { currentSearchText = billingSearchField.getText(); applyProductFilter(); }
                @Override public void changedUpdate(DocumentEvent e) { currentSearchText = billingSearchField.getText(); applyProductFilter(); }
            });
            topControls.add(billingSearchField, BorderLayout.CENTER);

            JPanel greetingBlock = new JPanel(new BorderLayout(12, 0));
            greetingBlock.setOpaque(false);
            greetingBlock.setBorder(new EmptyBorder(4, 8, 0, 8));

            JPanel textPanel = new JPanel();
            textPanel.setLayout(new BoxLayout(textPanel, BoxLayout.Y_AXIS));
            textPanel.setOpaque(false);
            JLabel greeting = new JLabel("Good morning, Admin");
            greeting.setForeground(TEXT);
            greeting.setFont(new Font("SansSerif", Font.BOLD, 22));
            greeting.setAlignmentX(Component.LEFT_ALIGNMENT);

            JLabel subtext = new JLabel("Build a bill quickly and keep the checkout moving.");
            subtext.setForeground(MUTED);
            subtext.setFont(new Font("SansSerif", Font.PLAIN, 14));
            subtext.setAlignmentX(Component.LEFT_ALIGNMENT);

            textPanel.add(greeting);
            textPanel.add(Box.createVerticalStrut(4));
            textPanel.add(subtext);
            greetingBlock.add(textPanel, BorderLayout.WEST);

            JPanel livePanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 8, 0));
            livePanel.setOpaque(false);
            JLabel dot = new JLabel("●");
            dot.setForeground(GREEN);
            dot.setFont(new Font("SansSerif", Font.BOLD, 12));
            JLabel liveLabel = new JLabel("Live register");
            liveLabel.setForeground(GREEN_DARK);
            liveLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            livePanel.add(dot);
            livePanel.add(liveLabel);
            greetingBlock.add(livePanel, BorderLayout.EAST);

            JPanel categoryRow = new JPanel(new WrapLayout(FlowLayout.LEFT, 10, 5));
            categoryRow.setOpaque(false);
            categoryRow.setBorder(new EmptyBorder(10, 8, 15, 8));
            String[] categories = {"All", "Grocery", "Beverages", "Dairy", "Snacks", "Personal Care", "Household", "Bakery"};
            for (String category : categories) {
                JButton filterBtn = createFilterButton(category, "All".equals(category));
                filterBtn.addActionListener(e -> {
                    currentCategory = category;
                    applyProductFilter();
                    refreshCategoryButtons(categoryRow);
                });
                categoryRow.add(filterBtn);
            }

            JPanel centreHeader = new JPanel(new BorderLayout(10, 0));
            centreHeader.setOpaque(false);
            JLabel productLabel = new JLabel("Select Product");
            productLabel.setForeground(TEXT);
            productLabel.setFont(new Font("SansSerif", Font.BOLD, 18));
            billingCountLabel = new JLabel("0 products available");
            billingCountLabel.setForeground(MUTED);
            billingCountLabel.setFont(new Font("SansSerif", Font.PLAIN, 12));
            JPanel leftMeta = new JPanel();
            leftMeta.setOpaque(false);
            leftMeta.setLayout(new BoxLayout(leftMeta, BoxLayout.Y_AXIS));
            leftMeta.add(productLabel);
            leftMeta.add(Box.createVerticalStrut(2));
            leftMeta.add(billingCountLabel);
            centreHeader.add(leftMeta, BorderLayout.WEST);
            JLabel catalogueLabel = new JLabel("CATALOGUE");
            catalogueLabel.setForeground(MUTED);
            catalogueLabel.setFont(new Font("SansSerif", Font.BOLD, 11));
            centreHeader.add(catalogueLabel, BorderLayout.EAST);

            JPanel productCard = new JPanel(new BorderLayout(0, 10));
            productCard.setBackground(SURFACE);
            productCard.setMinimumSize(new Dimension(280, 420));
            productCard.setBorder(BorderFactory.createCompoundBorder(
                    new RoundedBorder(18, BORDER, 1, true),
                    new EmptyBorder(14, 14, 14, 14)));
            productCard.add(centreHeader, BorderLayout.NORTH);

            billingProductGrid = new ResponsiveProductGrid();
            billingProductGrid.setBackground(SURFACE);
            billingProductGrid.setBorder(new EmptyBorder(2, 2, 2, 2));
            billingProductScrollPane = new JScrollPane(billingProductGrid);
            billingProductScrollPane.setBorder(null);
            billingProductScrollPane.setViewportBorder(null);
            billingProductScrollPane.getVerticalScrollBar().setUnitIncrement(14);
            billingProductScrollPane.setHorizontalScrollBarPolicy(ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
            billingProductScrollPane.getViewport().setBackground(SURFACE);
            JPanel productGridPanel = new JPanel(new CardLayout());
            productGridPanel.setOpaque(false);
            productGridPanel.add(billingProductScrollPane, "GRID");
            productGridPanel.add(billingNoResultsPanel, "EMPTY");
            billingProductState = productGridPanel;
            productCard.add(productGridPanel, BorderLayout.CENTER);

            JPanel billCard = new JPanel(new BorderLayout(0, 10));
            billCard.setBackground(SURFACE);
            billCard.setBorder(new RoundedBorder(18, BORDER, 1, true));
            billCard.setPreferredSize(new Dimension(370, 660));
            billCard.setMinimumSize(new Dimension(320, 620));

            JPanel billHeader = new JPanel();
            billHeader.setOpaque(false);
            billHeader.setBorder(new EmptyBorder(18, 18, 10, 18));
            billHeader.setLayout(new BoxLayout(billHeader, BoxLayout.Y_AXIS));

            JPanel billTitleRow = new JPanel(new BorderLayout());
            billTitleRow.setOpaque(false);
            JLabel billTitle = new JLabel("Current Bill");
            billTitle.setForeground(TEXT);
            billTitle.setFont(new Font("SansSerif", Font.BOLD, 22));
            billTitleRow.add(billTitle, BorderLayout.WEST);
            billHeader.add(billTitleRow);
            billHeader.add(Box.createVerticalStrut(10));

            JPanel billActions = new JPanel(new GridLayout(2, 2, 8, 8));
            billActions.setOpaque(false);
            billActions.setBorder(new EmptyBorder(2, 0, 4, 0));

            JButton holdBtn = new JButton("Hold Bill");
            holdBtn.setBackground(SOFT);
            holdBtn.setForeground(TEXT);
            holdBtn.setFocusPainted(false);
            holdBtn.setFont(new Font("SansSerif", Font.BOLD, 11));
            holdBtn.setBorder(new RoundedBorder(10, BORDER, 1, true));
            holdBtn.setMargin(new Insets(8, 10, 8, 10));
            holdBtn.setPreferredSize(new Dimension(0, 36));
            holdBtn.addActionListener(e -> holdBill());

            JButton clearBtn = new JButton("Clear");
            clearBtn.setBackground(SOFT);
            clearBtn.setForeground(TEXT);
            clearBtn.setFocusPainted(false);
            clearBtn.setFont(new Font("SansSerif", Font.BOLD, 11));
            clearBtn.setBorder(new RoundedBorder(10, BORDER, 1, true));
            clearBtn.setMargin(new Insets(8, 10, 8, 10));
            clearBtn.setPreferredSize(new Dimension(0, 36));
            clearBtn.addActionListener(e -> clearCart());

            JButton draftBtn = new JButton("Save Draft");
            draftBtn.setBackground(SOFT);
            draftBtn.setForeground(TEXT);
            draftBtn.setFocusPainted(false);
            draftBtn.setFont(new Font("SansSerif", Font.BOLD, 11));
            draftBtn.setBorder(new RoundedBorder(10, BORDER, 1, true));
            draftBtn.setMargin(new Insets(8, 10, 8, 10));
            draftBtn.setPreferredSize(new Dimension(0, 36));
            draftBtn.addActionListener(e -> saveDraft());

            JButton printBtn = new JButton("Print");
            printBtn.setBackground(SOFT);
            printBtn.setForeground(TEXT);
            printBtn.setFocusPainted(false);
            printBtn.setFont(new Font("SansSerif", Font.BOLD, 11));
            printBtn.setBorder(new RoundedBorder(10, BORDER, 1, true));
            printBtn.setMargin(new Insets(8, 10, 8, 10));
            printBtn.setPreferredSize(new Dimension(0, 36));
            printBtn.addActionListener(e -> printInvoice());

            billActions.add(holdBtn);
            billActions.add(draftBtn);
            billActions.add(printBtn);
            billActions.add(clearBtn);
            billHeader.add(billActions);

            JPanel customerPanel = new JPanel();
            customerPanel.setLayout(new GridBagLayout());
            customerPanel.setOpaque(false);
            customerPanel.setBorder(new EmptyBorder(0, 18, 12, 18));

            GridBagConstraints customerGbc = new GridBagConstraints();
            customerGbc.gridx = 0;
            customerGbc.gridy = 0;
            customerGbc.fill = GridBagConstraints.HORIZONTAL;
            customerGbc.weightx = 1.0;
            customerGbc.insets = new Insets(0, 0, 8, 0);

            JLabel customerTitle = new JLabel("Customer Details");
            customerTitle.setForeground(TEXT);
            customerTitle.setFont(new Font("SansSerif", Font.BOLD, 12));
            customerTitle.setBorder(new EmptyBorder(0, 0, 4, 0));
            customerPanel.add(customerTitle, customerGbc);

            customerGbc.gridy = 1;
            customerGbc.insets = new Insets(0, 0, 6, 0);
            customerSelector = new JComboBox<>();
            customerSelector.setEditable(false);
            customerSelector.setToolTipText("Select an existing customer or use Walk-in");
            customerSelector.setBackground(WHITE);
            customerSelector.setForeground(TEXT);
            customerSelector.setBorder(new RoundedBorder(10, BORDER, 1, true));
            customerSelector.setPreferredSize(new Dimension(0, 34));
            customerSelector.addActionListener(e -> selectCustomerFromCombo());
            loadCustomerSelector();
            customerPanel.add(customerSelector, customerGbc);

            customerGbc.gridy = 2;
            customerGbc.insets = new Insets(0, 0, 0, 0);
            customerNameField.setBorder(new RoundedBorder(10, BORDER, 1, true));
            customerNameField.setPreferredSize(new Dimension(0, 34));
            customerNameField.setToolTipText("Customer Name (optional)");
            customerMobileField.setBorder(new RoundedBorder(10, BORDER, 1, true));
            customerMobileField.setPreferredSize(new Dimension(0, 34));
            customerMobileField.setToolTipText("Customer Mobile Number (optional)");
            JPanel customerInputs = new JPanel(new GridLayout(1, 2, 8, 0));
            customerInputs.setOpaque(false);
            customerInputs.add(customerNameField);
            customerInputs.add(customerMobileField);
            customerPanel.add(customerInputs, customerGbc);

            JPanel cartArea = new JPanel(new BorderLayout(0, 8));
            cartArea.setOpaque(false);
            cartArea.add(customerPanel, BorderLayout.NORTH);

            billCard.add(billHeader, BorderLayout.NORTH);
            styleCartTable(cartTable);
            cartScrollPane = new JScrollPane(cartTable);
            cartScrollPane.setBorder(null);
            cartScrollPane.setViewportBorder(null);
            cartScrollPane.getVerticalScrollBar().setUnitIncrement(12);
            cartScrollPane.getVerticalScrollBar().setPreferredSize(new Dimension(10, 0));
            JPanel cartTableWrap = new JPanel(new CardLayout());
            cartTableWrap.setOpaque(false);
            cartTableWrap.add(cartScrollPane, "CART");
            cartTableWrap.add(cartEmptyLabel, "EMPTY");
            cartEmptyLabel.setHorizontalAlignment(SwingConstants.CENTER);
            cartEmptyLabel.setVisible(false);
            cartState = cartTableWrap;
            cartArea.add(cartTableWrap, BorderLayout.CENTER);
            billCard.add(cartArea, BorderLayout.CENTER);

            JPanel totalsPanel = new JPanel(new GridBagLayout());
            totalsPanel.setOpaque(false);
            totalsPanel.setBorder(new EmptyBorder(8, 18, 14, 18));

            GridBagConstraints totalsGbc = new GridBagConstraints();
            totalsGbc.gridx = 0;
            totalsGbc.gridy = 0;
            totalsGbc.weightx = 1.0;
            totalsGbc.fill = GridBagConstraints.HORIZONTAL;
            totalsGbc.anchor = GridBagConstraints.WEST;
            totalsGbc.insets = new Insets(2, 0, 2, 0);

            addTotalRow(totalsPanel, "Subtotal", subtotalLabel, false, totalsGbc, 0);
            addEditNumberRow(totalsPanel, "Discount", discountField, false, totalsGbc, 1);
            addEditNumberRow(totalsPanel, "Tax", taxField, false, totalsGbc, 2);
            discountField.setText("0.00");
            taxField.setText("0.00");
            discountField.getDocument().addDocumentListener(new SimpleDocumentListener(this::refreshCartTotals));
            taxField.setEditable(false);
            taxField.setBackground(WHITE);
            taxField.setForeground(TEXT);
            taxField.setHorizontalAlignment(SwingConstants.RIGHT);

            totalsGbc.gridy = 3;
            totalsGbc.insets = new Insets(5, 0, 5, 0);
            JSeparator separator = new JSeparator();
            separator.setForeground(BORDER);
            totalsPanel.add(separator, totalsGbc);

            totalsGbc.gridy = 4;
            totalsGbc.insets = new Insets(6, 0, 6, 0);
            addTotalRow(totalsPanel, "Grand Total", grandTotalLabel, true, totalsGbc, 4);

            totalsGbc.gridy = 5;
            totalsGbc.insets = new Insets(6, 0, 4, 0);
            JPanel paymentPanel = new JPanel(new BorderLayout(8, 0));
            paymentPanel.setOpaque(false);
            JLabel paymentLabel = new JLabel("Payment Method");
            paymentLabel.setForeground(TEXT);
            paymentLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            for (JRadioButton option : new JRadioButton[]{cashPayment, cardPayment, upiPayment}) {
                option.setOpaque(false);
                option.setForeground(TEXT);
                option.setFont(new Font("SansSerif", Font.BOLD, 12));
                option.setFocusPainted(false);
            }
            ButtonGroup paymentGroup = new ButtonGroup();
            paymentGroup.add(cashPayment);
            paymentGroup.add(cardPayment);
            paymentGroup.add(upiPayment);
            JPanel paymentOptions = new JPanel(new FlowLayout(FlowLayout.LEFT, 8, 0));
            paymentOptions.setOpaque(true);
            paymentOptions.setBackground(WHITE);
            paymentOptions.setBorder(new RoundedBorder(10, BORDER, 1, true));
            paymentOptions.add(cashPayment);
            paymentOptions.add(cardPayment);
            paymentOptions.add(upiPayment);
            paymentPanel.add(paymentLabel, BorderLayout.NORTH);
            paymentPanel.add(paymentOptions, BorderLayout.CENTER);
            totalsPanel.add(paymentPanel, totalsGbc);

            totalsGbc.gridy = 6;
            totalsGbc.insets = new Insets(8, 0, 0, 0);
            JButton completeBtn = createPrimaryButton("Pay / Complete Order");
            completeBtn.setPreferredSize(new Dimension(0, 42));
            completeBtn.setMinimumSize(new Dimension(0, 42));
            completeBtn.setMaximumSize(new Dimension(500, 52));
            completeBtn.setMargin(new Insets(10, 14, 10, 14));
            completeBtn.setToolTipText("Generate receipt and complete payment");
            completeBtn.addActionListener(e -> completeOrder());
            totalsPanel.add(completeBtn, totalsGbc);
            billCard.add(totalsPanel, BorderLayout.SOUTH);

            JSplitPane centerSplit = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT, productCard, billCard);
            centerSplit.setOpaque(false);
            centerSplit.setBorder(null);
            centerSplit.setContinuousLayout(true);
            centerSplit.setResizeWeight(0.64);
            centerSplit.setDividerSize(10);
            centerSplit.setMinimumSize(new Dimension(610, 620));

            JPanel headerPanel = new JPanel(new BorderLayout(16, 0));
            headerPanel.setOpaque(false);
            headerPanel.add(greetingBlock, BorderLayout.WEST);
            headerPanel.add(topControls, BorderLayout.CENTER);

            JPanel categoryFilterPanel = new JPanel(new BorderLayout());
            categoryFilterPanel.setOpaque(false);
            categoryFilterPanel.setBorder(new EmptyBorder(10, 0, 15, 0));
            categoryFilterPanel.add(categoryRow, BorderLayout.CENTER);

            JPanel mainContent = new JPanel();
            mainContent.setOpaque(false);
            mainContent.setLayout(new BoxLayout(mainContent, BoxLayout.Y_AXIS));
            mainContent.add(headerPanel);
            mainContent.add(Box.createVerticalStrut(15));
            mainContent.add(createBillingSummaryCards());
            mainContent.add(Box.createVerticalStrut(15));
            mainContent.add(categoryFilterPanel);

            JPanel page = new ResponsiveBillingPage();
            page.setBackground(BG);
            page.setBorder(new EmptyBorder(0, 0, 12, 0));
            page.add(mainContent, BorderLayout.NORTH);
            page.add(centerSplit, BorderLayout.CENTER);
            page.add(createBillingLowerInsights(), BorderLayout.SOUTH);

            JScrollPane pageScroll = new JScrollPane(page,
                    ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED,
                    ScrollPaneConstants.HORIZONTAL_SCROLLBAR_NEVER);
            pageScroll.setBorder(null);
            pageScroll.getVerticalScrollBar().setUnitIncrement(18);
            pageScroll.getViewport().setBackground(BG);
            main.add(pageScroll, BorderLayout.CENTER);
            loadProductsIntoTable();
            return main;
        }

        private JPanel createBillingLowerInsights() {
            JPanel insights = new JPanel(new GridLayout(1, 2, 14, 0));
            insights.setOpaque(false);
            insights.setBorder(new EmptyBorder(20, 0, 0, 0));

            insights.add(createDashboardTableCard("Recent Sales",
                    new String[]{"Bill No.", "Customer", "Date", "Amount", "Payment", "Status"},
                    loadRecentSaleDetailRows(), "No sales recorded yet."));
            insights.add(createDashboardTableCard("⚠ Low Stock Alert",
                    new String[]{"Product", "Stock", "Status"},
                    loadLowStockRows(), "No low-stock products right now."));
            return insights;
        }

        private List<Object[]> loadRecentSaleDetailRows() {
            List<Object[]> rows = new ArrayList<>();
            try {
                List<org.example.model.Sale> sales = new org.example.dao.SalesDao().findAll();
                java.text.SimpleDateFormat format = new java.text.SimpleDateFormat("dd MMM yyyy");
                for (int i = 0; i < Math.min(5, sales.size()); i++) {
                    org.example.model.Sale sale = sales.get(i);
                    rows.add(new Object[]{
                            sale.getBillNumber(),
                            sale.getCustomerName() == null ? "Walk-in" : sale.getCustomerName(),
                            sale.getSaleDate() == null ? "-" : format.format(sale.getSaleDate()),
                            MONEY.format(sale.getGrandTotal()),
                            sale.getPaymentMethod(),
                            "Paid"
                    });
                }
            } catch (SQLException ignored) {
                // The POS screen remains available if recent history cannot be read.
            }
            return rows;
        }

        private JPanel createBillingSummaryCards() {
            double todaySales = 0;
            int todayBills = 0;
            int totalProducts = 0;
            int lowStock = 0;
            try {
                org.example.dao.SalesDao salesDao = new org.example.dao.SalesDao();
                ProductDao productDao = new ProductDao();
                todaySales = salesDao.todayRevenue();
                todayBills = salesDao.todayBills();
                totalProducts = productDao.count();
                lowStock = productDao.countLowStock();
            } catch (SQLException ignored) {
                // The dashboard remains usable when the database is temporarily unavailable.
            }

            JPanel cards = new JPanel(new GridLayout(1, 4, 15, 0));
            cards.setOpaque(false);
            cards.setMaximumSize(new Dimension(Integer.MAX_VALUE, 92));
            cards.add(createStatCard("Total Products", String.valueOf(totalProducts), GREEN));
            cards.add(createStatCard("Today's Sales", MONEY.format(todaySales), GREEN_DARK));
            cards.add(createStatCard("Today's Bills", String.valueOf(todayBills), new Color(59, 130, 246)));
            cards.add(createStatCard("Low Stock", String.valueOf(lowStock), new Color(217, 119, 6)));
            return cards;
        }

        private void refreshCategoryButtons(Container container) {
            for (Component c : container.getComponents()) {
                if (c instanceof JButton btn) {
                    String text = btn.getText();
                    boolean active = text.equals(currentCategory);
                    btn.setBackground(active ? GREEN : WHITE);
                    btn.setForeground(active ? WHITE : TEXT);
                    btn.setBorder(new RoundedBorder(16, active ? GREEN : BORDER, 1, true));
                }
            }
        }

        private void refreshProductGrid() {
            if (billingProductGrid == null) {
                return;
            }
            billingProductGrid.removeAll();
            for (Product product : filteredProducts) {
                billingProductGrid.add(createProductCard(product));
            }
            boolean empty = filteredProducts.isEmpty();
            CardLayout stateLayout = (CardLayout) billingProductState.getLayout();
            stateLayout.show(billingProductState, empty ? "EMPTY" : "GRID");
            billingProductGrid.revalidate();
            billingProductGrid.repaint();
        }

        private JPanel createProductCard(Product product) {
            JPanel card = new JPanel(new BorderLayout(0, 8));
            card.setBackground(SURFACE);
            Dimension cardSize = new Dimension(216, 268);
            card.setPreferredSize(cardSize);
            card.setMinimumSize(cardSize);
            card.setMaximumSize(cardSize);
            card.setBorder(BorderFactory.createCompoundBorder(
                    new RoundedBorder(14, BORDER, 1, true),
                    new EmptyBorder(10, 10, 10, 10)));

            JLabel image = new JLabel(createProductThumbnailIcon(product.getImagePath(), 184, 108));
            image.setHorizontalAlignment(SwingConstants.CENTER);
            image.setVerticalAlignment(SwingConstants.CENTER);
            Dimension imageSize = new Dimension(184, 108);
            image.setPreferredSize(imageSize);
            image.setMinimumSize(imageSize);
            image.setMaximumSize(imageSize);
            image.setOpaque(true);
            image.setBackground(new Color(248, 250, 252));
            image.setBorder(new RoundedBorder(10, new Color(226, 232, 240), 1, true));
            card.add(image, BorderLayout.NORTH);

            JPanel details = new JPanel();
            details.setOpaque(false);
            details.setLayout(new BoxLayout(details, BoxLayout.Y_AXIS));
            Dimension detailsSize = new Dimension(184, 82);
            details.setPreferredSize(detailsSize);
            details.setMinimumSize(detailsSize);
            details.setMaximumSize(detailsSize);
            JLabel category = new JLabel(product.getCategory());
            category.setOpaque(true);
            category.setBackground(new Color(236, 253, 245));
            category.setForeground(GREEN_DARK);
            category.setFont(new Font("SansSerif", Font.BOLD, 10));
            category.setBorder(new EmptyBorder(3, 7, 3, 7));
            category.setAlignmentX(Component.LEFT_ALIGNMENT);
            JLabel name = new JLabel("<html><div style='width:175px'>" + escapeHtml(product.getName()) + "</div></html>");
            name.setForeground(TEXT);
            name.setFont(new Font("SansSerif", Font.BOLD, 13));
            name.setAlignmentX(Component.LEFT_ALIGNMENT);
            JLabel stock = new JLabel(product.getStock() > 0
                    ? "Stock: " + product.getStock() + " " + product.getUnit()
                    : "Out of stock");
            stock.setForeground(product.getStock() > 0 ? MUTED : new Color(185, 28, 28));
            stock.setFont(new Font("SansSerif", Font.PLAIN, 11));
            stock.setAlignmentX(Component.LEFT_ALIGNMENT);
            details.add(category);
            details.add(Box.createVerticalStrut(5));
            details.add(name);
            details.add(Box.createVerticalStrut(3));
            details.add(stock);
            card.add(details, BorderLayout.CENTER);

            JPanel footer = new JPanel(new BorderLayout(8, 0));
            footer.setOpaque(false);
            Dimension footerSize = new Dimension(184, 30);
            footer.setPreferredSize(footerSize);
            footer.setMinimumSize(footerSize);
            footer.setMaximumSize(footerSize);
            JLabel price = new JLabel(MONEY.format(product.getPrice()) + " / " + product.getUnit());
            price.setForeground(TEXT);
            price.setFont(new Font("SansSerif", Font.BOLD, 15));
            JButton add = createPrimaryButton("Add");
            add.setFont(new Font("SansSerif", Font.BOLD, 12));
            add.setPreferredSize(new Dimension(68, 30));
            add.setEnabled(product.getStock() > 0);
            add.addActionListener(e -> addProductToCart(product));
            footer.add(price, BorderLayout.WEST);
            footer.add(add, BorderLayout.EAST);
            card.add(footer, BorderLayout.SOUTH);
            return card;
        }

        private String escapeHtml(String value) {
            if (value == null) return "";
            return value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
        }

        private void addTotalRow(Container parent, String labelText, JLabel valueLabel, boolean highlight,
                                GridBagConstraints gbc, int rowIndex) {
            JPanel row = new JPanel(new GridBagLayout());
            row.setOpaque(false);
            row.setBorder(new EmptyBorder(4, 0, 4, 0));
            row.setPreferredSize(new Dimension(0, highlight ? 38 : 28));

            JLabel label = new JLabel(labelText);
            label.setForeground(highlight ? TEXT : MUTED);
            label.setFont(new Font("SansSerif", Font.BOLD, highlight ? 18 : 13));
            label.setMinimumSize(new Dimension(120, 24));

            valueLabel.setForeground(highlight ? GREEN_DARK : TEXT);
            valueLabel.setFont(new Font("SansSerif", Font.BOLD, highlight ? 28 : 14));
            valueLabel.setHorizontalAlignment(SwingConstants.RIGHT);
            valueLabel.setPreferredSize(new Dimension(120, 28));

            GridBagConstraints rowGbc = new GridBagConstraints();
            rowGbc.gridx = 0;
            rowGbc.gridy = 0;
            rowGbc.weightx = 1.0;
            rowGbc.fill = GridBagConstraints.HORIZONTAL;
            rowGbc.anchor = GridBagConstraints.WEST;
            rowGbc.insets = new Insets(0, 0, 0, 10);
            row.add(label, rowGbc);

            rowGbc.gridx = 1;
            rowGbc.weightx = 0.0;
            rowGbc.fill = GridBagConstraints.NONE;
            rowGbc.anchor = GridBagConstraints.EAST;
            rowGbc.insets = new Insets(0, 0, 0, 0);
            row.add(valueLabel, rowGbc);

            gbc.gridy = rowIndex;
            parent.add(row, gbc);
        }

        private void addEditNumberRow(Container parent, String labelText, JTextField inputField, boolean highlight,
                                      GridBagConstraints gbc, int rowIndex) {
            JPanel row = new JPanel(new GridBagLayout());
            row.setOpaque(false);
            row.setBorder(new EmptyBorder(4, 0, 4, 0));
            row.setPreferredSize(new Dimension(0, 32));

            JLabel label = new JLabel(labelText);
            label.setForeground(highlight ? TEXT : MUTED);
            label.setFont(new Font("SansSerif", Font.BOLD, highlight ? 18 : 13));
            label.setMinimumSize(new Dimension(120, 24));

            inputField.setBackground(WHITE);
            inputField.setForeground(TEXT);
            inputField.setHorizontalAlignment(SwingConstants.RIGHT);
            inputField.setBorder(new RoundedBorder(8, BORDER, 1, true));
            inputField.setPreferredSize(new Dimension(120, 28));
            inputField.setMinimumSize(new Dimension(120, 28));
            inputField.setFont(new Font("SansSerif", Font.BOLD, 13));

            GridBagConstraints rowGbc = new GridBagConstraints();
            rowGbc.gridx = 0;
            rowGbc.gridy = 0;
            rowGbc.weightx = 1.0;
            rowGbc.fill = GridBagConstraints.HORIZONTAL;
            rowGbc.anchor = GridBagConstraints.WEST;
            rowGbc.insets = new Insets(0, 0, 0, 10);
            row.add(label, rowGbc);

            rowGbc.gridx = 1;
            rowGbc.weightx = 0.0;
            rowGbc.fill = GridBagConstraints.NONE;
            rowGbc.anchor = GridBagConstraints.EAST;
            rowGbc.insets = new Insets(0, 0, 0, 0);
            row.add(inputField, rowGbc);

            gbc.gridy = rowIndex;
            parent.add(row, gbc);
        }

        private JButton createPrimaryButton(String text) {
            JButton btn = new JButton(text);
            btn.setBackground(GREEN);
            btn.setForeground(WHITE);
            btn.setFocusPainted(false);
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btn.setFont(new Font("SansSerif", Font.BOLD, 14));
            btn.setBorder(new RoundedBorder(12, GREEN, 1, true));
            btn.setOpaque(true);
            return btn;
        }

        private JButton createSecondaryButton(String text) {
            JButton btn = new JButton(text);
            btn.setBackground(WHITE);
            btn.setForeground(TEXT);
            btn.setFocusPainted(false);
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btn.setFont(new Font("SansSerif", Font.BOLD, 13));
            btn.setBorder(new RoundedBorder(12, BORDER, 1, true));
            btn.setOpaque(true);
            return btn;
        }

        private JButton createFilterButton(String text, boolean active) {
            JButton btn = new JButton(text);
            btn.setFocusPainted(false);
            btn.setBackground(active ? GREEN : WHITE);
            btn.setForeground(active ? WHITE : TEXT);
            btn.setBorder(new RoundedBorder(16, active ? GREEN : BORDER, 1, true));
            btn.setFont(new Font("SansSerif", Font.BOLD, 12));
            btn.setPreferredSize(new Dimension(text.length() > 10 ? 110 : 72, 32));
            btn.setOpaque(true);
            btn.setCursor(new Cursor(Cursor.HAND_CURSOR));
            btn.setToolTipText("Filter products by category");
            return btn;
        }

        private File chooseProductPhotoFile() {
            JFileChooser chooser = new JFileChooser();
            chooser.setDialogTitle("Select Product Photo");
            chooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
            chooser.setAcceptAllFileFilterUsed(false);
            chooser.addChoosableFileFilter(new FileNameExtensionFilter("Images (*.jpg, *.jpeg, *.png, *.webp)", "jpg", "jpeg", "png", "webp"));
            int result = chooser.showOpenDialog(this);
            if (result != JFileChooser.APPROVE_OPTION) {
                return null;
            }
            File selectedFile = chooser.getSelectedFile();
            if (selectedFile == null || !selectedFile.exists()) {
                JOptionPane.showMessageDialog(this, "Please choose a valid image file.", "Invalid Photo", JOptionPane.WARNING_MESSAGE);
                return null;
            }
            String lowerName = selectedFile.getName().toLowerCase();
            boolean validType = lowerName.endsWith(".jpg") || lowerName.endsWith(".jpeg") || lowerName.endsWith(".png") || lowerName.endsWith(".webp");
            if (!validType) {
                JOptionPane.showMessageDialog(this, "Only JPG, JPEG, PNG, and WEBP images are allowed.", "Invalid Photo", JOptionPane.WARNING_MESSAGE);
                return null;
            }
            if (selectedFile.length() > MAX_PRODUCT_PHOTO_SIZE_BYTES) {
                JOptionPane.showMessageDialog(this, "Please select an image smaller than 5MB.", "File Too Large", JOptionPane.WARNING_MESSAGE);
                return null;
            }
            if (ImageUtils.read(selectedFile.getAbsolutePath()) == null) {
                JOptionPane.showMessageDialog(this, "The selected file is not a readable image.", "Invalid Photo", JOptionPane.WARNING_MESSAGE);
                return null;
            }
            return selectedFile;
        }

        private String persistProductPhoto(File sourceFile) {
            try {
                Path storageDir = Paths.get(PRODUCT_PHOTO_STORAGE_FOLDER);
                Files.createDirectories(storageDir);
                String originalName = sourceFile.getName();
                String extension = originalName.contains(".") ? originalName.substring(originalName.lastIndexOf('.')) : ".png";
                String safeName = System.currentTimeMillis() + "_" + originalName.replaceAll("[^a-zA-Z0-9._-]", "_");
                Path targetPath = storageDir.resolve(safeName);
                Files.copy(sourceFile.toPath(), targetPath, StandardCopyOption.REPLACE_EXISTING);
                return targetPath.toAbsolutePath().toString();
            } catch (IOException ex) {
                JOptionPane.showMessageDialog(this, "Unable to save selected photo: " + ex.getMessage(), "Photo Save Error", JOptionPane.ERROR_MESSAGE);
                return null;
            }
        }

        private void applyProductPhotoPreview(JLabel previewLabel, String imagePath) {
            previewLabel.setHorizontalAlignment(SwingConstants.CENTER);
            previewLabel.setOpaque(true);
            previewLabel.setBackground(new Color(248, 250, 252));
            previewLabel.setBorder(new RoundedBorder(12, BORDER, 1, true));
            previewLabel.setText("No photo selected");
            previewLabel.setIcon(null);
            if (imagePath == null || imagePath.trim().isEmpty()) {
                return;
            }
            File imageFile = new File(imagePath);
            if (!imageFile.exists()) {
                previewLabel.setText("Photo not found");
                return;
            }
            BufferedImage sourceImage = ImageUtils.read(imagePath);
            if (sourceImage == null) {
                previewLabel.setText("Invalid photo");
                return;
            }
                int targetWidth = 150;
                int targetHeight = 120;
                previewLabel.setIcon(ImageUtils.loadCover(imagePath, targetWidth, targetHeight));
                previewLabel.setText("");
                previewLabel.setHorizontalTextPosition(SwingConstants.CENTER);
        }

        private ImageIcon createProductThumbnailIcon(String imagePath, int width, int height) {
            return ImageUtils.loadCover(imagePath, width, height);
        }

        private JLabel createEmptyStateLabel(String htmlText) {
            JLabel label = new JLabel(htmlText);
            label.setHorizontalAlignment(SwingConstants.CENTER);
            label.setVerticalAlignment(SwingConstants.CENTER);
            label.setForeground(MUTED);
            label.setFont(new Font("SansSerif", Font.BOLD, 14));
            label.setBorder(new EmptyBorder(28, 24, 28, 24));
            label.setVisible(false);
            return label;
        }

        private JPanel createBillingEmptyState() {
            JPanel panel = new JPanel();
            panel.setOpaque(false);
            panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
            panel.setBorder(new EmptyBorder(42, 24, 42, 24));

            JLabel title = new JLabel("No products available");
            title.setForeground(TEXT);
            title.setFont(new Font("SansSerif", Font.BOLD, 17));
            title.setAlignmentX(Component.CENTER_ALIGNMENT);

            JLabel message = new JLabel("Add products from the Products section to start billing.");
            message.setForeground(MUTED);
            message.setFont(new Font("SansSerif", Font.PLAIN, 13));
            message.setAlignmentX(Component.CENTER_ALIGNMENT);

            JButton addProduct = createPrimaryButton("+  Add Product");
            addProduct.setAlignmentX(Component.CENTER_ALIGNMENT);
            addProduct.addActionListener(e -> openAddProductDialog());

            panel.add(Box.createVerticalGlue());
            panel.add(title);
            panel.add(Box.createVerticalStrut(8));
            panel.add(message);
            panel.add(Box.createVerticalStrut(16));
            panel.add(addProduct);
            panel.add(Box.createVerticalGlue());
            return panel;
        }

        private void refreshBillingEmptyStates() {
            if (productTable != null) {
                boolean noProducts = filteredProducts.isEmpty();
                productTable.setVisible(!noProducts);
                billingNoResultsPanel.setVisible(noProducts);
            }
            if (cartScrollPane != null) {
                boolean noCartItems = cartItems.isEmpty();
                cartScrollPane.setVisible(!noCartItems);
                cartEmptyLabel.setVisible(noCartItems);
                if (cartState != null) {
                    CardLayout stateLayout = (CardLayout) cartState.getLayout();
                    stateLayout.show(cartState, noCartItems ? "EMPTY" : "CART");
                }
            }
        }

        private void showToast(String message) {
            JWindow toast = new JWindow(this);
            JPanel panel = new JPanel(new BorderLayout());
            panel.setBackground(new Color(9, 118, 73));
            panel.setBorder(new RoundedBorder(14, new Color(9, 118, 73), 1, true));
            panel.setBorder(new EmptyBorder(12, 18, 12, 18));
            JLabel label = new JLabel(message);
            label.setForeground(WHITE);
            label.setFont(new Font("SansSerif", Font.BOLD, 12));
            label.setHorizontalAlignment(SwingConstants.CENTER);
            panel.add(label, BorderLayout.CENTER);
            toast.setContentPane(panel);
            toast.pack();
            Point origin = this.getLocationOnScreen();
            toast.setLocation(origin.x + this.getWidth() - toast.getWidth() - 32, origin.y + this.getHeight() - toast.getHeight() - 36);
            toast.setAlwaysOnTop(true);
            toast.setVisible(true);
            Timer timer = new Timer(1800, e -> toast.dispose());
            timer.setRepeats(false);
            timer.start();
        }

        private void seedProducts() {
            productCatalog.clear();
            try {
                ProductDao productDao = new ProductDao();
                List<org.example.model.Product> dbProducts = productDao.findAll();
                java.util.Map<String, org.example.model.Product> existingProducts = new java.util.HashMap<>();
                for (org.example.model.Product dbProduct : dbProducts) {
                    if (dbProduct.getProductName() == null || dbProduct.getProductName().isBlank()) {
                        continue;
                    }
                    existingProducts.put(dbProduct.getProductName().trim().toLowerCase(), dbProduct);
                }
                List<Product> catalogDefaults = createCatalogDefaults();
                for (Product catalogProduct : catalogDefaults) {
                    org.example.model.Product dbProduct = existingProducts.get(catalogProduct.getName().toLowerCase());
                    if (dbProduct == null) {
                        org.example.model.Product newProduct = new org.example.model.Product(
                                0, catalogProduct.getName(), catalogProduct.getCategory(), catalogProduct.getUnit(),
                                catalogProduct.getPrice(), catalogProduct.getStock(), null, catalogProduct.getImagePath());
                        productDao.save(newProduct);
                    }
                }
                for (org.example.model.Product dbProduct : productDao.findAll()) {
                    if (dbProduct.getProductName() == null || dbProduct.getProductName().isBlank()) {
                        continue;
                    }
                    Product product = new Product(
                            dbProduct.getProductId(),
                            dbProduct.getProductName(),
                            dbProduct.getCategory(),
                            dbProduct.getUnit(),
                            dbProduct.getPrice(),
                            dbProduct.getStock(),
                            0.0,
                            dbProduct.getProductPhotoPath()
                    );
                    product.setBarcode(dbProduct.getBarcode());
                    product.setMinimumStockLevel(dbProduct.getMinimumStockLevel());
                    productCatalog.add(product);
                }
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Unable to load products: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
            }
            applyProductFilter();
            if (productsPanelSearchField != null && productsPanelCategoryFilter != null) {
                refreshProductPanelTable(productsPanelSearchField.getText(),
                        String.valueOf(productsPanelCategoryFilter.getSelectedItem()));
            }
            updateProductSummary();
        }

        private List<Product> createCatalogDefaults() {
            String folder = PRODUCT_PHOTO_STORAGE_FOLDER;
            return List.of(
                    new Product(0, "Basmati Rice 1kg", "Grocery", "kg", 80.00, 48, 0.0, folder + "/basmati-rice-1kg.png"),
                    new Product(0, "Sugar 1kg", "Grocery", "kg", 45.00, 40, 0.0, folder + "/sugar-1kg.png"),
                    new Product(0, "Sunflower Oil 1L", "Grocery", "ltr", 150.00, 30, 0.0, folder + "/sunflower-oil-1l.png"),
                    new Product(0, "Milk 1L", "Dairy", "ltr", 60.00, 35, 0.0, folder + "/milk-1l.png"),
                    new Product(0, "Tata Tea 250g", "Beverages", "pack", 120.00, 25, 0.0, folder + "/tata-tea-250g.png"),
                    new Product(0, "Maggi Noodles", "Snacks", "pack", 15.00, 60, 0.0, folder + "/maggi-noodles.png"),
                    new Product(0, "Colgate Toothpaste", "Personal Care", "pcs", 95.00, 20, 0.0, folder + "/colgate-toothpaste.png"),
                    new Product(0, "Pantene Shampoo", "Personal Care", "btl", 210.00, 16, 0.0, folder + "/pantene-shampoo.png"),
                    new Product(0, "Lux Soap", "Personal Care", "pcs", 40.00, 28, 0.0, folder + "/lux-soap.png"),
                    new Product(0, "Surf Excel", "Household", "pack", 120.00, 18, 0.0, folder + "/surf-excel.png"),
                    new Product(0, "Wheat Flour 1kg", "Grocery", "kg", 55.00, 32, 0.0, folder + "/wheat-flour-1kg.png"),
                    new Product(0, "Horlicks 500g", "Grocery", "jar", 250.00, 14, 0.0, folder + "/horlicks-500g.png"),
                    new Product(0, "Bru Coffee 50g", "Beverages", "jar", 150.00, 22, 0.0, folder + "/bru-coffee-50g.png"),
                    new Product(0, "Kissan Ketchup", "Grocery", "btl", 130.00, 19, 0.0, folder + "/kissan-ketchup.png"),
                    new Product(0, "Parle-G Biscuits", "Snacks", "pack", 20.00, 45, 0.0, folder + "/parle-g-biscuits.png"),
                    new Product(0, "Harpic Toilet Cleaner", "Household", "btl", 180.00, 12, 0.0, folder + "/harpic-toilet-cleaner.png")
                    , new Product(0, "Bread", "Bakery", "loaf", 45.00, 20, 0.0, folder + "/bread.png")
                    , new Product(0, "Buns", "Bakery", "pack", 35.00, 18, 0.0, folder + "/buns.png")
                    , new Product(0, "Cake", "Bakery", "pcs", 280.00, 8, 0.0, folder + "/cake.png")
                    , new Product(0, "Cooking Salt 1kg", "Grocery", "kg", 28.00, 36, 0.0, folder + "/salt-1kg.png")
                    , new Product(0, "Fruit Juice 1L", "Beverages", "ltr", 110.00, 24, 0.0, folder + "/fruit-juice-1l.png")
                    , new Product(0, "Mineral Water 1L", "Beverages", "btl", 20.00, 50, 0.0, folder + "/mineral-water-1l.png")
                    , new Product(0, "Curd 500g", "Dairy", "pack", 70.00, 22, 0.0, folder + "/curd-500g.png")
                    , new Product(0, "Butter 100g", "Dairy", "pack", 65.00, 15, 0.0, folder + "/butter-100g.png")
                    , new Product(0, "Potato Chips", "Snacks", "pack", 30.00, 32, 0.0, folder + "/potato-chips.png")
                    , new Product(0, "Dishwash Liquid", "Household", "btl", 95.00, 14, 0.0, folder + "/dishwash-liquid.png")
                    , new Product(0, "Tissue Paper", "Household", "pack", 75.00, 16, 0.0, folder + "/tissue-paper.png")
                    , new Product(0, "Toothbrush", "Personal Care", "pcs", 55.00, 20, 0.0, folder + "/toothbrush.png")
                    , new Product(0, "Aashirvaad Atta 5kg", "Grocery", "bag", 275.00, 25, 0.0, folder + "/aashirvaad-atta-5kg.png")
                    , new Product(0, "India Gate Basmati Rice 5kg", "Grocery", "bag", 620.00, 12, 0.0, folder + "/india-gate-rice-5kg.png")
                    , new Product(0, "Amul Butter 500g", "Dairy", "pack", 285.00, 10, 0.0, folder + "/amul-butter-500g.png")
                    , new Product(0, "Nescafe Classic 100g", "Beverages", "jar", 315.00, 11, 0.0, folder + "/nescafe-classic-100g.png")
                    , new Product(0, "Red Bull 250ml", "Beverages", "can", 125.00, 9, 0.0, folder + "/red-bull-250ml.png")
                    , new Product(0, "Handwash 250ml", "Personal Care", "btl", 85.00, 13, 0.0, folder + "/handwash-250ml.png")
                    , new Product(0, "Floor Cleaner 1L", "Household", "btl", 145.00, 10, 0.0, folder + "/floor-cleaner-1l.png")
                    , new Product(0, "Cookies 200g", "Snacks", "pack", 60.00, 21, 0.0, folder + "/cookies-200g.png")
            );
        }

        private void loadProductsIntoTable() {
            applyProductFilter();
        }

        private void applyProductFilter() {
            filteredProducts.clear();
            String search = currentSearchText == null ? "" : currentSearchText.trim().toLowerCase();
            for (Product product : productCatalog) {
                String productName = product.getName() == null ? "" : product.getName();
                String productCategory = product.getCategory() == null ? "" : product.getCategory();
                boolean matchesCategory = "All".equals(currentCategory) || productCategory.equalsIgnoreCase(currentCategory);
                boolean matchesSearch = search.isEmpty() ||
                        productName.toLowerCase().contains(search) ||
                        productCategory.toLowerCase().contains(search) ||
                        String.valueOf(product.getId()).contains(search) ||
                        (product.getBarcode() != null && product.getBarcode().contains(search));
                if (matchesCategory && matchesSearch) {
                    filteredProducts.add(product);
                }
            }
            productModel.setRowCount(0);
            for (int i = 0; i < filteredProducts.size(); i++) {
                Product product = filteredProducts.get(i);
                productModel.addRow(new Object[]{i + 1, product.getName(), product.getCategory(), product.getUnit(), MONEY.format(product.getPrice()), "+"});
            }
            if (productTable.getColumnModel().getColumnCount() > 5) {
                productTable.getColumnModel().getColumn(5).setCellRenderer(new AddActionRenderer());
                productTable.getColumnModel().getColumn(5).setCellEditor(new AddActionEditor());
            }
            refreshBillingEmptyStates();
            refreshProductGrid();
            if (billingCountLabel != null) {
                billingCountLabel.setText(filteredProducts.size() + " products available");
            }
        }

        private void handleLogin() {
            String user = usernameField.getText().trim();
            String pass = new String(passwordField.getPassword()).trim();
            try {
                org.example.model.User loggedUser = new UserDao().authenticate(user, pass);
                if (loggedUser == null) {
                    JOptionPane.showMessageDialog(this,
                            "Invalid username or password.",
                            "Login Failed",
                            JOptionPane.ERROR_MESSAGE);
                    return;
                }
                mainLayout.show(mainCards, "DASHBOARD");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this,
                        "Login failed: " + ex.getMessage(),
                        "Database Error",
                        JOptionPane.ERROR_MESSAGE);
            }
        }

        private void handleLogout() {
            clearCart();
            usernameField.setText("admin");
            passwordField.setText("1234");
            mainLayout.show(mainCards, "LOGIN");
        }

        private void installShortcuts() {
            JRootPane root = getRootPane();
            InputMap input = root.getInputMap(JComponent.WHEN_IN_FOCUSED_WINDOW);
            ActionMap actions = root.getActionMap();
            input.put(KeyStroke.getKeyStroke("F2"), "focusBillingSearch");
            actions.put("focusBillingSearch", new AbstractAction() {
                @Override public void actionPerformed(ActionEvent e) {
                    if (billingSearchField != null) {
                        sectionLayout.show(sectionCards, "BILLING");
                        billingSearchField.requestFocusInWindow();
                    }
                }
            });
            input.put(KeyStroke.getKeyStroke("F3"), "scanBarcode");
            actions.put("scanBarcode", new AbstractAction() {
                @Override public void actionPerformed(ActionEvent e) { simulateScanAndAdd(); }
            });
            input.put(KeyStroke.getKeyStroke("F5"), "payNow");
            actions.put("payNow", new AbstractAction() {
                @Override public void actionPerformed(ActionEvent e) { completeOrder(); }
            });
            input.put(KeyStroke.getKeyStroke("F8"), "holdBill");
            actions.put("holdBill", new AbstractAction() {
                @Override public void actionPerformed(ActionEvent e) { holdBill(); }
            });
            input.put(KeyStroke.getKeyStroke("ESCAPE"), "clearRegister");
            actions.put("clearRegister", new AbstractAction() {
                @Override public void actionPerformed(ActionEvent e) {
                    if (billingSearchField != null) billingSearchField.setText("");
                    clearCart();
                }
            });
        }

        private void performGlobalSearch() {
            String query = globalSearchField == null ? "" : globalSearchField.getText().trim();
            if (query.isEmpty()) return;
            boolean productFound = false;
            for (Product product : productCatalog) {
                if (product.getName().toLowerCase().contains(query.toLowerCase())
                        || (product.getBarcode() != null && product.getBarcode().contains(query))) {
                    productFound = true;
                    break;
                }
            }
            if (productFound && billingSearchField != null) {
                sectionLayout.show(sectionCards, "BILLING");
                billingSearchField.setText(query);
                showToast("Showing matching products");
            } else {
                sectionLayout.show(sectionCards, "SALES");
                showToast("Searching sales for \"" + query + "\"");
            }
        }

        private void showNotifications() {
            try {
                List<org.example.model.Product> low = new ProductDao().findLowStockProducts();
                if (low.isEmpty()) {
                    JOptionPane.showMessageDialog(this, "All inventory levels look healthy.",
                            "Notifications", JOptionPane.INFORMATION_MESSAGE);
                    return;
                }
                StringBuilder message = new StringBuilder("Low stock alerts:\n\n");
                for (int i = 0; i < Math.min(8, low.size()); i++) {
                    org.example.model.Product product = low.get(i);
                    message.append("• ").append(product.getProductName())
                            .append(" — ").append(product.getStock()).append(" left\n");
                }
                JOptionPane.showMessageDialog(this, message.toString(),
                        "Notifications (" + low.size() + ")", JOptionPane.WARNING_MESSAGE);
            } catch (SQLException ex) {
                JOptionPane.showMessageDialog(this, "Unable to load notifications: " + ex.getMessage(),
                        "Notifications", JOptionPane.ERROR_MESSAGE);
            }
        }

        private void openAddProductDialog() {
            openProductEntryDialog(null, false);
        }

        private void openEditProductDialog(Product product) {
            if (product == null) {
                return;
            }
            openProductEntryDialog(product, true);
        }

        private void openProductEntryDialog(Product product, boolean isEdit) {
            JDialog dialog = new JDialog(this, isEdit ? "Edit Product" : "Add Product", true);
            dialog.setLayout(new GridBagLayout());
            dialog.setSize(540, 680);
            dialog.setLocationRelativeTo(this);
            dialog.setResizable(false);

            JPanel form = new JPanel(new GridBagLayout());
            form.setBackground(SURFACE);
            form.setBorder(new EmptyBorder(20, 20, 20, 20));

            GridBagConstraints gbc = new GridBagConstraints();
            gbc.insets = new Insets(8, 8, 8, 8);
            gbc.fill = GridBagConstraints.HORIZONTAL;
            gbc.gridx = 0;
            gbc.weightx = 0;

            JLabel nameLabel = new JLabel("Name");
            nameLabel.setForeground(TEXT);
            nameLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            form.add(nameLabel, gbc);
            gbc.gridx = 1;
            gbc.weightx = 1;
            JTextField nameField = new JTextField(product == null ? "" : product.getName());
            nameField.setBorder(new RoundedBorder(10, BORDER, 1, true));
            form.add(nameField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 1;
            gbc.weightx = 0;
            JLabel categoryLabel = new JLabel("Category");
            categoryLabel.setForeground(TEXT);
            categoryLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            form.add(categoryLabel, gbc);
            gbc.gridx = 1;
            gbc.weightx = 1;
            JComboBox<String> categoryBox = new JComboBox<>(new String[]{"Grocery", "Beverages", "Dairy", "Snacks", "Personal Care", "Household", "Bakery"});
            categoryBox.setBackground(WHITE);
            categoryBox.setForeground(TEXT);
            categoryBox.setBorder(new RoundedBorder(10, BORDER, 1, true));
            if (product != null) {
                categoryBox.setSelectedItem(product.getCategory());
            }
            form.add(categoryBox, gbc);

            gbc.gridx = 0;
            gbc.gridy = 2;
            gbc.weightx = 0;
            JLabel unitLabel = new JLabel("Unit");
            unitLabel.setForeground(TEXT);
            unitLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            form.add(unitLabel, gbc);
            gbc.gridx = 1;
            gbc.weightx = 1;
            JTextField unitField = new JTextField(product == null ? "kg" : product.getUnit());
            unitField.setBorder(new RoundedBorder(10, BORDER, 1, true));
            form.add(unitField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 3;
            gbc.weightx = 0;
            JLabel priceLabel = new JLabel("Price");
            priceLabel.setForeground(TEXT);
            priceLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            form.add(priceLabel, gbc);
            gbc.gridx = 1;
            gbc.weightx = 1;
            JTextField priceField = new JTextField(product == null ? "" : String.valueOf(product.getPrice()));
            priceField.setBorder(new RoundedBorder(10, BORDER, 1, true));
            form.add(priceField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 4;
            gbc.weightx = 0;
            JLabel stockLabel = new JLabel("Stock");
            stockLabel.setForeground(TEXT);
            stockLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            form.add(stockLabel, gbc);
            gbc.gridx = 1;
            gbc.weightx = 1;
            JTextField stockField = new JTextField(product == null ? "0" : String.valueOf(product.getStock()));
            stockField.setBorder(new RoundedBorder(10, BORDER, 1, true));
            form.add(stockField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 5;
            gbc.weightx = 0;
            JLabel minimumStockLabel = new JLabel("Low-stock threshold");
            minimumStockLabel.setForeground(TEXT);
            minimumStockLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            form.add(minimumStockLabel, gbc);
            gbc.gridx = 1;
            gbc.weightx = 1;
            JTextField minimumStockField = new JTextField(product == null ? "5" : String.valueOf(Math.max(1, product.getStock() / 2)));
            minimumStockField.setBorder(new RoundedBorder(10, BORDER, 1, true));
            form.add(minimumStockField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 6;
            gbc.weightx = 0;
            JLabel barcodeLabel = new JLabel("Barcode / Product ID");
            barcodeLabel.setForeground(TEXT);
            barcodeLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            form.add(barcodeLabel, gbc);
            gbc.gridx = 1;
            gbc.weightx = 1;
            JTextField barcodeField = new JTextField(product == null ? "" : product.getBarcode());
            barcodeField.setBorder(new RoundedBorder(10, BORDER, 1, true));
            form.add(barcodeField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 7;
            gbc.weightx = 0;
            JLabel taxRateLabel = new JLabel("Tax (%)");
            taxRateLabel.setForeground(TEXT);
            taxRateLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            form.add(taxRateLabel, gbc);
            gbc.gridx = 1;
            gbc.weightx = 1;
            JTextField taxRateField = new JTextField("0");
            taxRateField.setBorder(new RoundedBorder(10, BORDER, 1, true));
            form.add(taxRateField, gbc);

            gbc.gridx = 0;
            gbc.gridy = 8;
            gbc.weightx = 0;
            JLabel photoLabel = new JLabel("Product Photo");
            photoLabel.setForeground(TEXT);
            photoLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
            form.add(photoLabel, gbc);
            gbc.gridx = 1;
            gbc.weightx = 1;
            JPanel photoPanel = new JPanel(new BorderLayout(8, 0));
            photoPanel.setOpaque(false);
            final String[] selectedPhotoPath = {product == null ? null : product.getImagePath()};
            JLabel photoPreview = new JLabel();
            photoPreview.setPreferredSize(new Dimension(180, 110));
            photoPreview.setMinimumSize(new Dimension(180, 110));
            photoPreview.setHorizontalAlignment(SwingConstants.CENTER);
            photoPreview.setVerticalAlignment(SwingConstants.CENTER);
            photoPreview.setOpaque(true);
            photoPreview.setBackground(new Color(248, 250, 252));
            photoPreview.setBorder(new RoundedBorder(12, BORDER, 1, true));
            applyProductPhotoPreview(photoPreview, selectedPhotoPath[0]);
            JButton choosePhotoBtn = createSecondaryButton("Choose Photo");
            choosePhotoBtn.setToolTipText("Select a product image from your computer");
            choosePhotoBtn.addActionListener(e -> {
                File selectedFile = chooseProductPhotoFile();
                if (selectedFile != null) {
                    String storedPath = persistProductPhoto(selectedFile);
                    if (storedPath != null) {
                        selectedPhotoPath[0] = storedPath;
                        applyProductPhotoPreview(photoPreview, storedPath);
                    }
                }
            });
            JButton removePhotoBtn = createSecondaryButton("Remove Photo");
            removePhotoBtn.addActionListener(e -> {
                selectedPhotoPath[0] = null;
                applyProductPhotoPreview(photoPreview, null);
            });
            JPanel chooseActions = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
            chooseActions.setOpaque(false);
            chooseActions.add(choosePhotoBtn);
            chooseActions.add(removePhotoBtn);
            photoPanel.add(chooseActions, BorderLayout.NORTH);
            photoPanel.add(photoPreview, BorderLayout.CENTER);
            form.add(photoPanel, gbc);

            JButton saveBtn = createPrimaryButton(isEdit ? "Save Changes" : "Add Product");
            saveBtn.addActionListener(e -> {
                String name = nameField.getText().trim();
                String category = (String) categoryBox.getSelectedItem();
                String unit = unitField.getText().trim();
                String priceRaw = priceField.getText().trim();
                String stockRaw = stockField.getText().trim();
                String taxRaw = taxRateField.getText().trim();

                if (name.isEmpty() || unit.isEmpty() || priceRaw.isEmpty() || stockRaw.isEmpty()) {
                    JOptionPane.showMessageDialog(dialog, "Please fill in all required fields.", "Validation Error", JOptionPane.WARNING_MESSAGE);
                    return;
                }
                try {
                    double price;
                    int stock;
                    int minimumStock;
                    double taxRate;
                    try {
                        price = parseNonNegativeDecimal(priceRaw, "Price");
                        stock = parseNonNegativeInteger(stockRaw, "Stock");
                        minimumStock = parseNonNegativeInteger(minimumStockField.getText().trim(),
                                "Low-stock threshold");
                        taxRate = taxRaw.isEmpty() ? 0.0 : parseNonNegativeDecimal(taxRaw, "Tax");
                    } catch (IllegalArgumentException validationError) {
                        JOptionPane.showMessageDialog(dialog, validationError.getMessage(),
                                "Validation Error", JOptionPane.WARNING_MESSAGE);
                        return;
                    }
                    org.example.model.Product modelProduct = new org.example.model.Product();
                    if (isEdit && product != null) {
                        modelProduct.setProductId(product.getId());
                    }
                    modelProduct.setProductName(name);
                    modelProduct.setCategory(category);
                    modelProduct.setUnit(unit);
                    modelProduct.setPrice(price);
                    modelProduct.setStock(stock);
                    modelProduct.setMinimumStockLevel(minimumStock);
                    modelProduct.setProductPhotoPath(selectedPhotoPath[0]);
                    modelProduct.setBarcode(barcodeField.getText().trim().isEmpty() ? null : barcodeField.getText().trim());
                    modelProduct.setExpiryDate(null);
                    new ProductDao().save(modelProduct);
                    seedProducts();
                    applyProductFilter();
                    showToast(isEdit ? "Product updated successfully" : "Product added successfully");
                    JOptionPane.showMessageDialog(dialog, isEdit ? "Product updated successfully." : "Product saved successfully.", "Success", JOptionPane.INFORMATION_MESSAGE);
                    dialog.dispose();
                } catch (Exception ex) {
                    JOptionPane.showMessageDialog(dialog, "Unable to save product: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                }
            });

            JButton cancelBtn = createSecondaryButton("Cancel");
            cancelBtn.addActionListener(e -> dialog.dispose());

            JPanel actionPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
            actionPanel.setOpaque(false);
            actionPanel.add(cancelBtn);
            actionPanel.add(saveBtn);

            gbc.gridx = 0;
            gbc.gridy = 9;
            gbc.gridwidth = 2;
            gbc.weightx = 1;
            gbc.fill = GridBagConstraints.HORIZONTAL;
            form.add(actionPanel, gbc);
            dialog.add(form);
            dialog.setVisible(true);
        }

        private void simulateScanAndAdd() {
            String barcode = JOptionPane.showInputDialog(this, "Enter product barcode or ID:", "Scan Barcode", JOptionPane.QUESTION_MESSAGE);
            if (barcode == null || barcode.trim().isEmpty()) return;
            String value = barcode.trim();
            for (Product product : productCatalog) {
                if (value.equals(product.getBarcode()) || value.equals(String.valueOf(product.getId()))) {
                    addProductToCart(product);
                    return;
                }
            }
            JOptionPane.showMessageDialog(this, "No product found for barcode/ID " + value + ".", "Scan", JOptionPane.WARNING_MESSAGE);
        }

        private void addProductToCart(Product product) {
            int currentQtyInCart = 0;
            for (CartItem item : cartItems) {
                if (item.getProduct().getId() == product.getId()) {
                    currentQtyInCart = item.getQuantity();
                    if (item.getQuantity() >= product.getStock()) {
                        JOptionPane.showMessageDialog(this,
                                "Insufficient stock for " + product.getName() + ". Available: " + product.getStock(),
                                "Stock Limit",
                                JOptionPane.WARNING_MESSAGE);
                        return;
                    }
                    item.setQuantity(item.getQuantity() + 1);
                    refreshCartTotals();
                    showToast(product.getName() + " added to bill");
                    return;
                }
            }
            if (product.getStock() <= 0) {
                JOptionPane.showMessageDialog(this,
                        "Insufficient stock for " + product.getName() + ". Available: 0",
                        "Stock Limit",
                        JOptionPane.WARNING_MESSAGE);
                return;
            }
            cartItems.add(new CartItem(product, 1));
            refreshCartTotals();
            showToast(product.getName() + " added to bill");
        }

        private void refreshCartTotals() {
            cartModel.setRowCount(0);
            double subtotal = 0.0;
            double totalTax = 0.0;
            for (int i = 0; i < cartItems.size(); i++) {
                CartItem item = cartItems.get(i);
                subtotal += item.getTotalPrice();
                totalTax += item.getItemTax();
                cartModel.addRow(new Object[]{
                        item.getProduct().getImagePath(),
                        item.getProduct().getName(),
                        item.getQuantity(),
                        MONEY.format(item.getProduct().getPrice()),
                        MONEY.format(item.getTotalPrice()),
                        "Remove"
                });
            }

            double discount = parseCurrencyField(discountField.getText());
            double grandTotal = subtotal - discount + totalTax;

            subtotalLabel.setText(MONEY.format(subtotal));
            discountLabel.setText(MONEY.format(discount));
            taxLabel.setText(MONEY.format(totalTax));
            taxField.setText(MONEY.format(totalTax));
            grandTotalLabel.setText(MONEY.format(grandTotal));
            refreshBillingEmptyStates();
        }

        private void clearCart() {
            cartItems.clear();
            cartModel.setRowCount(0);
            subtotalLabel.setText("₹ 0.00");
            discountLabel.setText("₹ 0.00");
            taxLabel.setText("₹ 0.00");
            grandTotalLabel.setText("₹ 0.00");
            discountField.setText("0.00");
            taxField.setText("0.00");
            refreshBillingEmptyStates();
        }

        private double parseCurrencyField(String rawValue) {
            if (rawValue == null || rawValue.trim().isEmpty()) {
                return 0.0;
            }
            try {
                return Double.parseDouble(rawValue.trim());
            } catch (NumberFormatException ex) {
                return 0.0;
            }
        }

        private String getSelectedPaymentMethod() {
            if (cardPayment.isSelected()) return "Card";
            if (upiPayment.isSelected()) return "UPI";
            return "Cash";
        }

        private double parseNonNegativeDecimal(String rawValue, String fieldName) {
            if (rawValue == null || rawValue.trim().isEmpty()) {
                throw new IllegalArgumentException(fieldName + " is required.");
            }
            try {
                double value = Double.parseDouble(rawValue.trim());
                if (!Double.isFinite(value) || value < 0) {
                    throw new NumberFormatException();
                }
                return value;
            } catch (NumberFormatException ex) {
                throw new IllegalArgumentException(fieldName + " must be a valid number, for example 10 or 10.50.");
            }
        }

        private int parseNonNegativeInteger(String rawValue, String fieldName) {
            if (rawValue == null || rawValue.trim().isEmpty()) {
                throw new IllegalArgumentException(fieldName + " is required.");
            }
            try {
                int value = Integer.parseInt(rawValue.trim());
                if (value < 0) throw new NumberFormatException();
                return value;
            } catch (NumberFormatException ex) {
                throw new IllegalArgumentException(fieldName + " must be a non-negative whole number.");
            }
        }

        private static class SimpleDocumentListener implements DocumentListener {
            private final Runnable callback;

            private SimpleDocumentListener(Runnable callback) {
                this.callback = callback;
            }

            @Override
            public void insertUpdate(DocumentEvent e) { callback.run(); }

            @Override
            public void removeUpdate(DocumentEvent e) { callback.run(); }

            @Override
            public void changedUpdate(DocumentEvent e) { callback.run(); }
        }

        private void holdBill() {
            if (cartItems.isEmpty()) {
                JOptionPane.showMessageDialog(this, "No bill to hold.", "Hold Bill", JOptionPane.WARNING_MESSAGE);
                return;
            }
            heldBill.clear();
            for (CartItem item : cartItems) {
                heldBill.add(new CartItem(item.getProduct(), item.getQuantity()));
            }
            clearCart();
            JOptionPane.showMessageDialog(this, "Current bill held successfully.", "Hold Bill", JOptionPane.INFORMATION_MESSAGE);
        }

        private void saveDraft() {
            if (cartItems.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Add at least one item before saving a draft.",
                        "Save Draft", JOptionPane.WARNING_MESSAGE);
                return;
            }
            heldBill.clear();
            for (CartItem item : cartItems) {
                heldBill.add(new CartItem(item.getProduct(), item.getQuantity()));
            }
            showToast("Draft saved — use Hold Bill to park the register");
        }

        private String buildReceiptText() {
            StringBuilder receipt = new StringBuilder();
            receipt.append("GREEN BASKET GROCERY\n");
            receipt.append("────────────────────────────────\n");
            receipt.append("Invoice: INV-").append(System.currentTimeMillis()).append("\n");
            receipt.append("Date: ").append(new java.text.SimpleDateFormat("dd MMM yyyy, HH:mm").format(new java.util.Date())).append("\n");
            if (!customerNameField.getText().trim().isEmpty()) {
                receipt.append("Customer: ").append(customerNameField.getText().trim()).append("\n");
            }
            receipt.append("────────────────────────────────\n");
            for (CartItem item : cartItems) {
                receipt.append(String.format("%-22s %2d  %10s%n", item.getProduct().getName(),
                        item.getQuantity(), MONEY.format(item.getTotalPrice())));
            }
            double subtotal = 0;
            double tax = 0;
            for (CartItem item : cartItems) {
                subtotal += item.getTotalPrice();
                tax += item.getItemTax();
            }
            double discount = parseCurrencyField(discountField.getText());
            receipt.append("────────────────────────────────\n");
            receipt.append("Subtotal: ").append(MONEY.format(subtotal)).append("\n");
            receipt.append("Discount: ").append(MONEY.format(discount)).append("\n");
            receipt.append("Tax: ").append(MONEY.format(tax)).append("\n");
            receipt.append("TOTAL: ").append(MONEY.format(subtotal - discount + tax)).append("\n");
            receipt.append("Payment: ").append(getSelectedPaymentMethod()).append("\n");
            receipt.append("\nThank you for shopping with us!");
            return receipt.toString();
        }

        private void printInvoice() {
            if (cartItems.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Add items before printing an invoice.",
                        "Print Invoice", JOptionPane.WARNING_MESSAGE);
                return;
            }
            JTextArea area = new JTextArea(buildReceiptText());
            area.setFont(new Font(Font.MONOSPACED, Font.PLAIN, 11));
            try {
                if (area.print()) showToast("Invoice sent to printer");
            } catch (PrinterException ex) {
                JOptionPane.showMessageDialog(this, "Unable to print invoice: " + ex.getMessage(),
                        "Print Invoice", JOptionPane.ERROR_MESSAGE);
            }
        }

        private void completeOrder() {
            if (cartItems.isEmpty()) {
                JOptionPane.showMessageDialog(this, "Cart is empty. Add products before checkout.", "Checkout", JOptionPane.WARNING_MESSAGE);
                return;
            }

            for (CartItem item : cartItems) {
                if (item.getQuantity() > item.getProduct().getStock()) {
                    JOptionPane.showMessageDialog(this,
                            "Insufficient stock for " + item.getProduct().getName() + ". Available: " + item.getProduct().getStock(),
                            "Stock Limit",
                            JOptionPane.WARNING_MESSAGE);
                    return;
                }
            }

            String paymentMethod = getSelectedPaymentMethod();
            double subtotal = 0.0;
            double tax = 0.0;
            for (CartItem item : cartItems) {
                subtotal += item.getTotalPrice();
                tax += item.getItemTax();
            }
            double discount = parseCurrencyField(discountField.getText());
            double grandTotal = subtotal - discount + tax;

            if (!saveCompletedSale(paymentMethod, subtotal, discount, tax, grandTotal)) {
                return;
            }
            seedProducts();

            StringBuilder receipt = new StringBuilder();
            receipt.append("Order Placed Successfully!\n\n");
            for (CartItem item : cartItems) {
                receipt.append(item.getProduct().getName())
                        .append(" x")
                        .append(item.getQuantity())
                        .append(" = ")
                        .append(MONEY.format(item.getTotalPrice()))
                        .append("\n");
            }
            receipt.append("\nSubtotal: ").append(MONEY.format(subtotal));
            receipt.append("\nDiscount: ").append(MONEY.format(discount));
            receipt.append("\nTax: ").append(MONEY.format(tax));
            receipt.append("\nGrand Total: ").append(MONEY.format(grandTotal));
            receipt.append("\nPayment Method: ").append(paymentMethod);

            JOptionPane.showMessageDialog(this,
                    "Payment successful via " + paymentMethod + "\n\n" + receipt,
                    "Order Completed",
                    JOptionPane.INFORMATION_MESSAGE);
            showToast("Bill completed successfully");
            clearCart();
        }

        private void reduceStockAfterSale() {
            for (CartItem item : cartItems) {
                Product product = item.getProduct();
                int remainingStock = product.getStock() - item.getQuantity();
                product.setStock(Math.max(0, remainingStock));
            }
        }

        private boolean saveCompletedSale(String paymentMethod, double subtotal, double discount, double tax, double grandTotal) {
            String customerName = customerNameField.getText() == null ? "" : customerNameField.getText().trim();
            String customerMobile = customerMobileField.getText() == null ? "" : customerMobileField.getText().trim();
            String invoiceId = "INV-" + System.currentTimeMillis();
            salesHistory.add(new SaleRecord(
                    invoiceId,
                    customerName,
                    paymentMethod,
                    subtotal,
                    discount,
                    tax,
                    grandTotal,
                    System.currentTimeMillis()
            ));
            try {
                org.example.dao.SalesDao salesDao = new org.example.dao.SalesDao();
                java.util.List<org.example.model.SaleItem> saleItems = new java.util.ArrayList<>();
                for (CartItem item : cartItems) {
                    org.example.model.SaleItem saleItem = new org.example.model.SaleItem();
                    saleItem.setProductId(item.getProduct().getId());
                    saleItem.setQuantity(item.getQuantity());
                    saleItem.setUnitPrice(item.getProduct().getPrice());
                    saleItem.setLineTotal(item.getTotalPrice());
                    saleItems.add(saleItem);
                }
                salesDao.saveSale(invoiceId, customerName, customerMobile, paymentMethod, subtotal, discount, tax, grandTotal, saleItems);
                return true;
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "Could not save bill to database: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                return false;
            }
        }

        private void styleProductTable(JTable table) {
            table.setBackground(SURFACE);
            table.setForeground(TEXT);
            table.setGridColor(new Color(241, 245, 249));
            table.setSelectionBackground(new Color(236, 253, 245));
            table.setSelectionForeground(TEXT);
            table.setShowGrid(false);
            table.setRowHeight(52);
            table.setIntercellSpacing(new Dimension(0, 0));
            table.setPreferredScrollableViewportSize(new Dimension(0, 0));
            table.setFillsViewportHeight(true);
            table.setAutoCreateRowSorter(false);

            JTableHeader header = table.getTableHeader();
            header.setBackground(new Color(241, 245, 249));
            header.setForeground(MUTED);
            header.setFont(new Font("SansSerif", Font.BOLD, 12));
            header.setBorder(new EmptyBorder(10, 10, 10, 10));
            header.setReorderingAllowed(false);

            DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
            renderer.setBackground(SURFACE);
            renderer.setForeground(TEXT);
            renderer.setBorder(new EmptyBorder(8, 10, 8, 10));
            table.setDefaultRenderer(Object.class, renderer);
            table.getColumnModel().getColumn(1).setCellRenderer(new ProductNameCellRenderer());
        }

        private void styleCartTable(JTable table) {
            table.setBackground(SURFACE);
            table.setForeground(TEXT);
            table.setShowGrid(false);
            table.setRowHeight(42);
            table.setIntercellSpacing(new Dimension(0, 0));
            table.setFillsViewportHeight(true);
            table.setPreferredScrollableViewportSize(new Dimension(0, 0));
            table.setSelectionBackground(new Color(236, 253, 245));
            table.setSelectionForeground(TEXT);
            table.setAutoResizeMode(JTable.AUTO_RESIZE_SUBSEQUENT_COLUMNS);

            JTableHeader header = table.getTableHeader();
            header.setBackground(new Color(241, 245, 249));
            header.setForeground(MUTED);
            header.setFont(new Font("SansSerif", Font.BOLD, 11));
            header.setBorder(new EmptyBorder(10, 10, 10, 10));
            header.setReorderingAllowed(false);

            DefaultTableCellRenderer renderer = new DefaultTableCellRenderer();
            renderer.setBackground(SURFACE);
            renderer.setForeground(TEXT);
            renderer.setBorder(new EmptyBorder(10, 10, 10, 10));
            table.setDefaultRenderer(Object.class, renderer);

            table.getColumnModel().getColumn(0).setPreferredWidth(58);
            table.getColumnModel().getColumn(1).setPreferredWidth(150);
            table.getColumnModel().getColumn(2).setPreferredWidth(70);
            table.getColumnModel().getColumn(3).setPreferredWidth(80);
            table.getColumnModel().getColumn(4).setPreferredWidth(90);
            table.getColumnModel().getColumn(5).setPreferredWidth(90);

            table.getColumnModel().getColumn(0).setCellRenderer(new ReportProductImageRenderer());
            table.getColumnModel().getColumn(2).setCellRenderer(new CartQtyRenderer());
            table.getColumnModel().getColumn(2).setCellEditor(new CartQtyEditor());
            table.getColumnModel().getColumn(5).setCellRenderer(new RemoveActionRenderer());
            table.getColumnModel().getColumn(5).setCellEditor(new RemoveActionEditor());

            table.addMouseListener(new MouseAdapter() {
                @Override
                public void mouseClicked(MouseEvent e) {
                    if (e.getClickCount() == 2) {
                        int row = table.rowAtPoint(e.getPoint());
                        if (row >= 0) {
                            adjustCartQty(row, 1);
                        }
                    }
                }
            });
        }

        private void adjustCartQty(int rowIndex, int delta) {
            if (rowIndex < 0 || rowIndex >= cartItems.size()) {
                return;
            }
            CartItem item = cartItems.get(rowIndex);
            int newQty = item.getQuantity() + delta;
            if (newQty <= 0) {
                cartItems.remove(rowIndex);
            } else {
                if (newQty > item.getProduct().getStock()) {
                    JOptionPane.showMessageDialog(this,
                            "Insufficient stock for " + item.getProduct().getName() + ". Available: " + item.getProduct().getStock(),
                            "Stock Limit",
                            JOptionPane.WARNING_MESSAGE);
                    return;
                }
                item.setQuantity(newQty);
            }
            refreshCartTotals();
        }

        private void removeCartItem(int rowIndex) {
            if (rowIndex >= 0 && rowIndex < cartItems.size()) {
                cartItems.remove(rowIndex);
                refreshCartTotals();
            }
        }

        private class ProductNameCellRenderer extends DefaultTableCellRenderer {
            private final JPanel panel = new JPanel(new BorderLayout(10, 0));
            private final JLabel imageLabel = new JLabel();
            private final JLabel textLabel = new JLabel();

            ProductNameCellRenderer() {
                panel.setOpaque(true);
                imageLabel.setPreferredSize(new Dimension(42, 42));
                imageLabel.setHorizontalAlignment(SwingConstants.CENTER);
                imageLabel.setVerticalAlignment(SwingConstants.CENTER);
                imageLabel.setBorder(new RoundedBorder(10, BORDER, 1, true));
                textLabel.setForeground(TEXT);
                textLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
                panel.add(imageLabel, BorderLayout.WEST);
                panel.add(textLabel, BorderLayout.CENTER);
            }

            private class ProductImageCellRenderer extends DefaultTableCellRenderer {
                private final JLabel label = new JLabel();

                ProductImageCellRenderer() {
                    label.setHorizontalAlignment(SwingConstants.CENTER);
                    label.setOpaque(true);
                    label.setBackground(new Color(248, 250, 252));
                    label.setBorder(new RoundedBorder(10, BORDER, 1, true));
                }

                @Override
                public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                               boolean hasFocus, int row, int column) {
                    int sourceIndex = (productsPanelPage - 1) * PRODUCTS_PAGE_SIZE + row;
                    Product product = sourceIndex >= 0 && sourceIndex < productsPanelFiltered.size()
                            ? productsPanelFiltered.get(sourceIndex) : null;
                    label.setIcon(createProductThumbnailIcon(product == null ? null : product.getImagePath(), 38, 38));
                    label.setBackground(isSelected ? table.getSelectionBackground() : new Color(248, 250, 252));
                    return label;
                }
            }

            private class CategoryBadgeRenderer extends DefaultTableCellRenderer {
                private final JLabel label = new JLabel();

                CategoryBadgeRenderer() {
                    label.setHorizontalAlignment(SwingConstants.CENTER);
                    label.setOpaque(true);
                    label.setFont(new Font("SansSerif", Font.BOLD, 11));
                }

                @Override
                public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                               boolean hasFocus, int row, int column) {
                    String category = value == null ? "" : String.valueOf(value);
                    label.setText(category);
                    label.setForeground(GREEN_DARK);
                    label.setBackground(new Color(236, 253, 245));
                    label.setBorder(new RoundedBorder(10, new Color(187, 247, 208), 1, true));
                    return label;
                }
            }

            private class StockQuantityRenderer extends DefaultTableCellRenderer {
                private final JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
                private final JLabel quantity = new JLabel();
                private final JLabel status = new JLabel();

                StockQuantityRenderer() {
                    panel.setOpaque(false);
                    quantity.setForeground(TEXT);
                    quantity.setFont(new Font("SansSerif", Font.BOLD, 12));
                    status.setFont(new Font("SansSerif", Font.BOLD, 10));
                    panel.add(quantity);
                    panel.add(status);
                }

                @Override
                public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                               boolean hasFocus, int row, int column) {
                    int stock = value instanceof Number n ? n.intValue() : 0;
                    quantity.setText(String.valueOf(stock));
                    String text = stock <= 0 ? "Out of Stock" : stock <= 10 ? "Low Stock" : "In Stock";
                    status.setText(text);
                    status.setOpaque(true);
                    status.setBorder(new RoundedBorder(9, stock <= 0 ? new Color(254, 202, 202)
                            : stock <= 10 ? new Color(253, 230, 138) : new Color(187, 247, 208), 1, true));
                    status.setBackground(stock <= 0 ? new Color(254, 242, 242)
                            : stock <= 10 ? new Color(254, 243, 199) : new Color(236, 253, 245));
                    status.setForeground(stock <= 0 ? new Color(153, 27, 27)
                            : stock <= 10 ? new Color(146, 64, 14) : new Color(22, 101, 52));
                    return panel;
                }
            }

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                panel.setBackground(isSelected ? table.getSelectionBackground() : table.getBackground());
                String name = value == null ? "" : String.valueOf(value);
                textLabel.setText(name);
                Product product = row >= 0 && row < filteredProducts.size() ? filteredProducts.get(row) : null;
                if (product != null) {
                    imageLabel.setIcon(createProductThumbnailIcon(product.getImagePath(), 42, 42));
                } else {
                    imageLabel.setIcon(createProductThumbnailIcon(null, 42, 42));
                }
                return panel;
            }
        }

        private class ProductsImageCellRenderer extends DefaultTableCellRenderer {
            private final JLabel label = new JLabel();

            ProductsImageCellRenderer() {
                label.setHorizontalAlignment(SwingConstants.CENTER);
                label.setOpaque(true);
                label.setBackground(new Color(248, 250, 252));
                label.setBorder(new RoundedBorder(10, BORDER, 1, true));
            }

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                           boolean hasFocus, int row, int column) {
                int sourceIndex = (productsPanelPage - 1) * PRODUCTS_PAGE_SIZE + row;
                Product product = sourceIndex >= 0 && sourceIndex < productsPanelFiltered.size()
                        ? productsPanelFiltered.get(sourceIndex) : null;
                label.setIcon(createProductThumbnailIcon(product == null ? null : product.getImagePath(), 38, 38));
                label.setBackground(isSelected ? table.getSelectionBackground() : new Color(248, 250, 252));
                return label;
            }
        }

        private class ReportProductImageRenderer extends DefaultTableCellRenderer {
            private final JLabel label = new JLabel();

            ReportProductImageRenderer() {
                label.setHorizontalAlignment(SwingConstants.CENTER);
                label.setOpaque(true);
                label.setBackground(new Color(248, 250, 252));
                label.setBorder(new RoundedBorder(9, BORDER, 1, true));
            }

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                           boolean hasFocus, int row, int column) {
                label.setIcon(createProductThumbnailIcon(value == null ? null : String.valueOf(value), 38, 38));
                label.setBackground(isSelected ? table.getSelectionBackground() : new Color(248, 250, 252));
                return label;
            }
        }

        private class ProductsCategoryBadgeRenderer extends DefaultTableCellRenderer {
            private final JLabel label = new JLabel();

            ProductsCategoryBadgeRenderer() {
                label.setHorizontalAlignment(SwingConstants.CENTER);
                label.setOpaque(true);
                label.setFont(new Font("SansSerif", Font.BOLD, 11));
            }

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                           boolean hasFocus, int row, int column) {
                label.setText(value == null ? "" : String.valueOf(value));
                label.setForeground(GREEN_DARK);
                label.setBackground(new Color(236, 253, 245));
                label.setBorder(new RoundedBorder(10, new Color(187, 247, 208), 1, true));
                return label;
            }
        }

        private class ProductsStockQuantityRenderer extends DefaultTableCellRenderer {
            private final JPanel panel = new JPanel(new FlowLayout(FlowLayout.LEFT, 6, 0));
            private final JLabel quantity = new JLabel();
            private final JLabel status = new JLabel();

            ProductsStockQuantityRenderer() {
                panel.setOpaque(true);
                panel.setBorder(new EmptyBorder(5, 10, 5, 10));
                quantity.setForeground(TEXT);
                quantity.setFont(new Font("SansSerif", Font.BOLD, 12));
                status.setFont(new Font("SansSerif", Font.BOLD, 10));
                panel.add(quantity);
                panel.add(status);
            }

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                           boolean hasFocus, int row, int column) {
                int stock = value instanceof Number n ? n.intValue() : 0;
                quantity.setText(String.valueOf(stock));
                int sourceIndex = (productsPanelPage - 1) * PRODUCTS_PAGE_SIZE + row;
                int lowStockThreshold = sourceIndex >= 0 && sourceIndex < productsPanelFiltered.size()
                        ? productsPanelFiltered.get(sourceIndex).getMinimumStockLevel() : 0;
                boolean lowStock = stock > 0 && stock <= lowStockThreshold;
                status.setText(stock <= 0 ? "Out of Stock" : lowStock ? "Low Stock" : "In Stock");
                panel.setBackground(isSelected ? table.getSelectionBackground() : SURFACE);
                status.setOpaque(true);
                status.setBackground(stock <= 0 ? new Color(254, 242, 242)
                        : lowStock ? new Color(254, 243, 199) : new Color(236, 253, 245));
                status.setForeground(stock <= 0 ? new Color(153, 27, 27)
                        : lowStock ? new Color(146, 64, 14) : new Color(22, 101, 52));
                status.setBorder(new RoundedBorder(9, stock <= 0 ? new Color(254, 202, 202)
                        : lowStock ? new Color(253, 230, 138) : new Color(187, 247, 208), 1, true));
                return panel;
            }
        }

        private class StockBadgeRenderer extends DefaultTableCellRenderer {
            private final JLabel label = new JLabel();

            StockBadgeRenderer() {
                label.setHorizontalAlignment(SwingConstants.CENTER);
                label.setOpaque(true);
                label.setBorder(new RoundedBorder(10, BORDER, 1, true));
                label.setFont(new Font("SansSerif", Font.BOLD, 11));
            }

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                int stock = value instanceof Number n ? n.intValue() : 0;
                boolean lowStock = stock > 0 && stock <= 10;
                String text = stock <= 0 ? "Out of Stock" : (lowStock ? "Low Stock" : "In Stock");
                label.setText(text);
                label.setBackground(lowStock ? new Color(254, 243, 199) : (stock <= 0 ? new Color(254, 242, 242) : new Color(236, 253, 245)));
                label.setForeground(lowStock ? new Color(146, 64, 14) : (stock <= 0 ? new Color(153, 27, 27) : new Color(22, 101, 52)));
                return label;
            }
        }

        private class AddActionRenderer implements TableCellRenderer {
            private final JButton button = new JButton("+");

            AddActionRenderer() {
                button.setBackground(GREEN);
                button.setForeground(WHITE);
                button.setFocusPainted(false);
                button.setFont(new Font("SansSerif", Font.BOLD, 12));
                button.setBorder(new RoundedBorder(8, GREEN, 1, true));
                button.setOpaque(true);
            }

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                return button;
            }
        }

        private class AddActionEditor extends AbstractCellEditor implements TableCellEditor, ActionListener {
            private final JButton button = new JButton("+");
            private int rowIndex = -1;

            AddActionEditor() {
                button.setBackground(GREEN);
                button.setForeground(WHITE);
                button.setFocusPainted(false);
                button.setFont(new Font("SansSerif", Font.BOLD, 12));
                button.setBorder(new RoundedBorder(8, GREEN, 1, true));
                button.addActionListener(this);
            }

            @Override
            public Object getCellEditorValue() {
                return "+";
            }

            @Override
            public Component getTableCellEditorComponent(JTable table, Object value,
                                                       boolean isSelected, int row, int column) {
                rowIndex = row;
                return button;
            }

            @Override
            public void actionPerformed(ActionEvent e) {
                if (rowIndex >= 0 && rowIndex < filteredProducts.size()) {
                    Product selected = filteredProducts.get(rowIndex);
                    addProductToCart(selected);
                }
                fireEditingStopped();
            }
        }

        private class CartQtyRenderer implements TableCellRenderer {
            private final JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0));
            private final JButton minusBtn = new JButton("-");
            private final JLabel qtyLabel = new JLabel();
            private final JButton plusBtn = new JButton("+");

            CartQtyRenderer() {
                panel.setOpaque(false);
                minusBtn.setFocusable(false);
                plusBtn.setFocusable(false);
                minusBtn.setBackground(SOFT);
                plusBtn.setBackground(SOFT);
                minusBtn.setForeground(TEXT);
                plusBtn.setForeground(TEXT);
                minusBtn.setBorder(new RoundedBorder(6, BORDER, 1, true));
                plusBtn.setBorder(new RoundedBorder(6, BORDER, 1, true));
                qtyLabel.setForeground(TEXT);
                qtyLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
                panel.add(minusBtn);
                panel.add(qtyLabel);
                panel.add(plusBtn);
            }

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                int qty = value instanceof Integer q ? q : 0;
                qtyLabel.setText(String.valueOf(qty));
                return panel;
            }
        }

        private class CartQtyEditor extends AbstractCellEditor implements TableCellEditor, ActionListener {
            private final JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0));
            private final JButton minusBtn = new JButton("-");
            private final JLabel qtyLabel = new JLabel();
            private final JButton plusBtn = new JButton("+");
            private int rowIndex = -1;

            CartQtyEditor() {
                panel.setOpaque(false);
                minusBtn.setFocusable(false);
                plusBtn.setFocusable(false);
                minusBtn.setBackground(SOFT);
                plusBtn.setBackground(SOFT);
                minusBtn.setForeground(TEXT);
                plusBtn.setForeground(TEXT);
                minusBtn.setBorder(new RoundedBorder(6, BORDER, 1, true));
                plusBtn.setBorder(new RoundedBorder(6, BORDER, 1, true));
                qtyLabel.setForeground(TEXT);
                qtyLabel.setFont(new Font("SansSerif", Font.BOLD, 12));
                minusBtn.addActionListener(this);
                plusBtn.addActionListener(this);
                panel.add(minusBtn);
                panel.add(qtyLabel);
                panel.add(plusBtn);
            }

            @Override
            public Object getCellEditorValue() {
                try {
                    return Integer.parseInt(qtyLabel.getText());
                } catch (NumberFormatException ex) {
                    return 0;
                }
            }

            @Override
            public Component getTableCellEditorComponent(JTable table, Object value,
                                                       boolean isSelected, int row, int column) {
                rowIndex = row;
                int qty = value instanceof Integer q ? q : 0;
                qtyLabel.setText(String.valueOf(qty));
                return panel;
            }

            @Override
            public void actionPerformed(ActionEvent e) {
                int delta = 0;
                if (e.getSource() == minusBtn) {
                    delta = -1;
                } else if (e.getSource() == plusBtn) {
                    delta = 1;
                }
                if (delta != 0) {
                    adjustCartQty(rowIndex, delta);
                }
                fireEditingStopped();
            }
        }

        private class RemoveActionRenderer implements TableCellRenderer {
            private final JButton button = new JButton("Remove");

            RemoveActionRenderer() {
                button.setBackground(new Color(254, 242, 242));
                button.setForeground(new Color(153, 27, 27));
                button.setFocusPainted(false);
                button.setFont(new Font("SansSerif", Font.BOLD, 11));
                button.setBorder(new RoundedBorder(8, new Color(248, 113, 113), 1, true));
                button.setOpaque(true);
            }

            @Override
            public Component getTableCellRendererComponent(JTable table, Object value,
                                                           boolean isSelected, boolean hasFocus,
                                                           int row, int column) {
                return button;
            }
        }

        private class RemoveActionEditor extends AbstractCellEditor implements TableCellEditor, ActionListener {
            private final JButton button = new JButton("Remove");
            private int rowIndex = -1;

            RemoveActionEditor() {
                button.setBackground(new Color(254, 242, 242));
                button.setForeground(new Color(153, 27, 27));
                button.setFocusPainted(false);
                button.setFont(new Font("SansSerif", Font.BOLD, 11));
                button.setBorder(new RoundedBorder(8, new Color(248, 113, 113), 1, true));
                button.addActionListener(this);
            }

            @Override
            public Object getCellEditorValue() {
                return "Remove";
            }

            @Override
            public Component getTableCellEditorComponent(JTable table, Object value,
                                                       boolean isSelected, int row, int column) {
                rowIndex = row;
                return button;
            }

            @Override
            public void actionPerformed(ActionEvent e) {
                removeCartItem(rowIndex);
                fireEditingStopped();
            }
        }

            private class ProductActionRenderer implements TableCellRenderer {
                private final JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0));
                private final JButton editButton = new JButton("Edit");
                private final JButton deleteButton = new JButton("Delete");

                ProductActionRenderer() {
                    panel.setOpaque(false);
                    editButton.setBackground(SOFT);
                    editButton.setForeground(TEXT);
                    editButton.setFocusPainted(false);
                    editButton.setBorder(new RoundedBorder(8, BORDER, 1, true));
                    editButton.setFont(new Font("SansSerif", Font.BOLD, 11));
                    deleteButton.setBackground(new Color(254, 242, 242));
                    deleteButton.setForeground(new Color(153, 27, 27));
                    deleteButton.setFocusPainted(false);
                    deleteButton.setBorder(new RoundedBorder(8, new Color(248, 113, 113), 1, true));
                    deleteButton.setFont(new Font("SansSerif", Font.BOLD, 11));
                    panel.add(editButton);
                    panel.add(deleteButton);
                }

                @Override
                public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                               boolean hasFocus, int row, int column) {
                    return panel;
                }
        }

            private class ProductActionEditor extends AbstractCellEditor implements TableCellEditor, ActionListener {
                private final JPanel panel = new JPanel(new FlowLayout(FlowLayout.CENTER, 6, 0));
                private final JButton editButton = new JButton("Edit");
                private final JButton deleteButton = new JButton("Delete");
                private int rowIndex = -1;

                ProductActionEditor() {
                    panel.setOpaque(false);
                    editButton.setBackground(SOFT);
                    editButton.setForeground(TEXT);
                    editButton.setFocusPainted(false);
                    editButton.setBorder(new RoundedBorder(8, BORDER, 1, true));
                    editButton.setFont(new Font("SansSerif", Font.BOLD, 11));
                    deleteButton.setBackground(new Color(254, 242, 242));
                    deleteButton.setForeground(new Color(153, 27, 27));
                    deleteButton.setFocusPainted(false);
                    deleteButton.setBorder(new RoundedBorder(8, new Color(248, 113, 113), 1, true));
                    deleteButton.setFont(new Font("SansSerif", Font.BOLD, 11));
                    editButton.addActionListener(this);
                    deleteButton.addActionListener(this);
                    panel.add(editButton);
                    panel.add(deleteButton);
                }

                @Override
                public Object getCellEditorValue() {
                    return "Actions";
                }

                @Override
                public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected,
                                                           int row, int column) {
                    rowIndex = row;
                    return panel;
                }

                @Override
                public void actionPerformed(ActionEvent e) {
                    int sourceIndex = (productsPanelPage - 1) * PRODUCTS_PAGE_SIZE + rowIndex;
                    if (rowIndex < 0 || sourceIndex >= productsPanelFiltered.size()) {
                        fireEditingStopped();
                        return;
                    }
                    Product product = productsPanelFiltered.get(sourceIndex);
                    if (e.getSource() == editButton) {
                        openEditProductDialog(product);
                    } else if (e.getSource() == deleteButton) {
                        int confirm = JOptionPane.showConfirmDialog(GroceryBillingApp.this,
                                "Delete \"" + product.getName() + "\" from the inventory?",
                                "Confirm deletion",
                                JOptionPane.YES_NO_OPTION,
                                JOptionPane.WARNING_MESSAGE);
                        if (confirm == JOptionPane.YES_OPTION) {
                            try {
                                new ProductDao().delete(product.getId());
                                productCatalog.remove(product);
                                applyProductFilter();
                                refreshProductPanelTable(productsPanelSearchField.getText(),
                                        String.valueOf(productsPanelCategoryFilter.getSelectedItem()));
                                updateProductSummary();
                                showToast("Product deleted successfully");
                            } catch (SQLException ex) {
                                JOptionPane.showMessageDialog(GroceryBillingApp.this,
                                        "Unable to delete product: " + ex.getMessage(),
                                        "Database Error", JOptionPane.ERROR_MESSAGE);
                            }
                        }
                    }
                    fireEditingStopped();
                }
        }

            private class ReceiptButtonRenderer implements TableCellRenderer {
                private final JButton button = new JButton("View Receipt");

                ReceiptButtonRenderer() {
                    button.setBackground(SOFT);
                    button.setForeground(TEXT);
                    button.setFocusPainted(false);
                    button.setBorder(new RoundedBorder(8, BORDER, 1, true));
                    button.setFont(new Font("SansSerif", Font.BOLD, 11));
                }

                @Override
                public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                               boolean hasFocus, int row, int column) {
                    return button;
                }
        }

            private class ReceiptButtonEditor extends AbstractCellEditor implements TableCellEditor, ActionListener {
                private final JButton button = new JButton("View Receipt");
                private int rowIndex = -1;

                ReceiptButtonEditor() {
                    button.setBackground(SOFT);
                    button.setForeground(TEXT);
                    button.setFocusPainted(false);
                    button.setBorder(new RoundedBorder(8, BORDER, 1, true));
                    button.setFont(new Font("SansSerif", Font.BOLD, 11));
                    button.addActionListener(this);
                }

                @Override
                public Object getCellEditorValue() {
                    return "View Receipt";
                }

                @Override
                public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected,
                                                           int row, int column) {
                    rowIndex = row;
                    return button;
                }

                @Override
                public void actionPerformed(ActionEvent e) {
                    if (rowIndex >= 0 && rowIndex < salesHistory.size()) {
                        SaleRecord sale = salesHistory.get(rowIndex);
                        String message = "Invoice: " + sale.getInvoiceId() + "\nCustomer: " + sale.getCustomerName()
                                + "\nPayment: " + sale.getPaymentMethod() + "\nTotal: " + MONEY.format(sale.getGrandTotal());
                        JOptionPane.showMessageDialog(GroceryBillingApp.this, message, "Receipt", JOptionPane.INFORMATION_MESSAGE);
                    }
                    fireEditingStopped();
                }
        }

            private class StockActionRenderer implements TableCellRenderer {
                private final JButton button = new JButton("Update Stock");

                StockActionRenderer() {
                    button.setBackground(SOFT);
                    button.setForeground(TEXT);
                    button.setFocusPainted(false);
                    button.setBorder(new RoundedBorder(8, BORDER, 1, true));
                    button.setFont(new Font("SansSerif", Font.BOLD, 11));
                }

                @Override
                public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected,
                                                               boolean hasFocus, int row, int column) {
                    return button;
                }
        }

            private class StockActionEditor extends AbstractCellEditor implements TableCellEditor, ActionListener {
                private final JButton button = new JButton("Update Stock");
                private int rowIndex = -1;

                StockActionEditor() {
                    button.setBackground(SOFT);
                    button.setForeground(TEXT);
                    button.setFocusPainted(false);
                    button.setBorder(new RoundedBorder(8, BORDER, 1, true));
                    button.setFont(new Font("SansSerif", Font.BOLD, 11));
                    button.addActionListener(this);
                }

                @Override
                public Object getCellEditorValue() {
                    return "Update Stock";
                }

                @Override
                public Component getTableCellEditorComponent(JTable table, Object value, boolean isSelected,
                                                           int row, int column) {
                    rowIndex = row;
                    return button;
                }

                @Override
                public void actionPerformed(ActionEvent e) {
                    if (rowIndex >= 0 && rowIndex < productCatalog.size()) {
                        Product product = productCatalog.get(rowIndex);
                        String input = JOptionPane.showInputDialog(GroceryBillingApp.this, "Update stock for " + product.getName(), product.getStock());
                        if (input != null) {
                            try {
                                int newStock = Integer.parseInt(input.trim());
                                if (newStock < 0) {
                                    throw new NumberFormatException();
                                }
                                new ProductDao().updateStock(product.getId(), newStock);
                                seedProducts();
                                refreshStockTable();
                            } catch (NumberFormatException ignored) {
                                JOptionPane.showMessageDialog(GroceryBillingApp.this, "Please enter a valid number.", "Invalid Stock", JOptionPane.WARNING_MESSAGE);
                            } catch (SQLException ex) {
                                JOptionPane.showMessageDialog(GroceryBillingApp.this, "Unable to update stock: " + ex.getMessage(), "Database Error", JOptionPane.ERROR_MESSAGE);
                            }
                    }
                }
                    fireEditingStopped();
                }
        }
    }

    static class Customer {
        private final int id;
        private final String name;
        private final String phoneNumber;
        private final int loyaltyPoints;
        private final String tier;
        private final double totalPurchaseValue;

        Customer(int id, String name, String phoneNumber, int loyaltyPoints, String tier, double totalPurchaseValue) {
            this.id = id;
            this.name = name;
            this.phoneNumber = phoneNumber;
            this.loyaltyPoints = loyaltyPoints;
            this.tier = tier;
            this.totalPurchaseValue = totalPurchaseValue;
        }

        public int getId() { return id; }
        public String getName() { return name; }
        public String getPhoneNumber() { return phoneNumber; }
        public int getLoyaltyPoints() { return loyaltyPoints; }
        public String getTier() { return tier; }
        public double getTotalPurchaseValue() { return totalPurchaseValue; }
    }

    static class Product {
        private final int id;
        private final String name;
        private final String category;
        private final String unit;
        private final double price;
        private int stock;
        private double taxRate;
        private String imagePath;
        private String barcode;
        private int minimumStockLevel;

        Product(int id, String name, String category, String unit, double price) {
            this(id, name, category, unit, price, 0, 0.0, null);
        }

        Product(int id, String name, String category, String unit, double price, int stock) {
            this(id, name, category, unit, price, stock, 0.0, null);
        }

        Product(int id, String name, String category, String unit, double price, int stock, double taxRate) {
            this(id, name, category, unit, price, stock, taxRate, null);
        }

        Product(int id, String name, String category, String unit, double price, int stock, double taxRate, String imagePath) {
            this.id = id;
            this.name = name;
            this.category = category;
            this.unit = unit;
            this.price = price;
            this.stock = stock;
            this.taxRate = taxRate;
            this.imagePath = imagePath;
        }

        public int getId() { return id; }
        public String getName() { return name; }
        public String getCategory() { return category; }
        public String getUnit() { return unit; }
        public double getPrice() { return price; }
        public int getStock() { return stock; }
        public double getTaxRate() { return taxRate; }
        public String getImagePath() { return imagePath; }
        public String getBarcode() { return barcode; }
        public int getMinimumStockLevel() { return minimumStockLevel; }
        public void setTaxRate(double taxRate) { this.taxRate = taxRate; }
        public void setStock(int stock) { this.stock = stock; }
        public void setImagePath(String imagePath) { this.imagePath = imagePath; }
        public void setBarcode(String barcode) { this.barcode = barcode; }
        public void setMinimumStockLevel(int minimumStockLevel) { this.minimumStockLevel = Math.max(0, minimumStockLevel); }
    }

    static class CartItem {
        private final Product product;
        private int quantity;

        CartItem(Product product, int quantity) {
            this.product = product;
            this.quantity = quantity;
        }

        public Product getProduct() { return product; }
        public int getQuantity() { return quantity; }
        public void setQuantity(int quantity) { this.quantity = quantity; }
        public double getTotalPrice() { return product.getPrice() * quantity; }
        public double getItemTax() { return (product.getPrice() * quantity * product.getTaxRate()) / 100.0; }
    }

    static class SaleRecord {
        private final String invoiceId;
        private final String customerName;
        private final String customerMobile;
        private final String paymentMethod;
        private final double subtotal;
        private final double discount;
        private final double tax;
        private final double grandTotal;
        private final long timestamp;

        SaleRecord(String invoiceId, String customerName, String paymentMethod,
                   double subtotal, double discount, double tax, double grandTotal, long timestamp) {
            this(invoiceId, customerName, "", paymentMethod, subtotal, discount, tax, grandTotal, timestamp);
        }

        SaleRecord(String invoiceId, String customerName, String customerMobile, String paymentMethod,
                   double subtotal, double discount, double tax, double grandTotal, long timestamp) {
            this.invoiceId = invoiceId;
            this.customerName = customerName;
            this.customerMobile = customerMobile;
            this.paymentMethod = paymentMethod;
            this.subtotal = subtotal;
            this.discount = discount;
            this.tax = tax;
            this.grandTotal = grandTotal;
            this.timestamp = timestamp;
        }

        public String getInvoiceId() { return invoiceId; }
        public String getCustomerName() { return customerName; }
        public String getCustomerMobile() { return customerMobile; }
        public String getPaymentMethod() { return paymentMethod; }
        public double getSubtotal() { return subtotal; }
        public double getDiscount() { return discount; }
        public double getTax() { return tax; }
        public double getGrandTotal() { return grandTotal; }
        public long getTimestamp() { return timestamp; }
    }

    static class SalesChartPanel extends JPanel {
        private final List<Double> hourlyTotals = new ArrayList<>();

        SalesChartPanel(List<org.example.model.Sale> sales) {
            setOpaque(false);
            for (int i = 0; i < 12; i++) hourlyTotals.add(0.0);
            java.util.Calendar now = java.util.Calendar.getInstance();
            for (org.example.model.Sale sale : sales) {
                if (sale.getSaleDate() == null) continue;
                java.util.Calendar date = java.util.Calendar.getInstance();
                date.setTimeInMillis(sale.getSaleDate().getTime());
                if (date.get(java.util.Calendar.YEAR) == now.get(java.util.Calendar.YEAR)
                        && date.get(java.util.Calendar.DAY_OF_YEAR) == now.get(java.util.Calendar.DAY_OF_YEAR)) {
                    int bucket = Math.min(11, date.get(java.util.Calendar.HOUR_OF_DAY) / 2);
                    hourlyTotals.set(bucket, hourlyTotals.get(bucket) + sale.getGrandTotal());
                }
            }
            setPreferredSize(new Dimension(420, 150));
        }

        @Override protected void paintComponent(Graphics graphics) {
            super.paintComponent(graphics);
            Graphics2D g = (Graphics2D) graphics.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            int left = 34, top = 12, bottom = 28;
            int chartHeight = Math.max(30, getHeight() - top - bottom);
            int chartWidth = Math.max(80, getWidth() - left - 12);
            double max = 0;
            for (double value : hourlyTotals) max = Math.max(max, value);
            g.setColor(BORDER);
            for (int line = 0; line < 4; line++) {
                int y = top + chartHeight - (line * chartHeight / 3);
                g.drawLine(left, y, left + chartWidth, y);
            }
            if (max == 0) {
                g.setColor(MUTED);
                g.setFont(new Font("SansSerif", Font.PLAIN, 12));
                g.drawString("No sales data available yet", left + 20, top + chartHeight / 2);
            } else {
                int gap = 5;
                int barWidth = Math.max(8, (chartWidth - gap * 11) / 12);
                g.setColor(GREEN);
                for (int i = 0; i < hourlyTotals.size(); i++) {
                    int height = (int) Math.round((hourlyTotals.get(i) / max) * (chartHeight - 8));
                    int x = left + i * (barWidth + gap);
                    int y = top + chartHeight - height;
                    g.fillRoundRect(x, y, barWidth, Math.max(3, height), 6, 6);
                }
            }
            g.setColor(MUTED);
            g.setFont(new Font("SansSerif", Font.PLAIN, 10));
            g.drawString("08:00", left, getHeight() - 8);
            g.drawString("14:00", left + chartWidth / 2 - 16, getHeight() - 8);
            g.drawString("Now", left + chartWidth - 22, getHeight() - 8);
            g.dispose();
        }
    }

    static class ResponsiveBillingPage extends JPanel implements Scrollable {
        ResponsiveBillingPage() {
            super(new BorderLayout(20, 18));
        }

        @Override
        public Dimension getPreferredScrollableViewportSize() {
            return new Dimension(900, 620);
        }

        @Override
        public boolean getScrollableTracksViewportWidth() {
            return true;
        }

        @Override
        public boolean getScrollableTracksViewportHeight() {
            return false;
        }

        @Override
        public int getScrollableUnitIncrement(Rectangle visibleRect, int orientation, int direction) {
            return 18;
        }

        @Override
        public int getScrollableBlockIncrement(Rectangle visibleRect, int orientation, int direction) {
            return Math.max(visibleRect.height - 36, 18);
        }
    }

    static class ResponsiveProductGrid extends JPanel implements Scrollable {
        ResponsiveProductGrid() {
            super(new WrapLayout(FlowLayout.LEFT, 14, 14));
        }

        @Override
        public Dimension getPreferredScrollableViewportSize() {
            return new Dimension(620, 420);
        }

        @Override
        public boolean getScrollableTracksViewportWidth() {
            return true;
        }

        @Override
        public boolean getScrollableTracksViewportHeight() {
            return false;
        }

        @Override
        public int getScrollableUnitIncrement(Rectangle visibleRect, int orientation, int direction) {
            return 14;
        }

        @Override
        public int getScrollableBlockIncrement(Rectangle visibleRect, int orientation, int direction) {
            return Math.max(visibleRect.height - 28, 14);
        }
    }

    static class WrapLayout extends FlowLayout {
        WrapLayout(int align, int hgap, int vgap) {
            super(align, hgap, vgap);
        }

        @Override
        public Dimension preferredLayoutSize(Container target) {
            synchronized (target.getTreeLock()) {
                Insets insets = target.getInsets();
                int width = target.getWidth();
                if (width <= 0 && target.getParent() != null) {
                    width = target.getParent().getWidth();
                }
                if (width <= 0) {
                    width = 640;
                }
                int maxWidth = Math.max(1, width - insets.left - insets.right - getHgap() * 2);
                int rowWidth = 0;
                int rowHeight = 0;
                int height = insets.top + getVgap();
                for (Component component : target.getComponents()) {
                    if (!component.isVisible()) continue;
                    Dimension size = component.getPreferredSize();
                    if (rowWidth > 0 && rowWidth + getHgap() + size.width > maxWidth) {
                        height += rowHeight + getVgap();
                        rowWidth = 0;
                        rowHeight = 0;
                    }
                    rowWidth += (rowWidth == 0 ? 0 : getHgap()) + size.width;
                    rowHeight = Math.max(rowHeight, size.height);
                }
                return new Dimension(width, height + rowHeight + insets.bottom);
            }
        }

        @Override
        public Dimension minimumLayoutSize(Container target) {
            return preferredLayoutSize(target);
        }
    }

    static class RoundedBorder extends AbstractBorder {
        private final int radius;
        private final Color color;
        private final int thickness;

        RoundedBorder(int radius, Color color, int thickness, boolean ignored) {
            this.radius = radius;
            this.color = color;
            this.thickness = thickness;
        }

        @Override
        public void paintBorder(Component c, Graphics g, int x, int y, int width, int height) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(color);
            g2.setStroke(new BasicStroke(thickness));
            g2.draw(new RoundRectangle2D.Double(x + 1, y + 1, width - 3, height - 3, radius, radius));
            g2.dispose();
        }

        @Override
        public Insets getBorderInsets(Component c) {
            return new Insets(6, 6, 6, 6);
        }

        @Override
        public Insets getBorderInsets(Component c, Insets insets) {
            insets.left = 6;
            insets.right = 6;
            insets.bottom = 6;
            return insets;
        }
    }
}