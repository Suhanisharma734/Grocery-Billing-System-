#include <iostream>
using namespace std;

int main()
{
    // Stack size is 5
    int stack[5];

    // Stack is initially empty
    int top = -1;

    int n, value;

    // Take the number of elements from the user
    cout << "Enter number of elements: ";
    cin >> n;

    // Take elements as input
    for (int i = 0; i < n; i++)
    {
        // Check if the stack is full
        if (top == 4)
        {
            cout << "Stack Overflow!" << endl;
            break;
        }

        cout << "Enter element " << i + 1 << ": ";
        cin >> value;

        // Move top to the next position
        top++;

        // Store the value in the stack
        stack[top] = value;
    }

    // Display the stack
    cout << "\nStack:" << endl;
    cout << "-------" << endl;

    // Display elements from top to bottom
    for (int i = top; i >= 0; i--)
    {
        cout << "| " << stack[i] << " |";

        // Identify the top element
        if (i == top)
        {
            cout << " <- TOP";
        }

        cout << endl;
        cout << "-------" << endl;
    }

    return 0;
}