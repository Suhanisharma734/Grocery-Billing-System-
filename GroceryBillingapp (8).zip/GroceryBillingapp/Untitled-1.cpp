#include <iostream>
using namespace std;

// This function deletes an element from the array
void deletion(int arr[], int &n, int pos)
{
    // Shift elements to the left
    for (int i = pos; i < n - 1; i++)
    {
        arr[i] = arr[i + 1];
    }

    // Decrease array size
    n--;
}

int main()
{
    int n;
    int arr[100];
    int pos;

    cout << "Enter number of elements: ";
    cin >> n;

    cout << "Enter elements: ";

    for (int i = 0; i < n; i++)
    {
        cin >> arr[i];
    }

    cout << "Enter position to delete: ";
    cin >> pos;

    // Convert position into array index
    pos = pos - 1;

    // Check whether position is valid
    if (pos >= 0 && pos < n)
    {
        // Call deletion function
        deletion(arr, n, pos);

        cout << "Array after deletion: ";

        for (int i = 0; i < n; i++)
        {
            cout << arr[i] << " ";
        }
    }
    else
    {
        cout << "Invalid position";
    }

    return 0;
