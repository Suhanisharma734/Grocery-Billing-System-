#include <iostream>
using namespace std;

int main()
{
    // Maximum size of the queue
    const int SIZE = 10;

    // Declare an array to store queue elements
    int queue[SIZE];

    // Initially, queue is empty
    int front = -1;
    int rear = -1;

    // Variable for number of elements
    int n;

    // Variable to store each element
    int value;

    // Ask the user how many elements to insert
    cout << "Enter number of elements to insert: ";
    cin >> n;

    // Check whether number of elements is within queue size
    if (n > SIZE)
    {
        cout << "You can insert maximum " << SIZE
             << " elements." << endl;
    }
    else if (n <= 0)
    {
        cout << "Invalid number of elements." << endl;
    }
    else
    {
        // Insert elements one by one
        for (int i = 0; i < n; i++)
        {
            // Take element from the user
            cout << "Enter element " << i + 1 << ": ";
            cin >> value;

            // If this is the first element,
            // set front to 0
            if (front == -1)
            {
                front = 0;
            }

            // Move rear to the next position
            rear++;

            // Insert the element at rear
            queue[rear] = value;
        }

        // Display all queue elements
        cout << "\nQueue after Enqueue:" << endl;

        cout << "Front -> ";

        for (int i = front; i <= rear; i++)
        {
            cout << queue[i] << " ";
        }

        cout << "<- Rear" << endl;
    }

    return 0;
}