PEEK

#include <iostream>
using namespace std;

int main()
{
    // Create an array for the stack
    int stack[5];

    // Initially, the stack is empty
    int top = -1;

    int n, value;

    // Ask the user for the number of elements
    cout << "Enter number of elements: ";
    cin >> n;

    // Insert elements into the stack
    for (int i = 0; i < n; i++)
    {
        cout << "Enter element " << i + 1 << ": ";
        cin >> value;

        top++;
        stack[top] = value;
    }

    // Check whether the stack is empty
    if (top == -1)
    {
        cout << "Stack is Empty!" << endl;
    }
    else
    {
        // Peek displays the top element
        // without removing it
        cout << "\nTop element is: " << stack[top] << endl;

        // Display the stack
        cout << "\nStack:" << endl;
        cout << "-------" << endl;

        for (int i = top; i >= 0; i--)
        {
            cout << "| " << stack[i] << " |";

            if (i == top)
            {
                cout << " <- TOP";
            }

            cout << endl;
            cout << "-------" << endl;
        }
    }

    return 0;
}